<!-- Create this file at resources/views/emails/room-allocation.blade.php -->

<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>Hostel Room Allocation</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            line-height: 1.6;
            color: #333;
            max-width: 600px;
            margin: 0 auto;
            padding: 20px;
        }
        .header {
            background-color: #0d6efd;
            color: white;
            padding: 20px;
            text-align: center;
            border-radius: 5px 5px 0 0;
        }
        .content {
            padding: 20px;
            border: 1px solid #ddd;
            border-top: none;
            border-radius: 0 0 5px 5px;
        }
        .footer {
            margin-top: 20px;
            text-align: center;
            font-size: 0.8em;
            color: #666;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin: 20px 0;
        }
        th, td {
            padding: 10px;
            border: 1px solid #ddd;
            text-align: left;
        }
        th {
            background-color: #f5f5f5;
        }
    </style>
</head>
<body>
    <div class="header">
        <h1>Room Allocation Notification</h1>
    </div>
    
    <div class="content">
        <p>Dear {{ $data['student_name'] }},</p>
        
        <p>We are pleased to inform you that your hostel room has been allocated. Please find your room details below:</p>
        
        <table>
            <tr>
                <th>Student ID</th>
                <td>{{ $data['cid'] }}</td>
            </tr>
            <tr>
                <th>Student Name</th>
                <td>{{ $data['student_name'] }}</td>
            </tr>
            <tr>
                <th>Course</th>
                <td>{{ $data['course'] }}</td>
            </tr>
            <tr>
                <th>Block Number</th>
                <td>{{ $data['block'] }}</td>
            </tr>
            <tr>
                <th>Room Number</th>
                <td>{{ $data['room'] }}</td>
            </tr>
            <tr>
                <th>Allocation Date</th>
                <td>{{ $data['allocation_date'] }}</td>
            </tr>
        </table>
        
        <p>Please note the following:</p>
        <ul>
            <li>You are expected to move into your allocated room within 7 days.</li>
            <li>Please bring your student ID card when moving in.</li>
            <li>Collect your room key from the Warden's office during office hours.</li>
            <li>Any issues with your room allocation should be reported immediately to the Warden's office.</li>
        </ul>
        
        <p>Best regards,<br>{{ $data['warden_name'] }}<br>Hostel Warden</p>
    </div>
    
    <div class="footer">
        <p>This is an automated email. Please do not reply to this email address.</p>
        <p>If you have any queries, please contact the hostel administration office.</p>
    </div>
</body>
</html>