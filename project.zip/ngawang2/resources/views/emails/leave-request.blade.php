{{-- emails/leave-request-submitted.blade.php --}}
<!DOCTYPE html>
<html>
<head>
    <title>Hostel Leave Request Submitted</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            line-height: 1.6;
            color: #333;
            max-width: 600px;
            margin: 0 auto;
            padding: 20px;
        }
        .header {
            background-color: #28a745;
            color: white;
            padding: 10px 20px;
            border-radius: 5px;
            margin-bottom: 20px;
        }
        .content {
            background-color: #f9f9f9;
            padding: 20px;
            border-radius: 5px;
        }
        .details {
            margin: 20px 0;
        }
        .details div {
            margin-bottom: 10px;
        }
        .footer {
            margin-top: 30px;
            font-size: 0.9em;
            color: #666;
            text-align: center;
        }
        .status {
            display: inline-block;
            background-color: #ffc107;
            color: #333;
            padding: 5px 10px;
            border-radius: 3px;
            font-weight: bold;
        }
    </style>
</head>
<body>
    <div class="header">
        <h2>Hostel Leave Request Confirmation</h2>
    </div>
    
    <div class="content">
        <p>Dear {{ $leaveData['student_name'] }},</p>
        
        <p>Your hostel leave request has been submitted successfully. It is currently pending approval from the warden.</p>
        
        <div class="details">
            <h3>Leave Request Details:</h3>
            <div><strong>CID:</strong> {{ $leaveData['cid'] }}</div>
            <div><strong>Start Date:</strong> {{ $leaveData['start_date'] }}</div>
            <div><strong>End Date:</strong> {{ $leaveData['end_date'] }}</div>
            <div><strong>Reason:</strong> {{ $leaveData['reason'] }}</div>
            <div><strong>Submission Date:</strong> {{ $leaveData['request_date'] }}</div>
            <div><strong>Status:</strong> <span class="status">{{ $leaveData['status'] }}</span></div>
        </div>
        
        <p>You will receive another email notification once your leave request has been reviewed by the warden.</p>
        
        <p>Please note: Do not leave the hostel until your request has been approved.</p>
    </div>
    
    <div class="footer">
        <p>This is an automated message. Please do not reply to this email.</p>
        <p>&copy; {{ date('Y') }} Hostel Management System</p>
    </div>
</body>
</html>

{{-- emails/leave-request-approved.blade.php --}}
<!DOCTYPE html>
<html>
<head>
    <title>Hostel Leave Request Approved</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            line-height: 1.6;
            color: #333;
            max-width: 600px;
            margin: 0 auto;
            padding: 20px;
        }
        .header {
            background-color: #28a745;
            color: white;
            padding: 10px 20px;
            border-radius: 5px;
            margin-bottom: 20px;
        }
        .content {
            background-color: #f9f9f9;
            padding: 20px;
            border-radius: 5px;
        }
        .details {
            margin: 20px 0;
        }
        .details div {
            margin-bottom: 10px;
        }
        .footer {
            margin-top: 30px;
            font-size: 0.9em;
            color: #666;
            text-align: center;
        }
        .status {
            display: inline-block;
            background-color: #28a745;
            color: white;
            padding: 5px 10px;
            border-radius: 3px;
            font-weight: bold;
        }
    </style>
</head>
<body>
    <div class="header">
        <h2>Hostel Leave Request Approved</h2>
    </div>
    
    <div class="content">
        <p>Dear {{ $leaveData['student_name'] }},</p>
        
        <p>Good news! Your hostel leave request has been <strong>approved</strong> by the warden.</p>
        
        <div class="details">
            <h3>Leave Request Details:</h3>
            <div><strong>CID:</strong> {{ $leaveData['cid'] }}</div>
            <div><strong>Start Date:</strong> {{ $leaveData['start_date'] }}</div>
            <div><strong>End Date:</strong> {{ $leaveData['end_date'] }}</div>
            <div><strong>Reason:</strong> {{ $leaveData['reason'] }}</div>
            <div><strong>Approval Date:</strong> {{ $leaveData['approved_date'] }}</div>
            <div><strong>Status:</strong> <span class="status">{{ $leaveData['status'] }}</span></div>
        </div>
        
        <p>Important Reminders:</p>
        <ul>
            <li>Please inform your room supervisor before leaving</li>
            <li>Ensure your room is clean and all electronics are turned off</li>
            <li>Return to the hostel by the end date mentioned above</li>
            <li>If you need an extension, submit a new leave request</li>
        </ul>
        
        <p>Have a safe journey!</p>
    </div>
    
    <div class="footer">
        <p>This is an automated message. Please do not reply to this email.</p>
        <p>&copy; {{ date('Y') }} Hostel Management System</p>
    </div>
</body>
</html>