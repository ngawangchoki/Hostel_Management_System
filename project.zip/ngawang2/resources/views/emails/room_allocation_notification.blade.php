<!DOCTYPE html>
<html>
<head>
    <title>Room Allocation Update</title>
</head>
<body>
    <h2>Hello {{ $student->first_name }} {{ $student->last_name }},</h2>

    <p>Your room allocation has been updated. Below are the details:</p>

    <table border="1" cellpadding="5" cellspacing="0" style="border-collapse: collapse;">
        <tr>
            <th>Student ID</th>
            <td>{{ $student->cid }}</td>
        </tr>
        <tr>
            <th>Name</th>
            <td>{{ $student->first_name }} {{ $student->last_name }}</td>
        </tr>
        <tr>
            <th>Gender</th>
            <td>{{ $student->gender }}</td>
        </tr>
        <tr>
            <th>Course</th>
            <td>{{ $student->course }}</td>
        </tr>
        <tr>
            <th>Block</th>
            <td>{{ $student->block_no }}</td>
        </tr>
        <tr>
            <th>Room Number</th>
            <td>{{ $student->room_no }}</td>
        </tr>
    </table>

    <p>If you have any questions, feel free to reach out to the hostel management team.</p>

    <br>
    <p>— Hostel Management System Team</p>
</body>
</html>
