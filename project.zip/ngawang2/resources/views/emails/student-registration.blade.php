?>

<html>
<head>
    <title>Hostel Registration {{ ucfirst($status) }}</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            line-height: 1.6;
            color: #333;
        }
        .container {
            max-width: 600px;
            margin: 0 auto;
            padding: 20px;
            border: 1px solid #ddd;
            border-radius: 5px;
        }
        .header {
            background-color: #28a745;
            color: white;
            padding: 10px;
            text-align: center;
            border-radius: 5px 5px 0 0;
        }
        .content {
            padding: 20px;
        }
        .footer {
            text-align: center;
            margin-top: 20px;
            font-size: 12px;
            color: #777;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 20px;
        }
        table, th, td {
            border: 1px solid #ddd;
        }
        th, td {
            padding: 10px;
            text-align: left;
        }
        th {
            background-color: #f2f2f2;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h2>Hostel Registration {{ ucfirst($status) }}</h2>
        </div>
        <div class="content">
            @if($status == 'pending')
                <p>Dear {{ $studentData->first_name }} {{ $studentData->last_name }},</p>
                <p>Thank you for submitting your hostel registration. Your registration is currently <strong>pending</strong> approval by the warden.</p>
                <p>Here is a summary of your registration information:</p>
            @else
                <p>Dear {{ $studentData->first_name }} {{ $studentData->last_name }},</p>
                <p>Good news! Your hostel registration has been <strong>approved</strong> by the warden.</p>
                <p>Here is a summary of your approved registration information:</p>
            @endif

            <table>
                <tr>
                    <th>CID</th>
                    <td>{{ $studentData->cid }}</td>
                </tr>
                <tr>
                    <th>Name</th>
                    <td>{{ $studentData->first_name }} {{ $studentData->last_name }}</td>
                </tr>
                <tr>
                    <th>Email</th>
                    <td>{{ $studentData->email }}</td>
                </tr>
                <tr>
                    <th>Phone</th>
                    <td>{{ $studentData->phone }}</td>
                </tr>
                <tr>
                    <th>Address</th>
                    <td>{{ $studentData->address }}</td>
                </tr>
                <tr>
                    <th>Gender</th>
                    <td>{{ ucfirst($studentData->gender) }}</td>
                </tr>
                <tr>
                    <th>Date of Birth</th>
                    <td>{{ date('F j, Y', strtotime($studentData->dob)) }}</td>
                </tr>
                <tr>
                    <th>Course</th>
                    <td>{{ $studentData->course }}</td>
                </tr>
                <tr>
                    <th>Status</th>
                    <td><strong>{{ ucfirst($status) }}</strong></td>
                </tr>
            </table>

            @if($status === 'pending')
        <p>Your hostel registration request has been received and is currently <strong>pending</strong>.</p>
    @elseif($status === 'approved')
        <p>Congratulations! Your hostel registration has been <strong>approved</strong>.</p>
    @endif

            <p>If you have any questions, please contact the hostel administration.</p>

            <p>Thank you,<br>Hostel Management Team</p>
        </div>
        <div class="footer">
            <p>This is an automated email. Please do not reply to this message.</p>
        </div>
    </div>
</body>
</html>
