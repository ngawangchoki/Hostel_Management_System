<!DOCTYPE html>
<html>
<head>
    <title>Feedback Submitted</title>
    <style>
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }
        table, th, td {
            border: 1px solid #ddd;
        }
        th, td {
            padding: 8px 12px;
            text-align: left;
        }
        th {
            background-color: #f4f4f4;
        }
    </style>
</head>
<body>
    <h2>Hello {{ $feedback->name }},</h2>

    <p>Thank you for your feedback regarding <strong>{{ $feedback->subject }}</strong>.</p>

    <p>Here’s a summary of your feedback:</p>

    <!-- Feedback Details in Table -->
    <table>
        <tr>
            <th>Subject</th>
            <td>{{ $feedback->subject }}</td>
        </tr>
        <tr>
            <th>Category</th>
            <td>{{ ucfirst($feedback->category) }}</td>
        </tr>
        <tr>
            <th>Message</th>
            <td>{{ $feedback->message }}</td>
        </tr>
        <tr>
            <th>Rating</th>
            <td>{{ $feedback->rating }} star(s)</td>
        </tr>
        <tr>
            <th>Date Submitted</th>
            <td>{{ $feedback->created_at->format('M d, Y') }}</td>
        </tr>
    </table>

    <p>We appreciate your input!</p>

    <br>
    <p>— Hostel Management System Team</p>
</body>
</html>
