@extends('components.layout')

@section('title')
Hostel Management System
@endsection

@section('span')
You are not logged in
@endsection

@section('log')
<a href="#" data-bs-toggle="modal" data-bs-target="#loginModal" class="text-white">(Login)</a>
@endsection

@section('content')
<!-- header -->
<header class="navbar navbar-expand-lg navbar-light">
    <div class="container-fluid d-flex flex-column align-items-center position-relative">
        <!-- Logo -->
        <a class="navbar-brand" href="#">
            <img src="{{ asset('images/logo.png') }}" alt="Hostel Management Logo" class="logo">
        </a>
    </div>
</header>
<link rel="stylesheet" href="{{ asset('css/style.css') }}">

<!-- Background Image Section -->
<div class="position-relative" style="height: 100vw; overflow: hidden;">
    <!-- Background Image without Blur -->
    <img src="{{ asset('images/rim_academic.jpg') }}" alt="Hostel Image" class="img-fluid position-absolute top-0 start-0 w-100 h-100" style="object-fit: cover; transition: filter 0.5s ease;" id="backgroundImage">
    
    <!-- Overlay to make text more visible with transparency -->
    <div class="position-absolute top-0 start-0 w-100 h-100" style="background: rgba(0, 0, 0, 0.3);"></div>

    <!-- Main Content (Centered text) -->
    <div class="position-absolute top-50 start-50 translate-middle text-center text-white" style="z-index: 1;">
        <h3>Welcome to the Hostel Management System</h3>
        <p>Please select an option below:</p>

        <!-- Cards for various options -->
        <div class="row justify-content-center">
            <!-- Hostel Registration Card -->
            <div class="col-md-4 mb-4">
                <div class="card bg-transparent border-0 text-white hover-effect" onmouseover="blurBackground()" onmouseout="unblurBackground()">
                    <div class="card-body text-center">
                        <i class="fas fa-home fa-4x mb-3"></i>
                        <h5 class="card-title">Hostel Registration</h5>
                        <p class="card-text">Register for hostel accommodation.</p>
                        <a href="#" data-bs-toggle="modal" data-bs-target="#loginModal" class="btn btn-outline-light btn-sm">Register Now</a>
                    </div>
                </div>
            </div>

            <!-- Leave Application Card -->
            <div class="col-md-4 mb-4">
                <div class="card bg-transparent border-0 text-white hover-effect" onmouseover="blurBackground()" onmouseout="unblurBackground()">
                    <div class="card-body text-center">
                        <i class="fas fa-calendar-alt fa-4x mb-3"></i>
                        <h5 class="card-title">Leave Application</h5>
                        <p class="card-text">Apply for leave from the hostel.</p>
                        <a href="#" data-bs-toggle="modal" data-bs-target="#loginModal" class="btn btn-outline-light btn-sm">Apply Now</a>
                    </div>
                </div>
            </div>

            <!-- Generate Reports Card -->
            <div class="col-md-4 mb-4">
                <div class="card bg-transparent border-0 text-white hover-effect" onmouseover="blurBackground()" onmouseout="unblurBackground()">
                    <div class="card-body text-center">
                        <i class="fas fa-file-alt fa-4x mb-3"></i>
                        <h5 class="card-title">Generate Reports</h5>
                        <p class="card-text">Generate reports.</p>
                        <a href="#" data-bs-toggle="modal" data-bs-target="#loginModal" class="btn btn-outline-light btn-sm">Generate Reports</a>
                    </div>
                </div>
            </div>

            <!-- Feedback Card -->
            <div class="col-md-4 mb-4">
                <div class="card bg-transparent border-0 text-white hover-effect" onmouseover="blurBackground()" onmouseout="unblurBackground()">
                    <div class="card-body text-center">
                        <i class="fas fa-comment-dots fa-4x mb-3"></i>
                        <h5 class="card-title">Feedback</h5>
                        <p class="card-text">Share your feedback with us.</p>
                        <a href="#" data-bs-toggle="modal" data-bs-target="#loginModal" class="btn btn-outline-light btn-sm">Submit Feedback</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Show error message when login fails --> -->
 @if(session('error'))
<script>
    document.addEventListener('DOMContentLoaded', function () {
        alert("{{ session('error') }}");
    });
</script> 

<!-- @endif -->
<!-- @if(session('error'))
    <div class="alert alert-danger">
        {{ session('error') }}
    </div>
@endif -->


<!-- Modal for Login -->
<div class="modal fade" id="loginModal" tabindex="-1" aria-labelledby="loginModalLabel" aria-hidden="true">

    <div class="modal-dialog modal-dialog-centered" style="max-width: 350px;">
        <div class="modal-content" style="border-radius: 10px; overflow: hidden;">
            <!-- Modal Header -->
            <div class="modal-header text-white" style="background: rgba(53, 141, 53, 0.89);">
                <h5 class="modal-title" id="loginModalLabel">Login to access more!</h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <!-- Modal Body -->
            <div class="modal-body">
                <form action="{{ route('login') }}" method="POST">
                    @csrf
                    <div class="mb-2" style="max-width: 250px; margin: 0 auto;">
                    
                        <label for="role" class="form-label">Role</label>
                        <select class="form-select form-select-sm" id="role" name="role" required>
                            <option value="warden">Warden</option>
                            <option value="hr">HR</option>
                            <option value="student">Student</option>
                        </select>
                    </div>
                    <div class="mb-2" style="max-width: 250px; margin: 0 auto;">
                        <label for="username" class="form-label">Username</label>
                        <div class="input-group input-group-sm">
                            <span class="input-group-text"><i class="fas fa-user"></i></span>
                            <input type="text" class="form-control form-control-sm" id="username" name="username" placeholder="Username" required>
                        </div>
                    </div>
                    <div class="mb-2" style="max-width: 250px; margin: 0 auto;">
                        <label for="password" class="form-label">Password</label>
                        <div class="input-group input-group-sm">
                            <span class="input-group-text"><i class="fas fa-lock"></i></span>
                            <input type="password" class="form-control form-control-sm" id="password" name="password" placeholder="Password" required>
                        </div>
                    </div>
                    <div class="d-grid" style="max-width: 250px; margin: 0 auto;">
                        <button type="submit" class="btn btn-primary btn-sm" style="background: rgba(67, 116, 67, 0.95); border: none;">
                            <i class="fas fa-sign-in-alt me-1"></i> Login
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

@endsection

<link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css" rel="stylesheet">
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>

<script>
    function blurBackground() {
        document.getElementById('backgroundImage').style.filter = 'blur(4px)';
    }

    function unblurBackground() {
        document.getElementById('backgroundImage').style.filter = 'blur(0)';
    }

    document.addEventListener('DOMContentLoaded', function () {
        document.getElementById('role').addEventListener('change', function() {
            const usernameField = document.getElementById('username');
            const passwordField = document.getElementById('password');
            if (this.value === 'student') {
                usernameField.value = 'sonam';
                passwordField.value = 'sonam';
            } else {
                usernameField.value = '';
                passwordField.value = '';
            }
        });
    });
</script>
