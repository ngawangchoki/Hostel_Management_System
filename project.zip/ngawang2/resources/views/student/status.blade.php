@extends('components.layout')

@section('title')
    leaveStatus
@endsection

@section('span')
    You are logged in
@endsection

@section('log')
    <a href="#" data-bs-toggle="modal" data-bs-target="#loginModal" class="text-white">(Logout)</a>
@endsection

@section('content')
<header class="navbar navbar-expand-lg">
    <div class="container-fluid d-flex justify-content-between align-items-center position-relative">
        <!-- Logo -->
        <a class="navbar-brand" href="#">
            <img src="{{ asset('images/logo.png') }}" alt="Hostel Management Logo" class="logo">
        </a>
        <!-- Text Under Logo -->
        <div class="text-white">
            <span>You are logged in</span>
        </div>
    </div>
</header>

<!-- External CSS -->
<link rel="stylesheet" href="{{ asset('css/studentreg_style.css') }}">

<div class="container">
    <h3 class="text-center text-primary mb-4">Leave Form Status</h3>

    @if(session('cid'))
        <p>Welcome, Student with CID: {{ session('cid') }}</p>

        @if($leaveRequests->isEmpty())
            <p class="text-center">No leave requests found.</p>
        @else
            @php
                $sortedLeaves = $leaveRequests->sortByDesc('leave_start_date');
            @endphp
            <table class="table table-bordered">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>CID</th>
                        <th>Leave Start Date</th>
                        <th>Leave End Date</th>
                        <th>Reason</th>
                        <th>Status</th>
                    </tr>
                </thead>
                <tbody>
                    @foreach($sortedLeaves as $leave)
                        <tr>
                            <td>{{ $leave->id }}</td>
                            <td>{{ $leave->cid }}</td>
                            <td>{{ $leave->leave_start_date }}</td>
                            <td>{{ $leave->leave_end_date }}</td>
                            <td>{{ $leave->leave_reason }}</td>
                            <td>
                                @if($leave->status === 'approved')
                                    <span class="badge bg-success">Approved</span>
                                    <form action="{{ route('leave.cancel', $leave->id) }}" method="POST" class="d-inline-block mt-1">
                                        @csrf
                                        <input type="hidden" name="cid" value="{{ session('cid') }}">
                                        <input type="text" name="cancel_message" placeholder="Reason for cancellation" required class="form-control mb-1">
                                        <button type="submit" class="btn btn-sm btn-danger">Cancel Leave</button>
                                    </form>
                                @elseif($leave->status === 'disapproved')
                                    <span class="badge bg-danger">Disapproved</span>
                                @elseif($leave->status === 'cancelled')
                                    <span class="badge bg-secondary">Cancelled</span>
                                @else
                                    <span class="badge bg-warning">Pending</span>
                                @endif
                            </td>
                            
                            
                            

                        </tr>
                    @endforeach
                </tbody>
            </table>
        @endif
    @else
        <p>No CID found in session.</p>
    @endif
</div>
@endsection
