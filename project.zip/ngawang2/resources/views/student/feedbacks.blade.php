@extends('components.layout')

@section('title')
Student Dashboard
@endsection

@section('span')
You are logged in
@endsection

@section('log')
<a href="#" data-bs-toggle="modal" data-bs-target="#loginModal" class="text-white">(Logout)</a>
@endsection

@section('content')
<header class="navbar navbar-expand-lg">
    <div class="container-fluid d-flex justify-content-between align-items-center position-relative">
        <!-- Logo -->
        <a class="navbar-brand" href="#">
            <img src="{{ asset('images/logo.png') }}" alt="Hostel Management Logo" class="logo">
        </a>
        <!-- Text Under Logo -->
        <div class="text-white">
            <span>You are logged in     {{ session('cid') }}</span>
        </div>
    </div>
</header>

<!-- External CSS -->
<link rel="stylesheet" href="{{ asset('css/studentreg_style.css') }}">

<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-10">
            <div class="card">
                <div class="card-header">
                    <h2>Feedback Management</h2>
                </div>
                <div class="card-body">
                    @if(session('success'))
                        <div class="alert alert-success">
                            {{ session('success') }}
                        </div>
                    @endif

                    <!-- Feedback Form -->
                    <div class="mb-5">
                        <h3>Submit New Feedback</h3>
                        <form method="POST" action="{{ route('feedbacks.store') }}">
                            @csrf
                            <div class="form-group mb-3">
                                <label for="name">Your Name</label>
                                <input type="text" class="form-control @error('name') is-invalid @enderror" id="name" name="name" value="{{ old('name') }}" required>
                                @error('name')
                                    <span class="invalid-feedback" role="alert">
                                        <strong>{{ $message }}</strong>
                                    </span>
                                @enderror
                            </div>

                            <div class="form-group mb-3">
                                <label for="email">Email Address</label>
                                <input type="email" class="form-control @error('email') is-invalid @enderror" id="email" name="email" value="{{ old('email') }}" required>
                                @error('email')
                                    <span class="invalid-feedback" role="alert">
                                        <strong>{{ $message }}</strong>
                                    </span>
                                @enderror
                            </div>

                            <div class="form-group mb-3">
                                <label for="subject">Subject</label>
                                <input type="text" class="form-control @error('subject') is-invalid @enderror" id="subject" name="subject" value="{{ old('subject') }}" required>
                                @error('subject')
                                    <span class="invalid-feedback" role="alert">
                                        <strong>{{ $message }}</strong>
                                    </span>
                                @enderror
                            </div>

                            <div class="form-group mb-3">
                                <label for="category">Category</label>
                                <select class="form-control @error('category') is-invalid @enderror" id="category" name="category" required>
                                    <option value="">Select a category</option>
                                    <option value="general" {{ old('category') == 'general' ? 'selected' : '' }}>General</option>
                                    <option value="suggestion" {{ old('category') == 'suggestion' ? 'selected' : '' }}>Suggestion</option>
                                    <option value="complaint" {{ old('category') == 'complaint' ? 'selected' : '' }}>Complaint</option>
                                    <option value="bug" {{ old('category') == 'bug' ? 'selected' : '' }}>Bug Report</option>
                                    <option value="praise" {{ old('category') == 'praise' ? 'selected' : '' }}>Praise</option>
                                </select>
                                @error('category')
                                    <span class="invalid-feedback" role="alert">
                                        <strong>{{ $message }}</strong>
                                    </span>
                                @enderror
                            </div>

                            <div class="form-group mb-3">
                                <label for="message">Your Feedback</label>
                                <textarea class="form-control @error('message') is-invalid @enderror" id="message" name="message" rows="5" required>{{ old('message') }}</textarea>
                                @error('message')
                                    <span class="invalid-feedback" role="alert">
                                        <strong>{{ $message }}</strong>
                                    </span>
                                @enderror
                            </div>

                            <div class="form-group mb-3">
                                <label for="rating">Rating</label>
                                <div class="rating">
                                    @for ($i = 5; $i >= 1; $i--)
                                        <input type="radio" id="star{{ $i }}" name="rating" value="{{ $i }}" {{ old('rating') == $i ? 'checked' : '' }} />
                                        <label for="star{{ $i }}">{{ $i }} stars</label>
                                    @endfor
                                </div>
                                @error('rating')
                                    <span class="invalid-feedback d-block" role="alert">
                                        <strong>{{ $message }}</strong>
                                    </span>
                                @enderror
                            </div>

                            <button type="submit" class="btn btn-primary">Submit Feedback</button>
                        </form>
                    </div>

                    <!-- Feedback Listing (Admin only) -->
                    @auth
                        @if(auth()->user()->iswarden())
                            <div class="mt-5">
                                <h3>Recent Feedback</h3>
                                
                                @if(isset($feedbacks) && count($feedbacks) > 0)
                                    <div class="table-responsive">
                                        <table class="table table-striped">
                                            <thead>
                                                <tr>
                                                    <th>ID</th>
                                                    <th>Name</th>
                                                    <th>Email</th>
                                                    <th>Subject</th>
                                                    <th>Category</th>
                                                    <th>Rating</th>
                                                    <th>Date</th>
                                                    <th>Actions</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                @foreach($feedbacks as $feedback)
                                                    <tr>
                                                        <td>{{ $feedback->id }}</td>
                                                        <td>{{ $feedback->name }}</td>
                                                        <td>{{ $feedback->email }}</td>
                                                        <td>{{ $feedback->subject }}</td>
                                                        <td>
                                                            <span class="badge 
                                                                {{ $feedback->category == 'complaint' ? 'bg-danger' : '' }}
                                                                {{ $feedback->category == 'suggestion' ? 'bg-info' : '' }}
                                                                {{ $feedback->category == 'bug' ? 'bg-warning' : '' }}
                                                                {{ $feedback->category == 'praise' ? 'bg-success' : '' }}
                                                                {{ $feedback->category == 'general' ? 'bg-secondary' : '' }}
                                                            ">
                                                                {{ ucfirst($feedback->category) }}
                                                            </span>
                                                        </td>
                                                        <td>
                                                            @for($i = 1; $i <= 5; $i++)
                                                                @if($i <= $feedback->rating)
                                                                    <i class="fas fa-star text-warning"></i>
                                                                @else
                                                                    <i class="far fa-star"></i>
                                                                @endif
                                                            @endfor
                                                        </td>
                                                        <td>{{ $feedback->created_at->format('M d, Y') }}</td>
                                                        <td>
                                                            <div class="btn-group" role="group">
                                                                <a href="{{ route('feedbacks.show', $feedback->id) }}" class="btn btn-sm btn-info">
                                                                    <i class="fas fa-eye"></i> View
                                                                </a>
                                                                
                                                                @if(!$feedback->is_resolved)
                                                                    <form action="{{ route('feedbacks.resolve', $feedback->id) }}" method="POST">
                                                                        @csrf
                                                                        @method('PATCH')
                                                                        <button type="submit" class="btn btn-sm btn-success">
                                                                            <i class="fas fa-check"></i> Mark Resolved
                                                                        </button>
                                                                    </form>
                                                                @else
                                                                    <button type="button" class="btn btn-sm btn-secondary" disabled>
                                                                        <i class="fas fa-check-double"></i> Resolved
                                                                    </button>
                                                                @endif
                                                                
                                                                <form action="{{ route('feedbacks.destroy', $feedback->id) }}" method="POST" onsubmit="return confirm('Are you sure you want to delete this feedback?');">
                                                                    @csrf
                                                                    @method('DELETE')
                                                                    <button type="submit" class="btn btn-sm btn-danger">
                                                                        <i class="fas fa-trash"></i> Delete
                                                                    </button>
                                                                </form>
                                                            </div>
                                                        </td>
                                                    </tr>
                                                @endforeach
                                            </tbody>
                                        </table>
                                    </div>
                                    
                                    <div class="d-flex justify-content-center">
                                        {{ $feedbacks->links() }}
                                    </div>
                                @else
                                    <div class="alert alert-info">
                                        No feedback submissions found.
                                    </div>
                                @endif
                            </div>
                        @endif
                    @endauth
                </div>
            </div>
        </div>
    </div>
</div>

<style>
.rating {
    display: flex;
    flex-direction: row-reverse;
    justify-content: flex-end;
}
.rating:not(:checked) > input {
    position: absolute;
    clip: rect(0,0,0,0);
}
.rating:not(:checked) > label {
    float: right;
    width: 1em;
    padding: 0 .1em;
    overflow: hidden;
    white-space: nowrap;
    cursor: pointer;
    font-size: 1.5em;
    line-height: 1.2;
    color: #ddd;
}
.rating:not(:checked) > label:before {
    content: '★ ';
}
.rating > input:checked ~ label {
    color: #ffbb00;
}
.rating:not(:checked) > label:hover,
.rating:not(:checked) > label:hover ~ label {
    color: #ffcc44;
}
.rating > input:checked + label:hover,
.rating > input:checked + label:hover ~ label,
.rating > input:checked ~ label:hover,
.rating > input:checked ~ label:hover ~ label,
.rating > label:hover ~ input:checked ~ label {
    color: #ffdd66;
}
</style>
@endsection

@push('scripts')
<script>
    document.addEventListener('DOMContentLoaded', function() {
        // Any JavaScript needed for the feedback form
        console.log('Feedback form loaded');
    });
</script>
@endpush