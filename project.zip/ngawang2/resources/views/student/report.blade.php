@extends('components.layout')

@section('title')
Student Reports
@endsection

@section('span')
You are logged in
@endsection

@section('log')
<a href="#" data-bs-toggle="modal" data-bs-target="#loginModal" class="text-white">(Logout)</a>
@endsection

@section('content')
<header class="navbar navbar-expand-lg">
    <div class="container-fluid d-flex justify-content-between align-items-center position-relative">
        <!-- Logo -->
        <a class="navbar-brand" href="#">
            <img src="{{ asset('images/logo.png') }}" alt="Hostel Management Logo" class="logo">
        </a>
        <!-- Text Under Logo -->
        <div class="text-white">
            <span>You are logged in {{ session('cid') }}</span>
        </div>
    </div>
</header>

<!-- External CSS -->
<link rel="stylesheet" href="{{ asset('css/studentreg_style.css') }}">

<div class="d-flex" style="min-height: 100vh;">
    <!-- Sidebar -->
    <div class="sidebar bg-success text-white p-4" style="width: 250px; height: 100vh; box-shadow: 2px 0 10px rgba(0,0,0,0.1); position: sticky;">
        <h4 class="text-center text-white mb-4">Student Dashboard</h4>
        <ul class="list-unstyled">
            <li>
                <a href="{{ route('student.dashboard') }}" class="text-white sidebar-link py-2 d-block px-3 rounded mb-2">
                    <i class="bi bi-person-plus"></i> Student Registration
                </a>
            </li>
            <li>
                <a href="{{ route('student.dashboard') }}" class="text-white sidebar-link py-2 d-block px-3 rounded mb-2">
                    <i class="bi bi-file-earmark-text"></i> Leave Form
                </a>
            </li>
            <li>
                <a href="{{ route('feedbacks') }}" class="text-white sidebar-link py-2 d-block px-3 rounded mb-2">
                    <i class="bi bi-chat-left-text"></i> Feedback
                </a>
            </li>
            
            <li>
                <a href="{{ route('studentreport') }}" class="text-white sidebar-link py-2 d-block px-3 rounded mb-2 active">
                    <i class="bi bi-bar-chart-line"></i> Reports
                </a>
            </li>
            <!-- Status Dropdown -->
            <li class="nav-item dropdown">
                <a class="nav-link dropdown-toggle text-white" href="#" id="statusDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                    <i class="bi bi-bar-chart-line"></i> Status
                </a>
            </li>
            <li>
                <a href="{{ route('student.hostel-registration-status') }}" class="text-white sidebar-link py-2 d-block px-3 rounded mb-2">
                    Hostel Registration Status
                </a>
            </li>
            <li>
                <a href="{{ route('student.status') }}" class="text-white sidebar-link py-2 d-block px-3 rounded mb-2">
                    Leave Form Status
                </a>
            </li>
        </ul>
    </div>

    <!-- Main Content -->
    <div class="main-content p-4" style="flex-grow: 1;">
        <div class="container">
            <h3 class="mb-4 text-center text-primary">Student Reports</h3>
            
            @if(session('success'))
                <div class="alert alert-success">
                    {{ session('success') }}
                </div>
            @endif

            @if(session('error'))
                <div class="alert alert-danger">
                    {{ session('error') }}
                </div>
            @endif

            <!-- Report Filters with Toggle -->
            <div class="card mb-4">
                <div class="card-header bg-light">
                    <h5 class="mb-0">View Reports</h5>
                </div>
                <div class="card-body">
                    <form action="{{ route('studentreport') }}" method="GET" class="row g-3">
                        <!-- Toggle Buttons -->
                        <div class="col-12 mb-3">
                            <div class="btn-group w-100" role="group" aria-label="Report Type Toggle">
                                <input type="radio" class="btn-check" name="report_type" id="attendanceToggle" value="attendance" {{ request('report_type', 'attendance') == 'attendance' ? 'checked' : '' }}>
                                <label class="btn btn-outline-primary" for="attendanceToggle">Attendance Reports</label>
                                
                                <input type="radio" class="btn-check" name="report_type" id="leaveToggle" value="leave" {{ request('report_type') == 'leave' ? 'checked' : '' }}>
                                <label class="btn btn-outline-primary" for="leaveToggle">Leave Reports</label>
                            </div>
                        </div>
                        
                        <div class="col-md-5">
                            <label for="start_date" class="form-label">Start Date</label>
                            <input type="date" class="form-control" id="start_date" name="start_date" value="{{ request('start_date') }}">
                        </div>
                        <div class="col-md-5">
                            <label for="end_date" class="form-label">End Date</label>
                            <input type="date" class="form-control" id="end_date" name="end_date" value="{{ request('end_date') }}">
                        </div>
                        <div class="col-md-2 d-flex align-items-end">
                            <button type="submit" class="btn btn-primary w-100">Apply Filters</button>
                        </div>
                        <div class="col-12 text-end mt-3">
                            <button type="button" class="btn btn-success" id="exportBtn">
                                <i class="bi bi-download me-1"></i> Export to CSV
                            </button>
                        </div>
                    </form>
                </div>
            </div>

            <!-- Report Results -->
            <div class="card">
                <div class="card-header bg-light d-flex justify-content-between align-items-center">
                    <h5 class="mb-0">
                        {{ request('report_type', 'attendance') == 'attendance' ? 'Attendance History' : 'Leave History' }}
                    </h5>
                    <span class="badge bg-primary">
                        {{ request('report_type', 'attendance') == 'attendance' ? 'Attendance' : 'Leave' }}
                    </span>
                </div>
                <div class="card-body">
                    <!-- Attendance Report Content - Show when attendance toggle is active -->
                    <div id="attendanceContent" class="{{ request('report_type', 'attendance') == 'attendance' ? '' : 'd-none' }}">
                        <div class="table-responsive">
                            <table class="table table-hover table-striped" id="attendanceTable">
                                <thead class="table-dark">
                                    <tr>
                                        <th>ID</th>
                                        <th>Allocation ID</th>
                                        <th>Student ID</th>
                                        <th>Block</th>
                                        <th>Room</th>
                                        <th>Date</th>
                                        <th>Status</th>
                                        <th>Remarks</th>
                                        <th>Created At</th>
                                        <th>Updated At</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    @if(isset($attendanceData) && $attendanceData->count() > 0)
                                        @foreach($attendanceData as $attendance)
                                            <tr>
                                                <td>{{ $attendance->id }}</td>
                                                <td>{{ $attendance->allocation_id }}</td>
                                                <td>{{ $attendance->cid }}</td>
                                                <td>{{ $attendance->block_no }}</td>
                                                <td>{{ $attendance->room_no }}</td>
                                                <td>{{ date('Y-m-d', strtotime($attendance->attendance_date)) }}</td>
                                                <td>
                                                    <span class="badge {{ $attendance->status == 'Present' ? 'bg-success' : ($attendance->status == 'Absent' ? 'bg-danger' : 'bg-warning') }}">
                                                        {{ $attendance->status }}
                                                    </span>
                                                </td>
                                                <td>{{ $attendance->remarks ?? 'N/A' }}</td>
                                                <td>{{ $attendance->created_at }}</td>
                                                <td>{{ $attendance->updated_at }}</td>
                                            </tr>
                                        @endforeach
                                    @else
                                        <tr>
                                            <td colspan="10" class="text-center">No attendance records found</td>
                                        </tr>
                                    @endif
                                </tbody>
                            </table>
                        </div>
                    </div>

                    <!-- Leave History Content - Show when leave toggle is active -->
                    <div id="leaveContent" class="{{ request('report_type') == 'leave' ? '' : 'd-none' }}">
                        <div class="table-responsive">
                            <table class="table table-hover table-striped" id="leavesTable">
                                <thead class="table-dark">
                                    <tr>
                                        <th>ID</th>
                                        <th>Student ID</th>
                                        <th>From Date</th>
                                        <th>To Date</th>
                                        <th>Status</th>
                                        <th>Acknowledged</th>
                                        <th>Cancel Message</th>
                                        <th>Reason</th>
                                        <th>Created At</th>
                                        <th>Updated At</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    @if(isset($leaveData) && $leaveData->count() > 0)
                                        @foreach($leaveData as $leave)
                                            <tr>
                                                <td>{{ $leave->id }}</td>
                                                <td>{{ $leave->cid }}</td>
                                                <td>{{ date('Y-m-d', strtotime($leave->leave_start_date)) }}</td>
                                                <td>{{ date('Y-m-d', strtotime($leave->leave_end_date)) }}</td>
                                                <td>
                                                    <span class="badge {{ $leave->status == 'Approved' ? 'bg-success' : ($leave->status == 'Pending' ? 'bg-warning' : 'bg-danger') }}">
                                                        {{ $leave->status }}
                                                    </span>
                                                </td>
                                                <td>
                                                    <span class="badge {{ $leave->acknowledged ? 'bg-success' : 'bg-secondary' }}">
                                                        {{ $leave->acknowledged ? 'Yes' : 'No' }}
                                                    </span>
                                                </td>
                                                <td>{{ $leave->cancel_message ?? 'N/A' }}</td>
                                                <td>{{ $leave->leave_reason }}</td>
                                                <td>{{ $leave->created_at }}</td>
                                                <td>{{ $leave->updated_at }}</td>
                                            </tr>
                                        @endforeach
                                    @else
                                        <tr>
                                            <td colspan="10" class="text-center">No leave records found</td>
                                        </tr>
                                    @endif
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- JavaScript for report interaction -->
<script>
    document.addEventListener('DOMContentLoaded', function() {
        // Toggle functionality
        const attendanceToggle = document.getElementById('attendanceToggle');
        const leaveToggle = document.getElementById('leaveToggle');
        const attendanceContent = document.getElementById('attendanceContent');
        const leaveContent = document.getElementById('leaveContent');
        
        if (attendanceToggle && leaveToggle) {
            attendanceToggle.addEventListener('change', function() {
                if (this.checked) {
                    attendanceContent.classList.remove('d-none');
                    leaveContent.classList.add('d-none');
                }
            });
            
            leaveToggle.addEventListener('change', function() {
                if (this.checked) {
                    leaveContent.classList.remove('d-none');
                    attendanceContent.classList.add('d-none');
                }
            });
        }
        
        // Validate date range
        const startDateInput = document.getElementById('start_date');
        const endDateInput = document.getElementById('end_date');
        
        if (startDateInput && endDateInput) {
            endDateInput.addEventListener('change', function() {
                if (startDateInput.value && endDateInput.value) {
                    if (new Date(endDateInput.value) < new Date(startDateInput.value)) {
                        alert('End date cannot be earlier than start date');
                        endDateInput.value = '';
                    }
                }
            });
        }
        
        // Export button functionality
        const exportBtn = document.getElementById('exportBtn');
        if (exportBtn) {
            exportBtn.addEventListener('click', function() {
                // Get current form data
                const form = document.querySelector('form');
                const formData = new FormData(form);
                const params = new URLSearchParams(formData).toString();
                
                // Redirect to export route with current filters
                window.location.href = "{{ route('export.report') }}?" + params;
            });
        }
    });
</script>
@endsection