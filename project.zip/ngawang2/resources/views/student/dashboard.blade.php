@extends('components.layout')

@section('title')
Student Dashboard
@endsection

@section('span')
You are logged in
@endsection

@section('log')
<a href="#" data-bs-toggle="modal" data-bs-target="#loginModal" class="text-white">(Logout)</a>
@endsection

@section('content')
<header class="navbar navbar-expand-lg">
    <div class="container-fluid d-flex justify-content-between align-items-center position-relative">
        <!-- Logo -->
        <a class="navbar-brand" href="#">
            <img src="{{ asset('images/logo.png') }}" alt="Hostel Management Logo" class="logo">
        </a>
        <!-- Text Under Logo -->
        <div class="text-white">
            <span>You are logged in     {{ session('cid') }}</span>
        </div>
    </div>
</header>

<!-- External CSS -->
<link rel="stylesheet" href="{{ asset('css/studentreg_style.css') }}">

<div class="d-flex" style="min-height: 100vh;">
    <!-- Sidebar (Unchanged) -->
    <!-- Sidebar -->
<div class="sidebar bg-success text-white p-4" style="width: 250px; height: 100vh; box-shadow: 2px 0 10px rgba(0,0,0,0.1); position: sticky;">
    <h4 class="text-center text-white mb-4">Student Dashboard</h4>
    <ul class="list-unstyled">
        <li>
            <a href="#" onclick="showSection('studentRegistration')" class="text-white sidebar-link py-2 d-block px-3 rounded mb-2">
                <i class="bi bi-person-plus"></i> Student Registration
            </a>
        </li>
        <li>
            <a href="#" onclick="showSection('leaveFormSection')" class="text-white sidebar-link py-2 d-block px-3 rounded mb-2">
                <i class="bi bi-file-earmark-text"></i> Leave Form
            </a>
        </li>
        <li>
            <a href="{{ route('feedbacks') }}" class="text-white sidebar-link py-2 d-block px-3 rounded mb-2">
                <i class="bi bi-chat-left-text"></i> Feedback
            </a>
        </li>
        
        <li>
            <a href="{{ route('student.report') }}" class="text-white sidebar-link py-2 d-block px-3 rounded mb-2">
                <i class="bi bi-bar-chart-line"></i> Reports
            </a>
        </li>
        <!-- Status Dropdown -->
        <li class="nav-item dropdown">
            <a class="nav-link dropdown-toggle text-white" href="#" id="statusDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                <i class="bi bi-bar-chart-line"></i> Status
            </a>
           
        </li>
        <li>
        <a href="{{ route('student.hostel-registration-status') }}"class="text-white sidebar-link py-2 d-block px-3 rounded mb-2">Hostel Registration Status</a>
            </a>
        </li>
        <!-- Student Dashboard Sidebar or Navbar -->
<ul class="list-group >
    <li class="list-group-item" >
        <a href="{{ route('student.status') }}"class="text-white sidebar-link py-2 d-block px-3 rounded mb-2">Leave Form Status</a>
    </li>
    <!-- Add other dashboard links here -->
</ul>

    </ul>
</div>



    <!-- Main Content -->
    <div class="main-content p-4" style="flex-grow: 1;">
        <!-- Success Message -->
        @if(session('success'))
            <div class="alert alert-success">
                {{ session('success') }}
            </div>
        @endif

        <!-- Student Registration Form (Initially hidden) -->
        <!-- Student Registration Form (Initially hidden) -->
<div id="studentRegistration" class="section d-none">
    <h3 class="mb-4 text-center text-primary">Student Registration</h3>
    <form action="{{ route('student.register') }}" method="POST">
        @csrf
        <!-- CID - Pre-filled with logged in user's CID and made read-only -->
        <div class="mb-3">
            <label for="cid" class="form-label">Citizen ID (CID)</label>
            <input type="text" class="form-control form-control-sm" id="cid" name="cid" value="{{ session('cid') }}" readonly>
        </div>
        <div class="row">
            <!-- First Name -->
            <div class="col-md-2">
                <div class="mb-3">
                    <label for="first_name" class="form-label">First Name</label>
                    <input type="text" class="form-control form-control-sm" id="first_name" name="first_name" required>
                </div>
            </div>
            <!-- Last Name -->
            <div class="col-md-2">
                <div class="mb-3">
                    <label for="last_name" class="form-label">Last Name</label>
                    <input type="text" class="form-control form-control-sm" id="last_name" name="last_name" required>
                </div>
            </div>
        </div>
        <!-- Rest of the form remains unchanged -->
        <!-- Email -->
        <div class="mb-3">
            <label for="email" class="form-label">Email</label>
            <input type="email" class="form-control form-control-sm @error('email') is-invalid @enderror" id="email" name="email" value="{{ old('email') }}" required>
            @error('email')
                <div class="invalid-feedback">{{ $message }}</div>
            @enderror
        </div>
        
        <div class="mb-3">
            <label for="phone" class="form-label">Phone Number</label>
            <input type="text" class="form-control form-control-sm @error('phone') is-invalid @enderror" id="phone" name="phone" value="{{ old('phone') }}" required>
            @error('phone')
                <div class="invalid-feedback">{{ $message }}</div>
            @enderror
            <small class="text-muted">Phone number must start with 17 or 77 and be 8 digits long.</small>
        </div>
        <!-- Address -->
        <div class="mb-3">
            <label for="address" class="form-label">Address</label>
            <textarea class="form-control form-control-sm" id="address" name="address" rows="3" required></textarea>
        </div>
        <!-- Gender -->
        <div class="mb-3">
            <label for="gender" class="form-label">Gender</label>
            <select class="form-control form-control-sm" id="gender" name="gender" required>
                <option value="male">Male</option>
                <option value="female">Female</option>
                <option value="other">Other</option>
            </select>
        </div>
        <!-- Date of Birth -->
        <div class="mb-3">
            <label for="dob" class="form-label">Date of Birth</label>
            <input type="date" class="form-control form-control-sm @error('dob') is-invalid @enderror" id="dob" name="dob" value="{{ old('dob') }}" required>
            @error('dob')
                <div class="invalid-feedback">{{ $message }}</div>
            @enderror
            <small class="text-muted">You must be at least 18 years old to register.</small>
        </div>
        <!-- Course (Dropdown) -->
        <div class="mb-3">
            <label for="course" class="form-label">Course</label>
            <select class="form-control form-control-sm" id="course" name="course" required>
                <option value="DIT">DIT</option>
                <option value="DFM">DFM</option>
                <option value="FIT">FIT</option>
                <option value="CIA">CIA</option>
                <option value="GDA">GDA</option>
            </select>
        </div>
        <!-- Submit Button for Registration -->
        <div class="text-center">
            <button type="submit" class="btn btn-success btn-sm">Register</button>
        </div>
    </form>
    
</div>
       <!-- Leave Form Section (Initially hidden) -->
<div id="leaveFormSection" class="section d-none">
    <h3 class="mb-4 text-center text-primary">Leave Form</h3>
    
    <!-- Check if student registration is approved -->
    @php
        $studentApproved = false;
        // Retrieve student registration status from database using session CID
        if(session('cid')) {
            $student = \App\Models\Student::where('cid', session('cid'))->first();
            $studentApproved = $student && $student->status === 'approved';
        }
        // Get current date in YYYY-MM-DD format for the min attribute
        $currentDate = date('Y-m-d');
    @endphp

    @if($studentApproved)
        <!-- Display leave form only if registration is approved -->
        <form action="{{ route('leave.store') }}" method="POST" id="leaveForm">
            @csrf
            <!-- Pre-filled with logged in user's CID and made read-only -->
            <div class="mb-3">
                <label for="cid_input" class="form-label">Citizen ID (CID)</label>
                <input type="text" class="form-control form-control-sm" id="cid_input" name="cid" value="{{ session('cid') }}" readonly>
            </div>

            <!-- Leave form fields -->
            <div class="mb-3">
                <label for="leave_start_date" class="form-label">Leave From</label>
                <input type="date" class="form-control form-control-sm" id="leave_start_date" name="leave_start_date" min="{{ $currentDate }}" value="{{ $currentDate }}" required>
                <small class="text-muted">Leave requests can only be made from today onwards.</small>
            </div>

            <div class="mb-3">
                <label for="leave_end_date" class="form-label">Leave Till</label>
                <input type="date" class="form-control form-control-sm" id="leave_end_date" name="leave_end_date" min="{{ $currentDate }}" required>
                <div id="dateError" class="invalid-feedback d-none">End date must be after or equal to start date.</div>
            </div>
            
            <div class="mb-3">
                <label for="leave_reason" class="form-label">Reason for Leave</label>
                <textarea class="form-control form-control-sm" id="leave_reason" name="leave_reason" rows="3" required></textarea>
            </div>

            <!-- Submit Button -->
            <div class="text-center">
                <button type="submit" class="btn btn-success btn-sm">Submit Leave Request</button>
            </div>
        </form>

        <!-- Add JavaScript validation -->
        <script>
            document.addEventListener('DOMContentLoaded', function() {
                const leaveForm = document.getElementById('leaveForm');
                const startDateInput = document.getElementById('leave_start_date');
                const endDateInput = document.getElementById('leave_end_date');
                const dateError = document.getElementById('dateError');
                
                // Set minimum start date to today
                const today = new Date().toISOString().split('T')[0];
                startDateInput.setAttribute('min', today);
                startDateInput.value = today; // Set default value to today
                
                // Update minimum end date when start date changes
                startDateInput.addEventListener('change', function() {
                    endDateInput.setAttribute('min', startDateInput.value);
                    validateDates();
                });
                
                // Validate end date when it changes
                endDateInput.addEventListener('change', validateDates);
                
                // Function to validate dates
                function validateDates() {
                    const startDate = new Date(startDateInput.value);
                    const endDate = new Date(endDateInput.value);
                    
                    if (endDate < startDate) {
                        dateError.classList.remove('d-none');
                        endDateInput.classList.add('is-invalid');
                        return false;
                    } else {
                        dateError.classList.add('d-none');
                        endDateInput.classList.remove('is-invalid');
                        return true;
                    }
                }
                
                // Form submission validation
                leaveForm.addEventListener('submit', function(event) {
                    if (!validateDates()) {
                        event.preventDefault();
                    }
                });
            });
        </script>
    @else
        <!-- Display message if registration is not approved -->
        <div class="alert alert-warning">
            <h5>Registration Not Approved</h5>
            <p>Your hostel registration has not been approved by the warden yet. You can submit a leave request once your registration is approved.</p>
            <p>Please check your <a href="{{ route('student.hostel-registration-status') }}" class="alert-link">Hostel Registration Status</a> for updates.</p>
        </div>
    @endif
</div>
        <!-- Hostel Registration Status (Initially hidden) -->
        <div id="hostelRegistrationStatus" class="section d-none">
            <h3 class="mb-4 text-center text-primary">Hostel Registration Status</h3>
            <p>Hostel registration status will be displayed here.</p>
        </div>
       
<script>
// Function to show and hide sections
function showSection(sectionId) {
    // Hide all sections initially
    const sections = document.querySelectorAll('.section');
    sections.forEach(section => {
        section.classList.add('d-none');
    });

    // Show the clicked section
    const selectedSection = document.getElementById(sectionId);
    if (selectedSection) {
        selectedSection.classList.remove('d-none');
    }
}


// Function to validate CID on blur event and show additional fields
function checkCID() {
    const cidInput = document.getElementById('cid_input');
    const cid = cidInput.value.trim();
    const cidError = document.getElementById('cidError');
    const leaveFormFields = document.getElementById('leaveFormFields');

    // If CID is empty, show error and hide additional fields
    if (cid === "") {
        cidError.textContent = "Please enter a valid CID.";
        cidError.classList.remove('d-none');
        leaveFormFields.style.display = "none";
        return;
    }

    // Display loading message while processing
    cidError.textContent = "Validating CID...";
    cidError.classList.remove('d-none');

    // AJAX request to validate CID
    fetch("{{ route('cid.validate') }}", {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
            'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]').getAttribute('content')
        },
        body: JSON.stringify({ cid: cid })
    })
    .then(response => response.json())
    .then(data => {
        if (data.status === 'success') {
            // Valid CID: hide error and reveal additional fields
            cidError.classList.add('d-none');
            leaveFormFields.style.display = "block";
        } else {
            // Invalid CID: show error and hide additional fields
            cidError.textContent = data.message || "This CID is not registered.";
            cidError.classList.remove('d-none');
            leaveFormFields.style.display = "none";
        }
    })
    .catch(error => {
        console.error('Error:', error);
        cidError.textContent = "An error occurred while validating CID.";
        cidError.classList.remove('d-none');
    });
}

// Function to toggle the status dropdown
// Function to toggle the status dropdown and show related sections
function toggleStatus(status) {
    // Hide all status sections
    const statusSections = document.querySelectorAll('.section');
    statusSections.forEach(section => {
        section.classList.add('d-none');
    });

    // Show the selected status section
    const selectedStatus = document.getElementById(status);
    if (selectedStatus) {
        selectedStatus.classList.remove('d-none');
    }

    // Close the dropdown menu after selection
    const statusDropdown = document.getElementById('statusDropdown');
    if (statusDropdown) {
        statusDropdown.classList.remove('show');
    }
    
}

</script>
@endsection
