@extends('components.layout')

@section('title')
    Hostel registration Status
@endsection

@section('span')
    You are logged in
@endsection

@section('log')
    <a href="{{ route('logout') }}" onclick="event.preventDefault(); document.getElementById('logout-form').submit();" class="text-white">
        <i class="fas fa-sign-out-alt me-1"></i>Logout
    </a>
    <form id="logout-form" action="{{ route('logout') }}" method="POST" class="d-none">
        @csrf
    </form>
@endsection

@section('content')
<header class="navbar navbar-expand-lg">
    <div class="container-fluid d-flex justify-content-between align-items-center position-relative">
        <!-- Logo -->
        <a class="navbar-brand" href="{{ route('dashboard') }}">
            <img src="{{ asset('images/logo.png') }}" alt="Hostel Management Logo" class="logo">
        </a>
        <!-- Navigation -->
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav ms-auto">
                <li class="nav-item">
                    <a class="nav-link text-white" href="{{ route('dashboard') }}">
                        <i class="fas fa-home me-1"></i>Dashboard
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link text-white active" href="{{ route('status') }}">
                        <i class="fas fa-clipboard-check me-1"></i>Status
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link text-white" href="{{ route('profile') }}">
                        <i class="fas fa-user-circle me-1"></i>Profile
                    </a>
                </li>
            </ul>
        </div>
    </div>
</header>

<!-- External CSS -->
<link rel="stylesheet" href="{{ asset('css/studentreg_style.css') }}">
<!-- Font Awesome for icons -->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">

<div class="container py-4">
    <!-- Alert for notifications -->
    @if(session('success'))
    <div class="alert alert-success alert-dismissible fade show" role="alert">
        <i class="fas fa-check-circle me-2"></i> {{ session('success') }}
        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
    </div>
    @endif

    <!-- Student info card -->
    @if(session()->has('cid'))
        @php
            $studentCid = session('cid');
            $studentRegistrations = $registrations->where('cid', $studentCid);
            $studentInfo = $studentRegistrations->first();
            
            // Get room allocations for the student
            $studentAllocations = DB::table('room_allocations')->where('cid', $studentCid)->get();
            $hasAllocation = $studentAllocations->isNotEmpty();
        @endphp

        <div class="card shadow-sm mb-4">
            <div class="card-header bg-primary text-white d-flex justify-content-between align-items-center">
                <h5 class="mb-0"><i class="fas fa-user-graduate me-2"></i>Student Information</h5>
                <span class="badge bg-light text-dark">CID: {{ $studentCid }}</span>
            </div>
            <div class="card-body">
                <div class="row">
                    @if($studentInfo)
                    <div class="col-md-8">
                        <h4>{{ $studentInfo->first_name }} {{ $studentInfo->last_name }}</h4>
                        <p class="text-muted mb-1">{{ $studentInfo->email }}</p>
                        <p class="mb-2"><i class="fas fa-phone me-2"></i>{{ $studentInfo->phone }}</p>
                        <p class="mb-2"><i class="fas fa-graduation-cap me-2"></i>{{ $studentInfo->course }}</p>
                        <div class="mt-3">
                            @if($hasAllocation)
                                <span class="badge bg-success p-2"><i class="fas fa-home me-1"></i>Room Allocated</span>
                            @else
                                @if($studentInfo->status === 'approved')
                                    <span class="badge bg-warning p-2"><i class="fas fa-clock me-1"></i>Pending Room Allocation</span>
                                @elseif($studentInfo->status === 'disapproved')
                                    <span class="badge bg-danger p-2"><i class="fas fa-times-circle me-1"></i>Registration Disapproved</span>
                                @else
                                    <span class="badge bg-info p-2"><i class="fas fa-hourglass-half me-1"></i>Registration Under Review</span>
                                @endif
                            @endif
                        </div>
                    </div>
                    <div class="col-md-4 text-center">
                        <div class="p-3 border rounded bg-light">
                            <i class="fas {{ $studentInfo->gender == 'male' ? 'fa-male' : 'fa-female' }} fa-4x text-primary"></i>
                            <p class="mt-2 mb-0">{{ ucfirst($studentInfo->gender) }}</p>
                        </div>
                    </div>
                    @else
                    <div class="col-12">
                        <div class="alert alert-info">
                            <i class="fas fa-info-circle me-2"></i>No registration information found. Please complete your hostel registration.
                        </div>
                    </div>
                    @endif
                </div>
            </div>
        </div>

        <!-- Status Info & Tab navigation -->
        <div class="card shadow-sm">
            <div class="card-header">
                <ul class="nav nav-tabs card-header-tabs" id="statusTabs" role="tablist">
                    <li class="nav-item" role="presentation">
                        <button class="nav-link active" id="registration-tab" data-bs-toggle="tab" data-bs-target="#registration" type="button" role="tab" aria-selected="true">
                            <i class="fas fa-clipboard-list me-2"></i>Registration Status
                        </button>
                    </li>
                    <li class="nav-item" role="presentation">
                        <button class="nav-link" id="allocation-tab" data-bs-toggle="tab" data-bs-target="#allocation" type="button" role="tab" aria-selected="false">
                            <i class="fas fa-key me-2"></i>Room Allocation
                        </button>
                    </li>
                </ul>
            </div>
            <div class="card-body">
                <div class="tab-content" id="statusTabContent">
                    <!-- Registration Status Tab -->
                    <div class="tab-pane fade show active" id="registration" role="tabpanel" aria-labelledby="registration-tab">
                        @if($studentRegistrations->isEmpty())
                            <div class="text-center py-5">
                                <i class="fas fa-exclamation-circle fa-3x text-warning mb-3"></i>
                                <p class="lead">No hostel registration found for your CID.</p>
                                <a href="{{ route('hostel.register') }}" class="btn btn-primary mt-3">
                                    <i class="fas fa-plus-circle me-2"></i>Register for Hostel
                                </a>
                            </div>
                        @else
                            @php
                                $sortedRegistrations = $studentRegistrations->sortByDesc('created_at');
                            @endphp

                            <div class="mb-3">
                                <div class="d-flex align-items-center mb-2">
                                    <h6 class="fw-bold mb-0">Registration Timeline</h6>
                                    <span class="ms-2 badge bg-primary">{{ $sortedRegistrations->count() }}</span>
                                </div>
                                <p class="text-muted small">Your registration history is displayed below with the most recent at the top.</p>
                            </div>

                            <div class="table-responsive">
                                <table class="table table-bordered table-striped table-hover">
                                    <thead class="table-primary">
                                        <tr>
                                            <th><i class="fas fa-id-card me-1"></i> ID</th>
                                            <th>Name</th>
                                            <th><i class="fas fa-at me-1"></i> Email</th>
                                            <th><i class="fas fa-book me-1"></i> Course</th>
                                            <th><i class="fas fa-chart-line me-1"></i> Status</th>
                                            <th><i class="fas fa-calendar-alt me-1"></i> Date Applied</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        @foreach($sortedRegistrations as $registration)
                                            <tr>
                                                <td>{{ $registration->id }}</td>
                                                <td>{{ $registration->first_name }} {{ $registration->last_name }}</td>
                                                <td>{{ $registration->email }}</td>
                                                <td>{{ $registration->course }}</td>
                                                <td>
                                                    @if($registration->status === 'approved')
                                                        <span class="badge bg-success"><i class="fas fa-check-circle me-1"></i> Approved</span>
                                                    @elseif($registration->status === 'disapproved')
                                                        <span class="badge bg-danger"><i class="fas fa-times-circle me-1"></i> Disapproved</span>
                                                    @else
                                                        <span class="badge bg-warning"><i class="fas fa-clock me-1"></i> Pending</span>
                                                    @endif
                                                </td>
                                                <td>{{ date('M d, Y', strtotime($registration->created_at)) }}</td>
                                            </tr>
                                        @endforeach
                                    </tbody>
                                </table>
                            </div>

                            @if($studentInfo->status === 'disapproved')
                            <div class="alert alert-danger mt-3">
                                <h6 class="alert-heading"><i class="fas fa-exclamation-triangle me-2"></i>Your application was not approved</h6>
                                <p>Please contact the hostel administrator for more information or reapply with updated information.</p>
                                <a href="{{ route('hostel.register') }}" class="btn btn-outline-danger btn-sm mt-2">Reapply</a>
                            </div>
                            @endif
                        @endif
                    </div>
                    
                    <!-- Room Allocation Status Tab -->
                    <div class="tab-pane fade" id="allocation" role="tabpanel" aria-labelledby="allocation-tab">
                        @if($studentAllocations->isEmpty())
                            <div class="text-center py-5">
                                <i class="fas fa-home fa-3x text-muted mb-3"></i>
                                <p class="lead">No room allocation found for your CID.</p>
                                @if($studentInfo && $studentInfo->status === 'approved')
                                <div class="alert alert-info mt-3">
                                    <p><i class="fas fa-info-circle me-2"></i>Your registration has been approved. Room allocation is in process.</p>
                                </div>
                                @endif
                            </div>
                        @else
                            @php
                                $sortedAllocations = $studentAllocations->sortByDesc('created_at');
                                $currentAllocation = $sortedAllocations->first();
                            @endphp
                            
                            <!-- Room Card -->
                            <div class="row mb-4">
                                <div class="col-md-6 offset-md-3">
                                    <div class="card border-success">
                                        <div class="card-header bg-success text-white">
                                            <h5 class="mb-0"><i class="fas fa-key me-2"></i>Your Room Details</h5>
                                        </div>
                                        <div class="card-body text-center">
                                            <div class="display-4 mb-3">{{ $currentAllocation->block_no }} - {{ $currentAllocation->room_no }}</div>
                                            <p class="lead mb-1">Block: <strong>{{ $currentAllocation->block_no }}</strong></p>
                                            <p class="lead mb-3">Room Number: <strong>{{ $currentAllocation->room_no }}</strong></p>
                                            <p class="text-muted">Allocation Date: {{ date('F d, Y', strtotime($currentAllocation->allocation_date)) }}</p>
                                            <hr>
                                            <div class="d-grid gap-2 col-6 mx-auto">
                                                <button class="btn btn-outline-primary" type="button" data-bs-toggle="modal" data-bs-target="#roomDetailsModal">
                                                    <i class="fas fa-info-circle me-2"></i>Room Details
                                                </button>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div class="mb-3">
                                <div class="d-flex align-items-center mb-2">
                                    <h6 class="fw-bold mb-0">Allocation History</h6>
                                    <span class="ms-2 badge bg-success">{{ $sortedAllocations->count() }}</span>
                                </div>
                                <p class="text-muted small">Your room allocation history is displayed below.</p>
                            </div>

                            <div class="table-responsive">
                                <table class="table table-bordered table-striped table-hover">
                                    <thead class="table-success">
                                        <tr>
                                            <th><i class="fas fa-hashtag me-1"></i> ID</th>
                                            <th><i class="fas fa-building me-1"></i> Block</th>
                                            <th><i class="fas fa-door-open me-1"></i> Room</th>
                                            <th><i class="fas fa-calendar-check me-1"></i> Allocation Date</th>
                                            <th><i class="fas fa-clock me-1"></i> Timestamp</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        @foreach($sortedAllocations as $allocation)
                                            <tr>
                                                <td>{{ $allocation->allocation_id }}</td>
                                                <td>{{ $allocation->block_no }}</td>
                                                <td>{{ $allocation->room_no }}</td>
                                                <td>{{ date('M d, Y', strtotime($allocation->allocation_date)) }}</td>
                                                <td>{{ date('M d, Y g:i A', strtotime($allocation->created_at)) }}</td>
                                            </tr>
                                        @endforeach
                                    </tbody>
                                </table>
                            </div>

                            <!-- Important notices -->
                            <div class="alert alert-info mt-4">
                                <h6 class="alert-heading"><i class="fas fa-info-circle me-2"></i>Important Information</h6>
                                <p class="mb-0">Please collect your room key from the hostel office during office hours (9:00 AM - 5:00 PM).</p>
                            </div>
                        @endif
                    </div>
                </div>
            </div>
            <div class="card-footer bg-light">
                <small class="text-muted"><i class="fas fa-info-circle me-1"></i> Last updated: {{ date('F d, Y g:i A') }}</small>
            </div>
        </div>
    @else
        <div class="card shadow">
            <div class="card-body text-center py-5">
                <i class="fas fa-user-lock fa-4x text-danger mb-4"></i>
                <h4>Authentication Required</h4>
                <p class="text-danger">You are not logged in. Please log in to view your registration and allocation status.</p>
                <a href="{{ route('login') }}" class="btn btn-primary mt-3">
                    <i class="fas fa-sign-in-alt me-2"></i>Login
                </a>
            </div>
        </div>
    @endif
</div>

<!-- Room Details Modal -->
@if(isset($currentAllocation) && !empty($currentAllocation))
<div class="modal fade" id="roomDetailsModal" tabindex="-1" aria-labelledby="roomDetailsModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header bg-primary text-white">
                <h5 class="modal-title" id="roomDetailsModalLabel"><i class="fas fa-info-circle me-2"></i>Room Details</h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <div class="card mb-3">
                    <div class="card-body">
                        <h5 class="card-title">{{ $currentAllocation->block_no }} - {{ $currentAllocation->room_no }}</h5>
                        <p class="card-text"><strong>Block:</strong> {{ $currentAllocation->block_no }}</p>
                        <p class="card-text"><strong>Room Number:</strong> {{ $currentAllocation->room_no }}</p>
                        <p class="card-text"><strong>Floor:</strong> {{ substr($currentAllocation->room_no, 0, 1) }}</p>
                        <p class="card-text"><strong>Room Type:</strong> Double Sharing</p>
                        <p class="card-text"><strong>Facilities:</strong> Bed, Desk, Chair, Wardrobe, Wi-Fi</p>
                    </div>
                </div>
                <div class="alert alert-warning">
                    <h6><i class="fas fa-exclamation-triangle me-2"></i>Room Rules</h6>
                    <ul class="mb-0">
                        <li>No cooking in the rooms</li>
                        <li>Quiet hours: 10:00 PM - 6:00 AM</li>
                        <li>No guests after 8:00 PM</li>
                        <li>Keep your room clean</li>
                    </ul>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                <a href="{{ route('help') }}" class="btn btn-primary"><i class="fas fa-question-circle me-2"></i>Help</a>
            </div>
        </div>
    </div>
</div>
@endif

<!-- Add Bootstrap JS for tab functionality -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
@endsection