@extends('components.layout')

@section('title') 
HR Reports 
@endsection

@section('span') 
You are logged in 
@endsection

@section('log') 
<a href="#" data-bs-toggle="modal" data-bs-target="#loginModal" class="text-white">(Logout)</a> 
@endsection

@section('content')
<header class="navbar navbar-expand-lg">
    <div class="container-fluid d-flex justify-content-between align-items-center position-relative">
        <a class="navbar-brand" href="#">
            <img src="{{ asset('images/logo.png') }}" alt="Hostel Management Logo" class="logo">
        </a>
        <div class="text-white">
            <span>You are logged in {{ session('cid') }}</span>
        </div>
    </div>
</header>

<link rel="stylesheet" href="{{ asset('css/hr_style.css') }}">

<div class="d-flex" style="min-height: 100vh;">
    <!-- Sidebar -->
    <div class="sidebar bg-success text-white p-4" style="width: 250px; height: 100vh; box-shadow: 2px 0 10px rgba(0,0,0,0.1); position: sticky;">
        <h4 class="text-center text-white mb-4">HR Dashboard</h4>
        <ul class="list-unstyled">
            <li><a href="{{ route('takeattendance') }}" class="text-white d-block py-2 px-3 rounded mb-2"><i class="bi bi-check-square"></i> Take Attendance</a></li>
            <li><a href="{{ route('attendancereport') }}" class="text-white d-block py-2 px-3 rounded mb-2"><i class="bi bi-check-square"></i> Attendance Report</a></li>
            <li><a href="{{ route('leave-requests') }}" class="text-white d-block py-2 px-3 rounded mb-2"><i class="bi bi-journal-text"></i> View Leave Report</a></li>
            <li><a href="{{ route('feedbacks') }}" class="text-white d-block py-2 px-3 rounded mb-2">
                <i class="bi bi-chat-dots"></i> Feedbacks
            </a></li>
            <li><a href="{{ route('report') }}" class="text-white d-block py-2 px-3 rounded mb-2 active"><i class="bi bi-bar-chart-line"></i> Reports</a></li>
        </ul>
    </div>
    
    <!-- Main Content -->
    <div class="main-content p-4" style="flex-grow: 1;">
        @if(session('success'))
            <div class="alert alert-success">{{ session('success') }}</div>
        @endif
        
        @if(session('error'))
            <div class="alert alert-danger">{{ session('error') }}</div>
        @endif
        
        <h2 class="text-center text-primary mb-4">HR Comprehensive Report</h2>
        
        <div class="row mb-4">
            <div class="col-md-12">
                <div class="card shadow">
                    <div class="card-header bg-primary text-white">
                        <h5 class="mb-0">Filter Options</h5>
                    </div>
                    <div class="card-body">
                        <form action="{{ route('report') }}" method="GET" class="row g-3">
                            <div class="col-md-3">
                                <label for="date_from" class="form-label">Date From</label>
                                <input type="date" class="form-control" id="date_from" name="date_from" value="{{ request('date_from') }}">
                            </div>
                            <div class="col-md-3">
                                <label for="date_to" class="form-label">Date To</label>
                                <input type="date" class="form-control" id="date_to" name="date_to" value="{{ request('date_to') }}">
                            </div>
                            <div class="col-md-3">
                                <label for="report_type" class="form-label">Report Type</label>
                                <select class="form-select" id="report_type" name="report_type">
                                    <option value="all" {{ request('report_type') == 'all' ? 'selected' : '' }}>All Reports</option>
                                    <option value="attendance" {{ request('report_type') == 'attendance' ? 'selected' : '' }}>Attendance</option>
                                    <option value="leaves" {{ request('report_type') == 'leaves' ? 'selected' : '' }}>Leaves</option>
                                    <option value="feedbacks" {{ request('report_type') == 'feedbacks' ? 'selected' : '' }}>Feedbacks</option>
                                </select>
                            </div>
                            <div class="col-md-3 d-flex align-items-end">
                                <button type="submit" class="btn btn-primary w-100">Generate Report</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
        
        <!-- Attendance Report Section -->
        @if(request('report_type') == 'all' || request('report_type') == 'attendance' || request('report_type') == null)
        <div class="row mb-4">
            <div class="col-md-12">
                <div class="card shadow">
                    <div class="card-header bg-success text-white d-flex justify-content-between align-items-center">
                        <h5 class="mb-0">Attendance Report</h5>
                        <button class="btn btn-sm btn-light" onclick="exportTable('attendance-table', 'Attendance_Report')">
                            <i class="bi bi-download"></i> Export
                        </button>
                    </div>
                    <div class="card-body">
                        <div class="table-responsive">
                            <table class="table table-striped table-hover" id="attendance-table">
                                <thead>
                                    <tr>
                                        <th>ID</th>
                                        <th>cid</th>
                                        <th>Block no</th>
                                        <th>Room No</th>
                                        <th>status</th>
                                        <th>Remarks</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    @forelse($attendances ?? [] as $attendance)
                                    <tr>
                                        <td>{{ $attendance->id }}</td>
                                        <td>{{ $attendance->cid }}</td>
                                        <td>{{ $attendance->block_no }}</td>
                                        <td>{{ $attendance->room_no }}</td>
                                        <td>
                                            @if($attendance->status == 'present')
                                                <span class="badge bg-success">Present</span>
                                            @elseif($attendance->status == 'absent')
                                                <span class="badge bg-danger">Absent</span>
                                            @else
                                                <span class="badge bg-warning">{{ $attendance->status }}</span>
                                            @endif
                                        </td>
                                        
                                        <td>{{ $attendance->remarks }}</td>
                                    </tr>
                                    @empty
                                    <tr>
                                        <td colspan="6" class="text-center">No attendance records found</td>
                                    </tr>
                                    @endforelse
                                </tbody>
                            </table>
                        </div>
                        
                        @if(isset($attendances) && $attendances->count() > 0)
                        <div class="mt-3">
                            {{ $attendances->appends(request()->except('page'))->links() }}
                        </div>
                        <div class="row mt-4">
                            <div class="col-md-6">
                                <div class="card bg-light">
                                    <div class="card-body">
                                        <h6>Attendance Summary</h6>
                                        <div class="progress mb-2" style="height: 25px;">
                                            <div class="progress-bar bg-success" role="progressbar" style="width: {{ $attendanceSummary['presentPercentage'] ?? 0 }}%;" aria-valuenow="{{ $attendanceSummary['presentPercentage'] ?? 0 }}" aria-valuemin="0" aria-valuemax="100">
                                                Present: {{ $attendanceSummary['presentPercentage'] ?? 0 }}%
                                            </div>
                                            <div class="progress-bar bg-danger" role="progressbar" style="width: {{ $attendanceSummary['absentPercentage'] ?? 0 }}%;" aria-valuenow="{{ $attendanceSummary['absentPercentage'] ?? 0 }}" aria-valuemin="0" aria-valuemax="100">
                                                Absent: {{ $attendanceSummary['absentPercentage'] ?? 0 }}%
                                            </div>
                                        </div>
                                        <p>Total Records: {{ $attendanceSummary['total'] ?? 0 }}</p>
                                    </div>
                                </div>
                            </div>
                        </div>
                        @endif
                    </div>
                </div>
            </div>
        </div>
        @endif
        
        <!-- Leaves Report Section -->
        @if(request('report_type') == 'all' || request('report_type') == 'leaves' || request('report_type') == null)
        <div class="row mb-4">
            <div class="col-md-12">
                <div class="card shadow">
                    <div class="card-header bg-info text-white d-flex justify-content-between align-items-center">
                        <h5 class="mb-0">Leave Requests Report</h5>
                        <button class="btn btn-sm btn-light" onclick="exportTable('leaves-table', 'Leaves_Report')">
                            <i class="bi bi-download"></i> Export
                        </button>
                    </div>
                    <div class="card-body">
                        <div class="table-responsive">
                            <table class="table table-striped table-hover" id="leaves-table">
                                <thead>
                                    <tr>
                                        <th>ID</th>
                                        <th>cid</th>
                                        <th>start date</th>
                                        <th>End Date</th>
                                        <th>Reason</th>
                                        <th>cancel message</th>

                                        <th>Status</th>
                                       
                                    </tr>
                                </thead>
                                <tbody>
                                    @forelse($leaves ?? [] as $leave)
                                    <tr>
                                        <td>{{ $leave->id }}</td>
                                        <td>{{ $leave->cid }}</td>
                                        <td>{{ $leave->leave_start_date }}</td>
                                        <td>{{ $leave->leave_end_date }}</td>
                                        <td>{{ Str::limit($leave->leave_reason, 50) }}</td>
                                        <td>{{ $leave->cancel_message }}</td>
                                        <td>
                                            @if($leave->status == 'approved')
                                                <span class="badge bg-success">Approved</span>
                                            @elseif($leave->status == 'pending')
                                                <span class="badge bg-warning">Pending</span>
                                            @elseif($leave->status == 'rejected')
                                                <span class="badge bg-danger">Rejected</span>
                                            @else
                                                <span class="badge bg-secondary">{{ $leave->status }}</span>
                                            @endif
                                        </td>
                                       
                                    </tr>
                                    @empty
                                    <tr>
                                        <td colspan="7" class="text-center">No leave requests found</td>
                                    </tr>
                                    @endforelse
                                </tbody>
                            </table>
                        </div>
                        
                        @if(isset($leaves) && $leaves->count() > 0)
                        <div class="mt-3">
                            {{ $leaves->appends(request()->except('page'))->links() }}
                        </div>
                        <div class="row mt-4">
                            <div class="col-md-6">
                                <div class="card bg-light">
                                    <div class="card-body">
                                        <h6>Leave Requests Summary</h6>
                                        <div class="d-flex justify-content-between mb-2">
                                            <span>Total Requests: {{ $leavesSummary['total'] ?? 0 }}</span>
                                            <span>Average Duration: {{ $leavesSummary['avgDuration'] ?? 0 }} days</span>
                                        </div>
                                        <div class="progress" style="height: 25px;">
                                            <div class="progress-bar bg-success" role="progressbar" style="width: {{ $leavesSummary['approvedPercentage'] ?? 0 }}%;" aria-valuenow="{{ $leavesSummary['approvedPercentage'] ?? 0 }}" aria-valuemin="0" aria-valuemax="100">
                                                Approved: {{ $leavesSummary['approvedPercentage'] ?? 0 }}%
                                            </div>
                                            <div class="progress-bar bg-warning" role="progressbar" style="width: {{ $leavesSummary['pendingPercentage'] ?? 0 }}%;" aria-valuenow="{{ $leavesSummary['pendingPercentage'] ?? 0 }}" aria-valuemin="0" aria-valuemax="100">
                                                Pending: {{ $leavesSummary['pendingPercentage'] ?? 0 }}%
                                            </div>
                                            <div class="progress-bar bg-danger" role="progressbar" style="width: {{ $leavesSummary['rejectedPercentage'] ?? 0 }}%;" aria-valuenow="{{ $leavesSummary['rejectedPercentage'] ?? 0 }}" aria-valuemin="0" aria-valuemax="100">
                                                Rejected: {{ $leavesSummary['rejectedPercentage'] ?? 0 }}%
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        @endif
                    </div>
                </div>
            </div>
        </div>
        @endif
        
        <!-- Feedbacks Report Section -->
        @if(request('report_type') == 'all' || request('report_type') == 'feedbacks' || request('report_type') == null)
        <div class="row mb-4">
            <div class="col-md-12">
                <div class="card shadow">
                    <div class="card-header bg-purple text-white d-flex justify-content-between align-items-center" style="background-color: #6f42c1;">
                        <h5 class="mb-0">Feedbacks Report</h5>
                        <button class="btn btn-sm btn-light" onclick="exportTable('feedbacks-table', 'Feedbacks_Report')">
                            <i class="bi bi-download"></i> Export
                        </button>
                    </div>
                    <div class="card-body">
                        <div class="table-responsive">
                            <table class="table table-striped table-hover" id="feedbacks-table">
                                <thead>
                                    <tr>
                                        <th>ID</th>
                                        <th>Name</th>
                                        <th>Email</th>
                                        <th>Subject</th>
                                        <th>Category</th>
                                        <th>Message</th>
                                        <th>is_resolved</th>
                                        <th>Rating</th>
                                        <th>created at</th>
                                       
                                    </tr>
                                </thead>
                                <tbody>
                                    @forelse($feedbacks ?? [] as $feedback)
                                    <tr>
                                        <td>{{ $feedback->id }}</td>
                                        <td>{{ $feedback->name }}</td>
                                        <td>{{ $feedback->email}}</td>
                                        <td>{{ $feedback->subject}}</td>
                                        <td>{{ $feedback->category}}</td>
                                        <td>{{ $feedback->message}}</td>
                                        <td>{{ $feedback->is_resolved}}</td>
                                        <td>
                                            <div class="star-rating">
                                                @for($i = 1; $i <= 5; $i++)
                                                    @if($i <= $feedback->rating)
                                                        <i class="bi bi-star-fill text-warning"></i>
                                                    @else
                                                        <i class="bi bi-star text-warning"></i>
                                                    @endif
                                                @endfor
                                                <span class="ms-1">({{ $feedback->rating }})</span>
                                            </div>
                                        </td>
                                        <td>{{ $feedback->created_at }}</td>
                                    </tr>
                                    @empty
                                    <tr>
                                        <td colspan="7" class="text-center">No feedbacks found</td>
                                    </tr>
                                    @endforelse
                                </tbody>
                            </table>
                        </div>
                        
                        @if(isset($feedbacks) && $feedbacks->count() > 0)
                        <div class="mt-3">
                            {{ $feedbacks->appends(request()->except('page'))->links() }}
                        </div>
                        <div class="row mt-4">
                            <div class="col-md-6">
                                <div class="card bg-light">
                                    <div class="card-body">
                                        <h6>Feedback Summary</h6>
                                        <p>Total Feedbacks: {{ $feedbackSummary['total'] ?? 0 }}</p>
                                        <p>Average Rating: 
                                            <strong>{{ number_format($feedbackSummary['avgRating'] ?? 0, 1) }}</strong>
                                            <span class="ms-2">
                                                @for($i = 1; $i <= 5; $i++)
                                                    @if($i <= round($feedbackSummary['avgRating'] ?? 0))
                                                        <i class="bi bi-star-fill text-warning"></i>
                                                    @else
                                                        <i class="bi bi-star text-warning"></i>
                                                    @endif
                                                @endfor
                                            </span>
                                        </p>
                                    </div>
                                </div>
                            </div>
                        </div>
                        @endif
                    </div>
                </div>
            </div>
        </div>
        @endif
    </div>
</div>

<script>
function exportTable(tableId, filename) {
    const table = document.getElementById(tableId);
    const headers = Array.from(table.querySelectorAll('thead th')).map(th => th.textContent.trim());
    
    // Get all rows from the table body
    const rows = Array.from(table.querySelectorAll('tbody tr'));
    
    // Extract data from rows
    const data = rows.map(row => {
        return Array.from(row.querySelectorAll('td')).map(td => {
            // Only extract text content, remove any HTML
            return td.textContent.trim().replace(/,/g, ' ');
        });
    });
    
    // Create CSV content
    let csvContent = headers.join(',') + '\n';
    data.forEach(row => {
        csvContent += row.join(',') + '\n';
    });
    
    // Create download link
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.setAttribute('href', url);
    link.setAttribute('download', filename + '_' + new Date().toLocaleDateString() + '.csv');
    link.style.visibility = 'hidden';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
}

</script>
@endsection