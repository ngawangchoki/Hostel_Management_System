{{-- resources/views/hr/leave-requests.blade.php --}}
@extends('components.layout')

@section('title')
HR - Student Leave Requests
@endsection

@section('span')
You are logged in as HR
@endsection

@section('log')
<a href="#" data-bs-toggle="modal" data-bs-target="#loginModal" class="text-white">(Logout)</a>
@endsection

@section('content')
<header class="navbar navbar-expand-lg">
    <div class="container-fluid d-flex justify-content-between align-items-center position-relative">
        <!-- Logo -->
        <a class="navbar-brand" href="#">
            <img src="{{ asset('images/logo.png') }}" alt="Hostel Management Logo" class="logo">
        </a>
        <!-- Text Under Logo -->
        <div class="text-white">
            <span>You are logged in as HR</span>
        </div>
    </div>
</header>


            <!-- Add other HR menu items here -->
            <li>
                <a href="{{ route('hr.leave-requests') }}" class="text-white sidebar-link py-2 d-block px-3 rounded mb-2 active">
                    <i class="bi bi-file-earmark-text"></i> Student Leave Requests
                </a>
            </li>
            <!-- Other HR menu items -->
        </ul>
    </div>

    <!-- Main Content -->
    <div class="main-content p-4" style="flex-grow: 1;">
        <h3 class="mb-4 text-primary">Student Leave Requests</h3>
        
        @if(session('success'))
            <div class="alert alert-success">
                {{ session('success') }}
            </div>
        @endif

        <!-- Leave Requests Table -->
        <div class="card">
            <div class="card-body">
                @if($leaves->count() > 0)
                    <div class="table-responsive">
                        <table class="table table-striped table-hover">
                            <thead>
                                <tr>
                                    <th>ID</th>
                                    <th>CID</th>
                                    <th>Block No</th>
                                    <th>Room No</th>
                                    <th>From Date</th>
                                    <th>To Date</th>
                                    <th>Reason</th>
                                    <th>Status</th>
                                    <th>Submitted On</th>
                                </tr>
                            </thead>
                            <tbody>
                                @foreach($leaves as $leave)
                                <tr>
                                    <td>{{ $leave->id }}</td>
                                    <td>{{ $leave->cid }}</td>
                                    <td>{{ $leave->roomAllocation->block_no ?? 'N/A' }}</td>
                                    <td>{{ $leave->roomAllocation->room_no ?? 'N/A' }}</td>
                                    <td>{{ date('d M Y', strtotime($leave->leave_start_date)) }}</td>
                                    <td>{{ date('d M Y', strtotime($leave->leave_end_date)) }}</td>
                                    <td>
                                        <button type="button" class="btn btn-sm btn-info" data-bs-toggle="modal" data-bs-target="#reasonModal{{ $leave->id }}">
                                            View Reason
                                        </button>
                                    </td>
                                    <td>
                                        <span class="badge rounded-pill bg-{{ $leave->status == 'approved' ? 'success' : ($leave->status == 'rejected' ? 'danger' : 'warning') }}">
                                            {{ ucfirst($leave->status) }}
                                        </span>
                                    </td>
                                    <td>{{ $leave->created_at->format('d M Y H:i') }}</td>
                                </tr>

                                <!-- Reason Modal -->
                                <div class="modal fade" id="reasonModal{{ $leave->id }}" tabindex="-1" aria-labelledby="reasonModalLabel{{ $leave->id }}" aria-hidden="true">
                                    <div class="modal-dialog">
                                        <div class="modal-content">
                                            <div class="modal-header">
                                                <h5 class="modal-title" id="reasonModalLabel{{ $leave->id }}">Leave Reason</h5>
                                                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                            </div>
                                            <div class="modal-body">
                                                <p>{{ $leave->leave_reason }}</p>
                                            </div>
                                            <div class="modal-footer">
                                                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                @endforeach
                            </tbody>
                        </table>
                    </div>
                @else
                    <div class="alert alert-info">
                        No leave requests have been submitted yet.
                    </div>
                @endif
            </div>
        </div>
    </div>
</div>
@endsection