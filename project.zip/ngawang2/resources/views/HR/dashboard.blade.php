@extends('components.layout')

@section('title') HR Dashboard @endsection

@section('span') You are logged in @endsection

@section('log') <a href="#" data-bs-toggle="modal" data-bs-target="#loginModal" class="text-white">(Logout)</a> @endsection

@section('content')
<header class="navbar navbar-expand-lg">
    <div class="container-fluid d-flex justify-content-between align-items-center position-relative">
        <a class="navbar-brand" href="#">
            <img src="{{ asset('images/logo.png') }}" alt="Hostel Management Logo" class="logo">
        </a>
        <div class="text-white">
            <span>You are logged in {{ session('cid') }}</span>
        </div>
    </div>
</header>

<link rel="stylesheet" href="{{ asset('css/hr_style.css') }}">

<div class="d-flex" style="min-height: 100vh;">
    <!-- Sidebar -->
    <div class="sidebar bg-success text-white p-4" style="width: 250px; height: 100vh; box-shadow: 2px 0 10px rgba(0,0,0,0.1); position: sticky;">
        <h4 class="text-center text-white mb-4">HR Dashboard</h4>
        <ul class="list-unstyled">
            <li><a href="{{ route('takeattendance') }}" class="text-white d-block py-2 px-3 rounded mb-2"><i class="bi bi-check-square"></i> Take Attendance</a></li>

            <li><a href="{{ route('attendancereport') }}" class="text-white d-block py-2 px-3 rounded mb-2"><i class="bi bi-check-square"></i> Attendance Report</a></li>
            <li><a href="{{ route('leave-requests') }}" class="text-white d-block py-2 px-3 rounded mb-2"><i class="bi bi-journal-text"></i> View Leave Report</a></li>
             <li><a href="{{ route('feedbacks') }}" class="text-white d-block py-2 px-3 rounded mb-2">
                <i class="bi bi-chat-dots"></i> Feedbacks
            </a>
            
            </li>
            <li><a href="{{ route('report') }}" class="text-white d-block py-2 px-3 rounded mb-2"><i class="bi bi-bar-chart-line"></i> Reports</a></li>
        </ul>
    </div>
    
    <!-- Main Content -->
    <div class="main-content p-4" style="flex-grow: 1;">
        @if(session('success'))
            <div class="alert alert-success">{{ session('success') }}</div>
        @endif
        
        @if(session('error'))
            <div class="alert alert-danger">{{ session('error') }}</div>
        @endif
        
        <div id="takeAttendance" class="section d-none">
            <h3 class="text-center text-primary mb-4">Take Attendance</h3>
            
            <div class="card shadow">
                <div class="card-body">
                    <form action="{{ route('attendance.store') }}" method="POST">
                        @csrf
                       
        
        <div id="attendanceReport" class="section d-none">
            <h3 class="text-center text-primary mb-4">Attendance Report</h3>
            <p>View attendance history and reports.</p>
        </div>
        
        <div id="leaveReport" class="section d-none">
            <h3 class="text-center text-primary mb-4">Leave Report</h3>
            <p>Detailed report of all student leaves.</p>
        </div>
        
        <div id="feedbacks" class="section d-none">
            <h3 class="text-center text-primary mb-4">Feedbacks</h3>
            <p>Review feedbacks submitted by students, wardens, or matrons.</p>
        </div>
        
        <div id="hrReports" class="section d-none">
            <h3 class="text-center text-primary mb-4">HR Reports</h3>
            <p>Generate HR related reports.</p>
        </div>
    </div>
</div>

<script>
    // Show Take Attendance section by default
    window.onload = function() {
        showSection('takeAttendance');
    }
    
    function showSection(sectionId) {
        document.querySelectorAll('.section').forEach(el => el.classList.add('d-none'));
        document.getElementById(sectionId).classList.remove('d-none');
    }
    
</script>
@endsection