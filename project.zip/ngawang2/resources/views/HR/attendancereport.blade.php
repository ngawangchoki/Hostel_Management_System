@extends('components.layout')

@section('title')
    Student Attendance Dashboard
@endsection

@section('span')
    Attendance Monitoring System
@endsection

@section('content')
<div class="container-fluid py-4">
    <!-- Header Section with Title and Controls -->
    <div class="row mb-4">
        <div class="col-12">
            <div class="card bg-gradient-primary text-white shadow-lg">
                <div class="card-body p-4">
                    <div class="d-flex justify-content-between align-items-center">
                        <div>
                            <h3 class="mb-0 text-white">Student Attendance Tracker</h3>
                            <p class="mb-0 opacity-8">Monitor and analyze attendance patterns</p>
                        </div>
                        <div class="btn-group">
                            <button class="btn btn-light btn-sm" onclick="exportToExcel()">
                                <i class="bi bi-file-earmark-excel me-1"></i>Excel Export
                            </button>
                            <button class="btn btn-light btn-sm" onclick="exportToPDF()">
                                <i class="bi bi-file-earmark-pdf me-1"></i>PDF Export
                            </button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Interactive Date Range Selection -->
    <div class="row mb-4">
        <div class="col-12">
            <div class="card shadow-sm border-0">
                <div class="card-body">
                    <h5 class="card-title border-bottom pb-2">Date Selection</h5>
                    <div class="row g-3">
                        <div class="col-md-4">
                            <div class="input-group">
                                <span class="input-group-text bg-light">From</span>
                                <input type="date" class="form-control" id="start_date" name="start_date" value="{{ $startDate ?? date('Y-m-d', strtotime('-7 days')) }}">
                                <span class="input-group-text bg-light">To</span>
                                <input type="date" class="form-control" id="end_date" name="end_date" value="{{ $endDate ?? date('Y-m-d') }}">
                                <button class="btn btn-primary" type="button" onclick="applyDateRange()">
                                    <i class="bi bi-calendar-check me-1"></i> Apply
                                </button>
                            </div>
                        </div>
                        <div class="col-md-8">
                            <div class="btn-group w-100" role="group">
                                <button type="button" class="btn btn-outline-primary" onclick="setDateRange('today')">Today</button>
                                <button type="button" class="btn btn-outline-primary" onclick="setDateRange('yesterday')">Yesterday</button>
                                <button type="button" class="btn btn-outline-primary" onclick="setDateRange('thisWeek')">This Week</button>
                                <button type="button" class="btn btn-outline-primary" onclick="setDateRange('lastWeek')">Last Week</button>
                                <button type="button" class="btn btn-outline-primary" onclick="setDateRange('thisMonth')">This Month</button>
                                <button type="button" class="btn btn-outline-primary" onclick="setDateRange('lastMonth')">Last Month</button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <!-- Statistics Cards with Visual Indicators -->
    <div class="row mb-4">
        <div class="col-md-3">
            <div class="card border-0 shadow-sm h-100">
                <div class="card-body position-relative">
                    <div class="position-absolute top-0 end-0 mt-3 me-3">
                        <div class="icon-shape rounded-circle bg-success bg-opacity-10 text-center p-3">
                            <i class="bi bi-person-check text-success" style="font-size: 1.5rem;"></i>
                        </div>
                    </div>
                    <h6 class="text-uppercase text-muted mb-2">Present</h6>
                    <h2 class="display-5 mb-0 text-success">{{ $presentCount ?? 0 }}</h2>
                    <div class="progress mt-3" style="height: 5px;">
                        <div class="progress-bar bg-success" role="progressbar" style="width: {{ (($presentCount ?? 0) / (($presentCount ?? 0) + ($absentCount ?? 0) + ($leaveCount ?? 0) ?: 1)) * 100 }}%"></div>
                    </div>
                </div>
            </div>
        </div>
        
        <div class="col-md-3">
            <div class="card border-0 shadow-sm h-100">
                <div class="card-body position-relative">
                    <div class="position-absolute top-0 end-0 mt-3 me-3">
                        <div class="icon-shape rounded-circle bg-danger bg-opacity-10 text-center p-3">
                            <i class="bi bi-person-x text-danger" style="font-size: 1.5rem;"></i>
                        </div>
                    </div>
                    <h6 class="text-uppercase text-muted mb-2">Absent</h6>
                    <h2 class="display-5 mb-0 text-danger">{{ $absentCount ?? 0 }}</h2>
                    <div class="progress mt-3" style="height: 5px;">
                        <div class="progress-bar bg-danger" role="progressbar" style="width: {{ (($absentCount ?? 0) / (($presentCount ?? 0) + ($absentCount ?? 0) + ($leaveCount ?? 0) ?: 1)) * 100 }}%"></div>
                    </div>
                </div>
            </div>
        </div>
        
        <div class="col-md-3">
            <div class="card border-0 shadow-sm h-100">
                <div class="card-body position-relative">
                    <div class="position-absolute top-0 end-0 mt-3 me-3">
                        <div class="icon-shape rounded-circle bg-info bg-opacity-10 text-center p-3">
                            <i class="bi bi-calendar2-check text-info" style="font-size: 1.5rem;"></i>
                        </div>
                    </div>
                    <h6 class="text-uppercase text-muted mb-2">On Leave</h6>
                    <h2 class="display-5 mb-0 text-info">{{ $leaveCount ?? 0 }}</h2>
                    <div class="progress mt-3" style="height: 5px;">
                        <div class="progress-bar bg-info" role="progressbar" style="width: {{ (($leaveCount ?? 0) / (($presentCount ?? 0) + ($absentCount ?? 0) + ($leaveCount ?? 0) ?: 1)) * 100 }}%"></div>
                    </div>
                </div>
            </div>
        </div>
        
        <div class="col-md-3">
            <div class="card border-0 shadow-sm h-100">
                <div class="card-body position-relative">
                    <div class="position-absolute top-0 end-0 mt-3 me-3">
                        <div class="icon-shape rounded-circle bg-primary bg-opacity-10 text-center p-3">
                            <i class="bi bi-people text-primary" style="font-size: 1.5rem;"></i>
                        </div>
                    </div>
                    <h6 class="text-uppercase text-muted mb-2">Total Students</h6>
                    <h2 class="display-5 mb-0 text-primary">{{ ($presentCount ?? 0) + ($absentCount ?? 0) + ($leaveCount ?? 0) }}</h2>
                    <div class="progress mt-3" style="height: 5px;">
                        <div class="progress-bar bg-primary" role="progressbar" style="width: 100%"></div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Advanced Filters -->
    <div class="row mb-4">
        <div class="col-12">
            <div class="card shadow-sm border-0">
                <div class="card-header bg-light p-3">
                    <h5 class="mb-0"><i class="bi bi-funnel me-2"></i>Advanced Filters</h5>
                </div>
                <div class="card-body">
                    <div class="row g-3">
                        <div class="col-md-3">
                            <div class="form-floating">
                                <input type="date" class="form-control" id="date_filter" name="date_filter" value="{{ $date ?? date('Y-m-d') }}">
                                <label for="date_filter">Specific Date</label>
                            </div>
                        </div>
                        <div class="col-md-3">
                            <div class="form-floating">
                                <select class="form-select" id="block_filter" name="block_filter">
                                    <option value="">All Blocks</option>
                                    <option value="A" {{ isset($block) && $block == 'A' ? 'selected' : '' }}>Block A</option>
                                    <option value="B" {{ isset($block) && $block == 'B' ? 'selected' : '' }}>Block B</option>
                                    <option value="C" {{ isset($block) && $block == 'C' ? 'selected' : '' }}>Block C</option>
                                    <option value="D" {{ isset($block) && $block == 'D' ? 'selected' : '' }}>Block D</option>
                                </select>
                                <label for="block_filter">Block Number</label>
                            </div>
                        </div>
                        <div class="col-md-3">
                            <div class="form-floating">
                                <select class="form-select" id="status_filter" name="status_filter">
                                    <option value="">All Status</option>
                                    <option value="present" {{ isset($status) && $status == 'present' ? 'selected' : '' }}>Present</option>
                                    <option value="absent" {{ isset($status) && $status == 'absent' ? 'selected' : '' }}>Absent</option>
                                    <option value="leave" {{ isset($status) && $status == 'leave' ? 'selected' : '' }}>On Leave</option>
                                </select>
                                <label for="status_filter">Attendance Status</label>
                            </div>
                        </div>
                        <div class="col-md-3 d-flex align-items-center justify-content-end">
                            <button type="button" class="btn btn-primary me-2" onclick="applyFilters()">
                                <i class="bi bi-search me-1"></i>Search
                            </button>
                            <button type="button" class="btn btn-outline-secondary" onclick="resetFilters()">
                                <i class="bi bi-arrow-counterclockwise me-1"></i>Reset
                            </button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Attendance Data Table -->
    <div class="row">
        <div class="col-12">
            <div class="card shadow-sm border-0">
                <div class="card-header bg-light p-3 d-flex justify-content-between align-items-center">
                    <h5 class="mb-0"><i class="bi bi-table me-2"></i>Attendance Records</h5>
                    <span class="badge bg-primary rounded-pill">{{ isset($attendances) ? $attendances->total() : 0 }} Records</span>
                </div>
                <div class="card-body p-0">
                    <div class="table-responsive">
                        <table class="table table-hover align-middle border-bottom mb-0" id="attendance-table">
                            <thead class="table-light text-uppercase">
                                <tr>
                                    <th width="50" class="text-center">#</th>
                                    <th width="80">ID</th>
                                    <th>Allocation ID</th>
                                    <th>CID</th>
                                    <th>Block</th>
                                    <th>Room</th>
                                    <th>Date</th>
                                    <th class="text-center">Status</th>
                                    <th>Remarks</th>
                                    <th>Created</th>
                                    <th>Updated</th>
                                </tr>
                            </thead>
                            <tbody>
                                @if(isset($attendances) && count($attendances) > 0)
                                    @foreach($attendances as $index => $attendance)
                                        <tr>
                                            <td class="text-center">{{ $index + 1 }}</td>
                                            <td><span class="badge bg-light text-dark">{{ $attendance->id }}</span></td>
                                            <td>{{ $attendance->allocation_id }}</td>
                                            <td>{{ $attendance->cid }}</td>
                                            <td><span class="badge rounded-pill bg-dark">Block {{ $attendance->block_no }}</span></td>
                                            <td>{{ $attendance->room_no }}</td>
                                            <td>{{ date('d M Y', strtotime($attendance->attendance_date)) }}</td>
                                            <td class="text-center">
                                                @if($attendance->status == 'present')
                                                    <span class="badge bg-success rounded-pill"><i class="bi bi-check-circle me-1"></i>Present</span>
                                                @elseif($attendance->status == 'absent')
                                                    <span class="badge bg-danger rounded-pill"><i class="bi bi-x-circle me-1"></i>Absent</span>
                                                @elseif($attendance->status == 'leave')
                                                    <span class="badge bg-info rounded-pill"><i class="bi bi-calendar-check me-1"></i>On Leave</span>
                                                @else
                                                    <span class="badge bg-secondary rounded-pill">{{ $attendance->status }}</span>
                                                @endif
                                            </td>
                                            <td>
                                                @if($attendance->remarks)
                                                    <span data-bs-toggle="tooltip" title="{{ $attendance->remarks }}">
                                                        {{ \Illuminate\Support\Str::limit($attendance->remarks, 20, '...') }}
                                                    </span>
                                                @else
                                                    <span class="text-muted">—</span>
                                                @endif
                                            </td>
                                            <td>
                                                <div class="small text-muted">{{ date('d M Y', strtotime($attendance->created_at)) }}</div>
                                                <div class="small">{{ date('H:i', strtotime($attendance->created_at)) }}</div>
                                            </td>
                                            <td>
                                                <div class="small text-muted">{{ date('d M Y', strtotime($attendance->updated_at)) }}</div>
                                                <div class="small">{{ date('H:i', strtotime($attendance->updated_at)) }}</div>
                                            </td>
                                        </tr>
                                    @endforeach
                                @else
                                    <tr>
                                        <td colspan="11" class="text-center p-5">
                                            <div class="text-muted">
                                                <i class="bi bi-inbox display-6 d-block mb-3"></i>
                                                <p>No attendance records found</p>
                                                <button class="btn btn-sm btn-outline-primary" onclick="resetFilters()">Reset Filters</button>
                                            </div>
                                        </td>
                                    </tr>
                                @endif
                            </tbody>
                        </table>
                    </div>
                </div>
                <!-- Pagination -->
                @if(isset($attendances) && $attendances instanceof \Illuminate\Pagination\LengthAwarePaginator)
                    <div class="card-footer bg-white p-3">
                        <div class="d-flex justify-content-between align-items-center">
                            <div class="small text-muted">
                                Showing {{ $attendances->firstItem() ?? 0 }} to {{ $attendances->lastItem() ?? 0 }} of {{ $attendances->total() }} records
                            </div>
                            <div>
                                {{ $attendances->appends(request()->query())->links() }}
                            </div>
                        </div>
                    </div>
                @endif
            </div>
        </div>
    </div>
</div>

<!-- JavaScript for attendance report functionality -->
<script>
    // Enable tooltips
    document.addEventListener('DOMContentLoaded', function() {
        var tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'))
        var tooltipList = tooltipTriggerList.map(function (tooltipTriggerEl) {
            return new bootstrap.Tooltip(tooltipTriggerEl)
        });
    });

    function applyFilters() {
        const date = document.getElementById('date_filter').value;
        const block = document.getElementById('block_filter').value;
        const status = document.getElementById('status_filter').value;
        
        let url = '{{ route("attendance.report") }}?';
        if (date) url += `date=${date}&`;
        if (block) url += `block=${block}&`;
        if (status) url += `status=${status}`;
        
        window.location.href = url;
    }
    
    function resetFilters() {
        window.location.href = '{{ route("attendance.report") }}';
    }
    
    function applyDateRange() {
        const startDate = document.getElementById('start_date').value;
        const endDate = document.getElementById('end_date').value;
        const block = document.getElementById('block_filter').value;
        const status = document.getElementById('status_filter').value;
        
        let url = '{{ route("attendance.report") }}?startDate=' + startDate + '&endDate=' + endDate;
        if (block) url += `&block=${block}`;
        if (status) url += `&status=${status}`;
        
        window.location.href = url;
    }
    
    function setDateRange(range) {
        const today = new Date();
        let startDate = new Date();
        let endDate = new Date();
        
        switch(range) {
            case 'today':
                // Start and end date are both today
                break;
            case 'yesterday':
                startDate.setDate(today.getDate() - 1);
                endDate.setDate(today.getDate() - 1);
                break;
            case 'thisWeek':
                // Start date is the first day (Sunday) of current week
                startDate.setDate(today.getDate() - today.getDay());
                break;
            case 'lastWeek':
                // Start date is the first day of last week
                startDate.setDate(today.getDate() - today.getDay() - 7);
                // End date is the last day of last week
                endDate.setDate(today.getDate() - today.getDay() - 1);
                break;
            case 'thisMonth':
                // Start date is the first day of current month
                startDate.setDate(1);
                break;
            case 'lastMonth':
                // Start date is the first day of last month
                startDate.setMonth(today.getMonth() - 1);
                startDate.setDate(1);
                // End date is the last day of last month
                endDate.setDate(0);
                break;
        }
        
        // Format dates to YYYY-MM-DD
        document.getElementById('start_date').value = formatDate(startDate);
        document.getElementById('end_date').value = formatDate(endDate);
        
        // Apply the date range
        applyDateRange();
    }
    
    function formatDate(date) {
        const year = date.getFullYear();
        const month = String(date.getMonth() + 1).padStart(2, '0');
        const day = String(date.getDate()).padStart(2, '0');
        return `${year}-${month}-${day}`;
    }
    
    function exportToExcel() {
        // Get current filter parameters
        const date = document.getElementById('date_filter').value;
        const block = document.getElementById('block_filter').value;
        const status = document.getElementById('status_filter').value;
        const startDate = document.getElementById('start_date').value;
        const endDate = document.getElementById('end_date').value;
        
        let url = '{{ route("attendance.export.excel") }}?format=excel';
        if (date) url += `&date=${date}`;
        if (block) url += `&block=${block}`;
        if (status) url += `&status=${status}`;
        if (startDate) url += `&startDate=${startDate}`;
        if (endDate) url += `&endDate=${endDate}`;
        
        window.location.href = url;
    }
    
    function exportToPDF() {
        // Get current filter parameters
        const date = document.getElementById('date_filter').value;
        const block = document.getElementById('block_filter').value;
        const status = document.getElementById('status_filter').value;
        const startDate = document.getElementById('start_date').value;
        const endDate = document.getElementById('end_date').value;
        
        let url = '{{ route("attendance.export.pdf") }}?format=pdf';
        if (date) url += `&date=${date}`;
        if (block) url += `&block=${block}`;
        if (status) url += `&status=${status}`;
        if (startDate) url += `&startDate=${startDate}`;
        if (endDate) url += `&endDate=${endDate}`;
        
        window.location.href = url;
    }
</script>
@endsection