@extends('components.layout')

@section('title')
    HR - Take Attendance
@endsection

@section('span')
    You are logged in as HR
@endsection

@section('log')
    <a href="#" data-bs-toggle="modal" data-bs-target="#loginModal" class="text-white">(Logout)</a>
@endsection

@section('content')
    <header class="navbar navbar-expand-lg">
        <div class="container-fluid d-flex justify-content-between align-items-center position-relative">
            <a class="navbar-brand" href="#">
                <img src="{{ asset('images/logo.png') }}" alt="Hostel Management Logo" class="logo">
            </a>
            <div class="text-white">
                <span>You are logged in as HR</span>
            </div>
        </div>
    </header>

    <link rel="stylesheet" href="{{ asset('css/hr_style.css') }}">
    <div class="container mt-5">
        <!-- Alert Messages -->
        @if(session('success'))
            <div class="alert alert-success alert-dismissible fade show" role="alert">
                {{ session('success') }}
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
        @endif
        
        @if(session('error'))
            <div class="alert alert-danger alert-dismissible fade show" role="alert">
                {{ session('error') }}
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
        @endif
        
        <div class="card shadow">
            <div class="card-header bg-primary text-white">
                <h3 class="text-center mb-0">Take Attendance</h3>
            </div>
            <div class="card-body">
                <form action="{{ route('hr.attendance.store') }}" method="POST" id="attendanceForm">
                    @csrf
                    
                    <!-- Date Input (Current date, can be changed) -->
                    <div class="row mb-4">
                        <div class="col-md-6 mx-auto">
                            <div class="form-group">
                                <label for="attendance_date" class="form-label">Attendance Date:</label>
                                <input type="date" class="form-control" id="attendance_date" name="attendance_date" value="{{ date('Y-m-d') }}" onchange="if(document.getElementById('room_no').value) getRoomAllocations()">
                            </div>
                        </div>
                    </div>
                    
                    <!-- Block and Room Selection -->
                    <div class="row mb-4">
                        <div class="col-md-6">
                            <div class="form-group">
                                <label for="block_no" class="form-label">Select Block:</label>
                                <select class="form-select" id="block_no" name="block_no" required onchange="getRooms()">
                                    <option value="">-- Select Block --</option>
                                    @foreach ($blocks as $block)
                                        <option value="{{ $block->block_no }}">Block {{ $block->block_no }}</option>
                                    @endforeach
                                </select>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group">
                                <label for="room_no" class="form-label">Select Room:</label>
                                <select class="form-select" id="room_no" name="room_no" required onchange="getRoomAllocations()">
                                    <option value="">-- Select Room --</option>
                                    <!-- Rooms will be populated via JavaScript -->
                                </select>
                            </div>
                        </div>
                    </div>
                    
                    <!-- Students List for Attendance -->
                    <div id="students-container" class="mt-4">
                        <div class="alert alert-info">
                            Please select a block and room to view students
                        </div>
                    </div>
                    
                    <!-- Submit Button (Only shows when students are loaded) -->
                    <div id="submit-button" class="text-center mt-4 d-none">
                        <button type="submit" class="btn btn-primary px-5">Save Attendance</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <!-- JavaScript for Dynamic Content -->
    <script>
        // Get room allocations based on selected block and room
        function getRoomAllocations() {
            const blockNo = document.getElementById('block_no').value;
            const roomNo = document.getElementById('room_no').value;
            const attendanceDate = document.getElementById('attendance_date').value;
            const studentsContainer = document.getElementById('students-container');
            
            // Reset students container
            studentsContainer.innerHTML = '<div class="alert alert-info">Loading room allocations...</div>';
            document.getElementById('submit-button').classList.add('d-none');

            // Ensure both block and room are selected
            if (!blockNo || !roomNo) return;

            // Make an AJAX request to fetch room allocations
            fetch(`/api/room-allocations?block_no=${blockNo}&room_no=${roomNo}&date=${attendanceDate}`)
                .then(response => response.json())
                .then(data => {
                    console.log("API Response:", data); // For debugging
                    
                    if (data.error) {
                        // If error response, show message
                        studentsContainer.innerHTML = `<div class="alert alert-danger">${data.error}</div>`;
                        return;
                    }

                    if (data.length === 0) {
                        studentsContainer.innerHTML = '<div class="alert alert-warning">No room allocations found for this room</div>';
                        document.getElementById('submit-button').classList.add('d-none');
                        return;
                    }

                    // Build the room allocations table
                    let html = `
                        <h4 class="mb-3">Room Allocations for Block ${blockNo}, Room ${roomNo}</h4>
                        <div class="table-responsive">
                            <table class="table table-bordered table-hover">
                                <thead class="table-light">
                                    <tr>
                                        <th>Allocation ID</th>
                                        <th>CID</th>
                                        <th>Block No</th>
                                        <th>Room No</th>
                                        <th>Allocation Date</th>
                                        <th>Status</th>
                                        <th>Remarks</th>
                                    </tr>
                                </thead>
                                <tbody>
                    `;

                    data.forEach(allocation => {
                        let statusHTML = '';
                        
                        if (allocation.on_leave) {
                            // If student is on leave, only show "On Leave" as disabled and checked
                            statusHTML = `
                                <div class="alert alert-info mb-0">
                                    Student is on leave${allocation.leave_reason ? ' - Reason: ' + allocation.leave_reason : ''}
                                </div>
                                <input type="hidden" name="status_${allocation.allocation_id}" value="leave">
                            `;
                        } else {
                            // Normal attendance options
                            statusHTML = `
                                <div class="form-check form-check-inline">
                                    <input class="form-check-input" type="radio" name="status_${allocation.allocation_id}" id="present_${allocation.allocation_id}" value="present" checked>
                                    <label class="form-check-label" for="present_${allocation.allocation_id}">Present</label>
                                </div>
                                <div class="form-check form-check-inline">
                                    <input class="form-check-input" type="radio" name="status_${allocation.allocation_id}" id="absent_${allocation.allocation_id}" value="absent">
                                    <label class="form-check-label" for="absent_${allocation.allocation_id}">Absent</label>
                                </div>
                                <div class="form-check form-check-inline">
                                    <input class="form-check-input" type="radio" name="status_${allocation.allocation_id}" id="leave_${allocation.allocation_id}" value="leave">
                                    <label class="form-check-label" for="leave_${allocation.allocation_id}">On Leave</label>
                                </div>
                            `;
                        }

                        html += `
                            <tr>
                                <td>${allocation.allocation_id}</td>
                                <td>${allocation.cid}</td>
                                <td>${allocation.block_no}</td>
                                <td>${allocation.room_no}</td>
                                <td>${allocation.allocation_date}</td>
                                <td>
                                    ${statusHTML}
                                    <input type="hidden" name="allocation_ids[]" value="${allocation.allocation_id}">
                                </td>
                                <td>
                                    <input type="text" class="form-control form-control-sm" name="remarks_${allocation.allocation_id}" 
                                        placeholder="Optional remarks" 
                                        ${allocation.on_leave ? 'value="On leave' + (allocation.leave_reason ? ' - ' + allocation.leave_reason : '') + '"' : ''}>
                                </td>
                            </tr>
                        `;
                    });

                    html += `
                                </tbody>
                            </table>
                        </div>
                    `;

                    studentsContainer.innerHTML = html;
                    document.getElementById('submit-button').classList.remove('d-none');
                })
                .catch(error => {
                    console.error('Error fetching room allocations:', error);
                    studentsContainer.innerHTML = '<div class="alert alert-danger">An error occurred while fetching room allocations.</div>';
                });
        }

        // Get rooms based on selected block
        function getRooms() {
            const blockNo = document.getElementById('block_no').value;
            const roomSelect = document.getElementById('room_no');
            
            // Clear current options
            roomSelect.innerHTML = '<option value="">-- Select Room --</option>';

            // Reset students container
            document.getElementById('students-container').innerHTML = '<div class="alert alert-info">Please select a block and room to view allocations</div>';
            document.getElementById('submit-button').classList.add('d-none');
            
            if (!blockNo) return;

            // Make an AJAX request to fetch rooms for the selected block
            fetch(`/api/rooms/${blockNo}`)
                .then(response => response.json())
                .then(data => {
                    if (data.length > 0) {
                        // Populate the room select dropdown with the fetched room numbers
                        data.forEach(room => {
                            const option = document.createElement('option');
                            option.value = room.room_no;
                            option.textContent = `Room ${room.room_no}`;
                            roomSelect.appendChild(option);
                        });
                    } else {
                        roomSelect.innerHTML = '<option value="">No rooms available for this block</option>';
                    }
                })
                .catch(error => {
                    console.error('Error fetching rooms:', error);
                    roomSelect.innerHTML = '<option value="">Error fetching rooms</option>';
                });
        }

        // Form submission validation
        document.getElementById('attendanceForm').addEventListener('submit', function(event) {
            const blockNo = document.getElementById('block_no').value;
            const roomNo = document.getElementById('room_no').value;
            const allocationIds = document.querySelectorAll('input[name="allocation_ids[]"]');
            
            if (!blockNo || !roomNo) {
                event.preventDefault();
                alert('Please select a block and room before submitting attendance.');
                return false;
            }
            
            if (allocationIds.length === 0) {
                event.preventDefault();
                alert('No students found to mark attendance for.');
                return false;
            }
            
            return true;
        });
    </script>
@endsection