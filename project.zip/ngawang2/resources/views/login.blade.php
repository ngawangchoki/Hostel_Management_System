<form id="loginForm" method="POST" action="{{ route('login') }}">
    @csrf

    <label for="role">Select Role:</label>
    <select id="role" name="role" onchange="autoFillCredentials()">
        <option value="">Select Role</option>
        <option value="student">Student/Trainee</option>
        <option value="hr">HR</option>
        <option value="warden">Warden</option>
        <option value="matron">Matron</option>
    </select>

    <label for="username">Username:</label>
    <input type="text" id="username" name="username" required>

    <label for="password">Password:</label>
    <input type="password" id="password" name="password" required>

    <button type="submit">Login</button>
</form>

<script>
    function autoFillCredentials() {
        var role = document.getElementById("role").value;
        var usernameField = document.getElementById("username");
        var passwordField = document.getElementById("password");

        if (role === "student") {
            usernameField.value = "ngawang"; // Replace with actual username from DB
            passwordField.value = "123"; // Replace with actual password from DB
            usernameField.readOnly = true;
            passwordField.readOnly = true;
        } else {
            usernameField.value = "";
            passwordField.value = "";
            usernameField.readOnly = false;
            passwordField.readOnly = false;
        }
    }
</script>
