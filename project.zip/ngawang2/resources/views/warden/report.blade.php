@extends('components.layout')

@section('title')
    Warden Dashboard
@endsection

@section('span')
    You are logged in as Warden
@endsection

@section('log')
    <a href="#" data-bs-toggle="modal" data-bs-target="#loginModal" class="text-white">(Logout)</a>
@endsection

@section('content')
    <header class="navbar navbar-expand-lg">
        <div class="container-fluid d-flex justify-content-between align-items-center position-relative">
            <a class="navbar-brand" href="#">
                <img src="{{ asset('images/logo.png') }}" alt="Hostel Management Logo" class="logo">
            </a>
            <div class="text-white">
                <span>You are logged in as Warden</span>
            </div>
        </div>
    </header>

    <link rel="stylesheet" href="{{ asset('css/warden_style.css') }}">

    <!-- Add CSRF Token Meta -->
    <meta name="csrf-token" content="{{ csrf_token() }}">
    
    <div class="container-fluid px-4">
        <!-- Quick Actions Bar -->
        <div class="bg-white rounded-lg shadow-md p-4 mb-6">
            <div class="flex flex-wrap items-center justify-between gap-2">
                <h2 class="text-xl font-bold text-gray-800">Quick Actions</h2>
                <div class="flex flex-wrap gap-2">
                    <a href="{{ route('students.create') }}" class="btn bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-md text-sm flex items-center">
                        <i class="fas fa-user-plus mr-2"></i>New Student
                    </a>
                    <a href="{{ route('room-allocations.create') }}" class="btn bg-green-600 hover:bg-green-700 text-white px-4 py-2 rounded-md text-sm flex items-center">
                        <i class="fas fa-home mr-2"></i>Allocate Room
                    </a>
                    <a href="{{ route('leaves.index') }}?status=pending" class="btn bg-orange-500 hover:bg-orange-600 text-white px-4 py-2 rounded-md text-sm flex items-center">
                        <i class="fas fa-calendar-check mr-2"></i>Review Leaves
                    </a>
                    <a href="{{ route('feedback.index') }}?read=0" class="btn bg-purple-600 hover:bg-purple-700 text-white px-4 py-2 rounded-md text-sm flex items-center">
                        <i class="fas fa-comment-dots mr-2"></i>New Feedback
                    </a>
                </div>
            </div>
        </div> 
        
        <!-- Summary Statistics -->
        <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
            <div class="bg-gradient-to-br from-blue-100 to-blue-50 rounded-xl shadow-md overflow-hidden relative">
                <div class="absolute top-0 right-0 bg-blue-600 p-3 rounded-bl-xl">
                    <i class="fas fa-users text-white text-xl"></i>
                </div>
                <div class="p-5 pt-8">
                    <p class="text-blue-800 font-medium">Total Students</p>
                    <h3 class="text-3xl font-bold mt-2">{{ $students->count() }}</h3>
                    <div class="mt-4 text-sm text-blue-700">
                        <button class="flex items-center hover:underline toggle-section-btn" data-section="student-registration">
                            View Details <i class="fas fa-arrow-right ml-1"></i>
                        </button>
                    </div>
                </div>
            </div>
            
            <div class="bg-gradient-to-br from-green-100 to-green-50 rounded-xl shadow-md overflow-hidden relative">
                <div class="absolute top-0 right-0 bg-green-600 p-3 rounded-bl-xl">
                    <i class="fas fa-door-open text-white text-xl"></i>
                </div>
                <div class="p-5 pt-8">
                    <p class="text-green-800 font-medium">Rooms Allocated</p>
                    <h3 class="text-3xl font-bold mt-2">{{ $roomAllocations->count() }}</h3>
                    <div class="mt-4 text-sm text-green-700">
                        <button class="flex items-center hover:underline toggle-section-btn" data-section="room-allocations">
                            View Details <i class="fas fa-arrow-right ml-1"></i>
                        </button>
                    </div>
                </div>
            </div>
            
            <div class="bg-gradient-to-br from-yellow-100 to-yellow-50 rounded-xl shadow-md overflow-hidden relative">
                <div class="absolute top-0 right-0 bg-yellow-600 p-3 rounded-bl-xl">
                    <i class="fas fa-calendar-alt text-white text-xl"></i>
                </div>
                <div class="p-5 pt-8">
                    <p class="text-yellow-800 font-medium">Active Leave Requests</p>
                    <h3 class="text-3xl font-bold mt-2">{{ $leaves->where('status', 'pending')->count() }}</h3>
                    <div class="mt-4 text-sm text-yellow-700">
                        <button class="flex items-center hover:underline toggle-section-btn" data-section="leave-applications">
                            Review Now <i class="fas fa-arrow-right ml-1"></i>
                        </button>
                    </div>
                </div>
            </div>
            
            <div class="bg-gradient-to-br from-purple-100 to-purple-50 rounded-xl shadow-md overflow-hidden relative">
                <div class="absolute top-0 right-0 bg-purple-600 p-3 rounded-bl-xl">
                    <i class="fas fa-comment-alt text-white text-xl"></i>
                </div>
                <div class="p-5 pt-8">
                    <p class="text-purple-800 font-medium">New Feedback</p>
                    <h3 class="text-3xl font-bold mt-2">{{ $feedback->where('read', false)->count() }}</h3>
                    <div class="mt-4 text-sm text-purple-700">
                        <button class="flex items-center hover:underline toggle-section-btn" data-section="feedback">
                            Read Messages <i class="fas fa-arrow-right ml-1"></i>
                        </button>
                    </div>
                </div>
            </div>
        </div>

        <!-- Main Sections (Initially All Hidden) -->
        
        <!-- Student Registration -->
        <div id="student-registration" class="mb-8 bg-success rounded-xl shadow-md overflow-hidden section-content" style="display: none;">
            <div class="bg-gradient-to-r from-blue-600 to-blue-500 px-6 py-4 flex justify-between items-center">
                <h2 class="text-xl font-bold text-white flex items-center">
                    <i class="fas fa-user-graduate mr-2"></i> Student Registrations
                </h2>
                <div class="flex items-center space-x-3">
                    <form action="{{ route('export.students') }}" method="GET" class="inline">
                        <button type="submit" class="bg-green-600 hover:bg-green-700 text-white text-sm px-3 py-1 rounded flex items-center">
                            <i class="fas fa-file-excel mr-1"></i> Download Excel
                        </button>
                    </form>
                    <button class="text-white hover:text-blue-200 text-sm flex items-center hide-section-btn">
                        <i class="fas fa-times ml-1"></i> Close
                    </button>
                </div>
            </div>
            
            <div class="overflow-x-auto">
                <table class="min-w-full bg-white">
                    <thead class="bg-gray-100">
                        <tr>
                            <th class="py-3 px-4 text-left text-sm font-medium text-gray-600 uppercase">ID</th>
                            <th class="py-3 px-4 text-left text-sm font-medium text-gray-600 uppercase">First Name</th>
                            <th class="py-3 px-4 text-left text-sm font-medium text-gray-600 uppercase">Last Name</th>
                            <th class="py-3 px-4 text-left text-sm font-medium text-gray-600 uppercase">Email</th>
                            <th class="py-3 px-4 text-left text-sm font-medium text-gray-600 uppercase">Gender</th>
                            <th class="py-3 px-4 text-left text-sm font-medium text-gray-600 uppercase">Course</th>
                            <th class="py-3 px-4 text-left text-sm font-medium text-gray-600 uppercase">Phone</th>
                            <th class="py-3 px-4 text-left text-sm font-medium text-gray-600 uppercase">Status</th>
                   
                        </tr>
                    </thead>
                    <tbody class="divide-y divide-gray-200">
                        @forelse($students as $student)
                            <tr class="hover:bg-gray-50">
                                <td class="py-3 px-4">{{ $student->id }}</td>
                                <td class="py-3 px-4">{{ $student->first_name }}</td>
                                <td class="py-3 px-4">{{ $student->last_name }}</td>
                                <td class="py-3 px-4 text-sm">{{ $student->email }}</td>
                                <td class="py-3 px-4">{{ $student->gender }}</td>
                                <td class="py-3 px-4">{{ $student->course }}</td>
                                <td class="py-3 px-4">{{ $student->phone }}</td>
                                <td class="py-3 px-4">
                                    <span class="px-2 py-1 rounded-full text-xs 
                                        {{ $student->status == 'active' ? 'bg-green-100 text-green-800' : 
                                           ($student->status == 'pending' ? 'bg-yellow-100 text-yellow-800' : 'bg-red-100 text-red-800') }}">
                                        {{ ucfirst($student->status) }}
                                    </span>
                                </td>
                                <td class="py-3 px-4">
                                    <div class="flex space-x-2">
                                        <a href="{{ route('students.edit', $student->id) }}" class="text-blue-600 hover:text-blue-800">
                                            <i class="fas fa-edit"></i>
                                        </a>
                                        <a href="{{ route('students.show', $student->id) }}" class="text-green-600 hover:text-green-800">
                                            <i class="fas fa-eye"></i>
                                        </a>
                                    </div>
                                </td>
                            </tr>
                        @empty
                            <tr>
                                <td colspan="9" class="py-4 text-center text-gray-500">No students found</td>
                            </tr>
                        @endforelse
                    </tbody>
                </table>
            </div>
        </div>

        <!-- Room Allocations -->
        <div id="room-allocations" class="mb-8 bg-success rounded-xl shadow-md overflow-hidden section-content" style="display: none;">
            <div class="bg-gradient-to-r from-green-600 to-green-500 px-6 py-4 flex justify-between items-center">
                <h2 class="text-xl font-bold text-white flex items-center">
                    <i class="fas fa-home mr-2"></i> Room Allocations
                </h2>
                <div class="flex items-center space-x-3">
                    <form action="{{ route('export.room-allocations') }}" method="GET" class="inline">
                        <button type="submit" class="bg-green-600 hover:bg-green-700 text-white text-sm px-3 py-1 rounded flex items-center">
                            <i class="fas fa-file-excel mr-1"></i> Download Excel
                        </button>
                    </form>
                    <button class="text-white hover:text-green-200 text-sm flex items-center hide-section-btn">
                        <i class="fas fa-times ml-1"></i> Close
                    </button>
                </div>
            </div>
            
            <div class="overflow-x-auto">
                <table class="min-w-full bg-white">
                    <thead class="bg-gray-100">
                        <tr>
                            <th class="py-3 px-4 text-left text-sm font-medium text-gray-600 uppercase">ID</th>
                            <th class="py-3 px-4 text-left text-sm font-medium text-gray-600 uppercase">CID</th>
                            <th class="py-3 px-4 text-left text-sm font-medium text-gray-600 uppercase">Block Number</th>
                            <th class="py-3 px-4 text-left text-sm font-medium text-gray-600 uppercase">Room Number</th>
                            <th class="py-3 px-4 text-left text-sm font-medium text-gray-600 uppercase">Allocation Date</th>
                            <th class="py-3 px-4 text-left text-sm font-medium text-gray-600 uppercase">Created At</th>
                           
                        </tr>
                    </thead>
                    <tbody class="divide-y divide-gray-200">
                        @forelse($roomAllocations as $allocation)
                            <tr class="hover:bg-gray-50">
                                <td class="py-3 px-4">{{ $allocation->allocation_id }}</td>
                                <td class="py-3 px-4">{{ $allocation->student->cid ?? 'N/A' }}</td>
                                <td class="py-3 px-4">{{ $allocation->block_no }}</td>
                                <td class="py-3 px-4">{{ $allocation->room_no }}</td>
                                <td class="py-3 px-4">{{ $allocation->allocation_date }}</td>
                                <td class="py-3 px-4">{{ $allocation->created_at->format('Y-m-d') }}</td>
                                <td class="py-3 px-4">
                                    <div class="flex space-x-2">
                                        <a href="{{ route('room-allocations.edit', $allocation->allocation_id) }}" class="text-blue-600 hover:text-blue-800">
                                            <i class="fas fa-edit"></i>
                                        </a>
                                        <a href="{{ route('room-allocations.show', $allocation->allocation_id) }}" class="text-green-600 hover:text-green-800">
                                            <i class="fas fa-eye"></i>
                                        </a>
                                    </div>
                                </td>
                            </tr>
                        @empty
                            <tr>
                                <td colspan="7" class="py-4 text-center text-gray-500">No room allocations found</td>
                            </tr>
                        @endforelse
                    </tbody>
                </table>
            </div>
        </div>

        <!-- Leave Applications -->
        <div id="leave-applications" class="mb-8 bg-success rounded-xl shadow-md overflow-hidden section-content" style="display: none;">
            <div class="bg-gradient-to-r from-yellow-600 to-yellow-500 px-6 py-4 flex justify-between items-center">
                <h2 class="text-xl font-bold text-white flex items-center">
                    <i class="fas fa-calendar-check mr-2"></i> Leave Applications
                </h2>
                <div class="flex items-center space-x-3">
                    <form action="{{ route('export.leaves') }}" method="GET" class="inline">
                        <button type="submit" class="bg-green-600 hover:bg-green-700 text-white text-sm px-3 py-1 rounded flex items-center">
                            <i class="fas fa-file-excel mr-1"></i> Download Excel
                        </button>
                    </form>
                    <button class="text-white hover:text-yellow-200 text-sm flex items-center hide-section-btn">
                        <i class="fas fa-times ml-1"></i> Close
                    </button>
                </div>
            </div>
            
            <div class="overflow-x-auto">
                <table class="min-w-full bg-white">
                    <thead class="bg-gray-100">
                        <tr>
                            <th class="py-3 px-4 text-left text-sm font-medium text-gray-600 uppercase">ID</th>
                            <th class="py-3 px-4 text-left text-sm font-medium text-gray-600 uppercase">CID</th>
                            <th class="py-3 px-4 text-left text-sm font-medium text-gray-600 uppercase">Start Date</th>
                            <th class="py-3 px-4 text-left text-sm font-medium text-gray-600 uppercase">End Date</th>
                            <th class="py-3 px-4 text-left text-sm font-medium text-gray-600 uppercase">Reason</th>
                            <th class="py-3 px-4 text-left text-sm font-medium text-gray-600 uppercase">Cancel Message</th>
                            <th class="py-3 px-4 text-left text-sm font-medium text-gray-600 uppercase">Status</th>
                        </tr>
                    </thead>
                    <tbody class="divide-y divide-gray-200">
                        @forelse($leaves as $leave)
                            <tr class="hover:bg-gray-50">
                                <td class="py-3 px-4">{{ $leave->id }}</td>
                                <td class="py-3 px-4">{{ $leave->cid ?? 'N/A' }}</td>
                                <td class="py-3 px-4">{{ $leave->leave_start_date }}</td>
                                <td class="py-3 px-4">{{ $leave->leave_end_date }}</td>
                                <td class="py-3 px-4">{{ Str::limit($leave->leave_reason, 30) }}</td>
                                <td class="py-3 px-4">{{ Str::limit($leave->cancel_message, 30) }}</td>
                                <td class="py-3 px-4">
                                    <span class="px-2 py-1 rounded-full text-xs 
                                        {{ $leave->status == 'approved' ? 'bg-green-100 text-green-800' : 
                                           ($leave->status == 'pending' ? 'bg-yellow-100 text-yellow-800' : 'bg-red-100 text-red-800') }}">
                                        {{ ucfirst($leave->status) }}
                                    </span>
                                </td>
                                <td class="py-3 px-4">
                                    <div class="flex space-x-2">
                                        @if($leave->status == 'pending')
                                            <a href="{{ route('leaves.approve', $leave->id) }}" class="text-green-600 hover:text-green-800">
                                                <i class="fas fa-check"></i>
                                            </a>
                                            <a href="{{ route('leaves.reject', $leave->id) }}" class="text-red-600 hover:text-red-800">
                                                <i class="fas fa-times"></i>
                                            </a>
                                        @endif
                                        <a href="{{ route('leaves.show', $leave->id) }}" class="text-blue-600 hover:text-blue-800">
                                            <i class="fas fa-eye"></i>
                                        </a>
                                    </div>
                                </td>
                            </tr>
                        @empty
                            <tr>
                                <td colspan="8" class="py-4 text-center text-gray-500">No leave applications found</td>
                            </tr>
                        @endforelse
                    </tbody>
                </table>
            </div>
        </div>

        <!-- Feedback -->
        <div id="feedback" class="mb-8 bg-success rounded-xl shadow-md overflow-hidden section-content" style="display: none;">
            <div class="bg-gradient-to-r from-purple-600 to-purple-500 px-6 py-4 flex justify-between items-center">
                <h2 class="text-xl font-bold text-white flex items-center">
                    <i class="fas fa-comment-alt mr-2"></i> Student Feedback
                </h2>
                <div class="flex items-center space-x-3">
                    <form action="{{ route('export.feedback') }}" method="GET" class="inline">
                        <button type="submit" class="bg-green-600 hover:bg-green-700 text-white text-sm px-3 py-1 rounded flex items-center">
                            <i class="fas fa-file-excel mr-1"></i> Download Excel
                        </button>
                    </form>
                    <button class="text-white hover:text-purple-200 text-sm flex items-center hide-section-btn">
                        <i class="fas fa-times ml-1"></i> Close
                    </button>
                </div>
            </div>
            
            <div class="overflow-x-auto">
                <table class="min-w-full bg-white">
                    <thead class="bg-gray-100">
                        <tr>
                            <th class="py-3 px-4 text-left text-sm font-medium text-gray-600 uppercase">ID</th>
                            <th class="py-3 px-4 text-left text-sm font-medium text-gray-600 uppercase">Name</th>
                            <th class="py-3 px-4 text-left text-sm font-medium text-gray-600 uppercase">Email</th>
                            <th class="py-3 px-4 text-left text-sm font-medium text-gray-600 uppercase">Subject</th>
                            <th class="py-3 px-4 text-left text-sm font-medium text-gray-600 uppercase">Category</th>
                            <th class="py-3 px-4 text-left text-sm font-medium text-gray-600 uppercase">Message</th>
                            <th class="py-3 px-4 text-left text-sm font-medium text-gray-600 uppercase">Rating</th>
                            <th class="py-3 px-4 text-left text-sm font-medium text-gray-600 uppercase">is_resolved</th>
                        </tr>
                    </thead>
                    <tbody class="divide-y divide-gray-200">
                        @forelse($feedback as $item)
                            <tr class="{{ $item->read ? '' : 'bg-purple-50' }} hover:bg-gray-50">
                                <td class="py-3 px-4">{{ $item->id }}</td>
                                <td class="py-3 px-4">{{ $item->name ?? 'N/A' }}</td>
                                <td class="py-3 px-4">{{ $item->email }}</td>
                                <td class="py-3 px-4">{{ $item->subject }}</td>
                                <td class="py-3 px-4">{{ $item->category }}</td>
                                <td class="py-3 px-4">{{ $item->message }}</td>
                                <td class="py-3 px-4">{{ $item->rating }}</td>
                                <td class="py-3 px-4">{{ $item->is_resolved }}</td>


                                
                                <td class="py-3 px-4">
                                    <div class="flex space-x-2">
                                        <a href="{{ route('feedback.show', $item->id) }}" class="text-blue-600 hover:text-blue-800">
                                            <i class="fas fa-eye"></i>
                                        </a>
                                        @if(!$item->is_resolved)
                                            <a href="{{ route('feedback.mark-resolved', $item->id) }}" class="text-green-600 hover:text-green-800">
                                                <i class="fas fa-check"></i>
                                            </a>
                                        @endif
                                    </div>
                                </td>
                            </tr>
                        @empty
                            <tr>
                                <td colspan="9" class="py-4 text-center text-gray-500">No feedback found</td>
                            </tr>
                        @endforelse
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <!-- Add jQuery for easier DOM manipulation (add this before your script) -->
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    
    <script>
        $(document).ready(function() {
            // Toggle section functionality - show the selected section
            $('.toggle-section-btn').click(function() {
                var sectionId = $(this).data('section');
                
                // Hide all sections first
                $('.section-content').hide();
                
                // Show the selected section
                $('#' + sectionId).fadeIn();
                
                // Scroll to the section
                $('html, body').animate({
                    scrollTop: $('#' + sectionId).offset().top - 20
                }, 500);
            });
            
            // Hide section when close button is clicked
            $('.hide-section-btn').click(function() {
                $(this).closest('.section-content').fadeOut();
            });
        });
    </script>
@endsection