@extends('components.layout')

@section('title')
    Warden Dashboard
@endsection

@section('span')
    You are logged in as Warden
@endsection

@section('log')
    <a href="#" data-bs-toggle="modal" data-bs-target="#loginModal" class="text-white">(Logout)</a>
@endsection

@section('content')
    <header class="navbar navbar-expand-lg">
        <div class="container-fluid d-flex justify-content-between align-items-center position-relative">
            <a class="navbar-brand" href="#">
                <img src="{{ asset('images/logo.png') }}" alt="Hostel Management Logo" class="logo">
            </a>
            <div class="text-white">
                <span>You are logged in as Warden</span>
            </div>
        </div>
    </header>

    <link rel="stylesheet" href="{{ asset('css/warden_style.css') }}">

    <!-- Add CSRF Token Meta -->
    <meta name="csrf-token" content="{{ csrf_token() }}">

    <div class="d-flex" style="min-height: 100vh;">
        <div class="sidebar bg-primary text-white p-4" style="width: 250px; height: 100vh; position: sticky;">
            <h4 class="text-center text-white mb-4">Warden Dashboard</h4>
            <ul class="list-unstyled">
                <li>
                    <a href="#"
                        class="nav-link text-white sidebar-link py-2 d-block px-3 rounded mb-2 position-relative"
                        data-section="viewStudentRegistration">
                        <i class="bi bi-person-check"></i> View Student Registrations
                        <span
                            class="position-absolute top-0 start-100 translate-middle badge rounded-pill bg-danger notification-badge"
                            id="studentNotificationBadge" style="display: none;">
                            <span id="studentNotificationCount">0</span>
                            <span class="visually-hidden">unread notifications</span>
                        </span>
                    </a>
                </li>
                <li>
                    <a href="{{ route('warden.roomAllocation') }}"
                        class="text-white sidebar-link py-2 d-block px-3 rounded mb-2 position-relative">
                        <i class="bi bi-door-open"></i> Room Allocation
                        <span
                            class="position-absolute top-0 start-100 translate-middle badge rounded-pill bg-danger notification-badge"
                            id="roomNotificationBadge" style="display: none;">
                            <span id="roomNotificationCount">0</span>
                            <span class="visually-hidden">unread notifications</span>
                        </span>
                    </a>
                </li>
                <li>
                    <a href="#"
                        class="nav-link text-white sidebar-link py-2 d-block px-3 rounded mb-2 position-relative"
                        data-section="viewLeaveDetails">
                        <i class="bi bi-file-earmark-text"></i> View Leave Details
                        <span
                            class="position-absolute top-0 start-100 translate-middle badge rounded-pill bg-danger notification-badge"
                            id="leaveNotificationBadge" style="display: none;">
                            <span id="leaveNotificationCount">0</span>
                            <span class="visually-hidden">unread notifications</span>
                        </span>
                    </a>
                </li>
                <li>
                    <a href="#"
                        class="nav-link text-white sidebar-link py-2 d-block px-3 rounded mb-2 position-relative"
                        data-section="feedbacks">
                        <i class="bi bi-chat-left-text"></i> Feedbacks
                        <span
                            class="position-absolute top-0 start-100 translate-middle badge rounded-pill bg-danger notification-badge"
                            id="feedbackNotificationBadge" style="display: none;">
                            <span id="feedbackNotificationCount">0</span>
                            <span class="visually-hidden">unread notifications</span>
                        </span>
                    </a>
                </li>
                <li>
                    <a href="{{ route('warden.report') }}" class="nav-link text-white sidebar-link py-2 d-block px-3 rounded mb-2 position-relative">
                        <i class="bi bi-bar-chart-line"></i> Reports
                        <!-- Note: No data-section attribute here -->
                        <span class="position-absolute top-0 start-100 translate-middle badge rounded-pill bg-danger notification-badge" id="reportNotificationBadge" style="display: none;">
                            <span id="reportNotificationCount">0</span>
                            <span class="visually-hidden">unread notifications</span>
                        </span>
                    </a>
                </li>
            </ul>
        </div>

        <div class="main-content p-4" style="flex-grow: 1;">
            <!-- Debug info section -->
            <div id="debug-info" class="alert alert-info mb-3" style="display: none;">
                Debug information will appear here
            </div>

            @if (session('success'))
                <div class="alert alert-success">{{ session('success') }}</div>
            @endif

            <!-- View Student Registrations -->
            <div id="viewStudentRegistration" class="section d-none">

                <h3 class="mb-4 text-center text-primary">Student Registrations</h3>
                <div class="alert alert-info" id="newStudentRegistrationsAlert" style="display: none;">
                    <i class="bi bi-bell"></i> You have new student registrations that need your attention!
                </div>
                <div id="studentRegistrations">
                    <table class="table table-bordered table-striped">
                        <thead>
                            <tr>
                                <th>CID</th>
                                <th>First Name</th>
                                <th>Last Name</th>
                                <th>Email</th>
                                <th>Phone</th>
                                <th>Address</th>
                                <th>Gender</th>
                                <th>Date of Birth</th>
                                <th>Course</th>
                                <th>Status</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <!-- Student registrations will be loaded here -->
                        </tbody>
                    </table>
                </div>
            </div>

            <!-- Room Allocation -->
            <div id="roomAllocation" class="section d-none">
                <h3 class="mb-4 text-center text-primary">Room Allocation</h3>
                <div class="alert alert-info" id="newRoomAllocationAlert" style="display: none;">
                    <i class="bi bi-bell"></i> You have new room allocation requests that need your attention!
                </div>
                <!-- Room allocation content -->
            </div>

            <!-- View Leave Details -->
            <div id="viewLeaveDetails" class="section d-none">
                <h3 class="mb-4 text-center text-primary">Leave Requests</h3>
                <div class="alert alert-info" id="newLeaveRequestsAlert" style="display: none;">
                    <i class="bi bi-bell"></i> You have new leave requests that need your attention!
                </div>
                <div id="leaveRequests">
                    <table class="table table-bordered table-striped">
                        <thead>
                            <tr>
                                <th>CID</th>
                                <th>Leave From</th>
                                <th>Leave Till</th>
                                <th>Reason</th>
                                <th>Status</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <!-- Leave requests will be loaded here -->
                        </tbody>
                    </table>
                </div>
            </div>

            <!-- Feedbacks -->
            <!-- First, let's update the feedbacks section in the dashboard -->
            <div id="feedbacks" class="section d-none">
                <h3 class="mb-4 text-center text-primary">Student Feedbacks</h3>
                <div class="alert alert-info" id="newFeedbacksAlert" style="display: none;">
                    <i class="bi bi-bell"></i> You have new feedback submissions that need your attention!
                </div>
                <div id="feedbacksTable">
                    <table class="table table-bordered table-striped">
                        <thead>
                            <tr>
                                <th>ID</th>
                                <th>Name</th>
                                <th>Email</th>
                                <th>Subject</th>
                                <th>Category</th>
                                <th>Message</th>
                                <th>Rating</th>
                                <th>Date</th>
                                <th>Status</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <!-- Feedbacks will be loaded here -->
                        </tbody>
                    </table>
                </div>
            </div>


            <!-- Reports -->
            <div id="reports" class="section d-none">
                <h3 class="mb-4 text-center text-primary">Reports</h3>
                <div class="alert alert-info" id="newReportsAlert" style="display: none;">
                    <i class="bi bi-bell"></i> You have new reports that need your attention!
                </div>
                <!-- Reports content -->
            </div>
        </div>
    </div>

    <script>
        document.addEventListener('DOMContentLoaded', function() {
            // Debug function
            function debug(message) {
                const debugElement = document.getElementById('debug-info');
                debugElement.style.display = 'block';
                debugElement.textContent = message;
                console.log(message);
            }

            // Get CSRF token
            const csrfToken = document.querySelector('meta[name="csrf-token"]').getAttribute('content');

            // Initialize notification storage
            const notificationStorage = {
                initialize() {
                    // Get notifications from localStorage or create if not exist
                    let stored = localStorage.getItem('wardenNotifications');
                    if (!stored) {
                        this.data = {
                            students: {
                                viewed: new Set(),
                                count: 0
                            },
                            leaves: {
                                viewed: new Set(),
                                count: 0
                            },
                            rooms: {
                                viewed: new Set(),
                                count: 0
                            },
                            feedbacks: {
                                viewed: new Set(),
                                count: 0
                            },
                            reports: {
                                viewed: new Set(),
                                count: 0
                            }
                        };
                        this.saveToStorage();
                    } else {
                        const parsed = JSON.parse(stored);
                        this.data = {
                            students: {
                                viewed: new Set(parsed.students.viewed),
                                count: parsed.students.count
                            },
                            leaves: {
                                viewed: new Set(parsed.leaves.viewed),
                                count: parsed.leaves.count
                            },
                            rooms: {
                                viewed: new Set(parsed.rooms.viewed),
                                count: parsed.rooms.count
                            },
                            feedbacks: {
                                viewed: new Set(parsed.feedbacks.viewed),
                                count: parsed.feedbacks.count
                            },
                            reports: {
                                viewed: new Set(parsed.reports.viewed),
                                count: parsed.reports.count
                            }
                        };
                    }
                },
                saveToStorage() {
                    const toSave = {
                        students: {
                            viewed: Array.from(this.data.students.viewed),
                            count: this.data.students.count
                        },
                        leaves: {
                            viewed: Array.from(this.data.leaves.viewed),
                            count: this.data.leaves.count
                        },
                        rooms: {
                            viewed: Array.from(this.data.rooms.viewed),
                            count: this.data.rooms.count
                        },
                        feedbacks: {
                            viewed: Array.from(this.data.feedbacks.viewed),
                            count: this.data.feedbacks.count
                        },
                        reports: {
                            viewed: Array.from(this.data.reports.viewed),
                            count: this.data.reports.count
                        }
                    };
                    localStorage.setItem('wardenNotifications', JSON.stringify(toSave));
                },
                markAsViewed(type, id) {
                    if (this.data[type]) {
                        this.data[type].viewed.add(id);
                        this.saveToStorage();
                    }
                },
                hasViewed(type, id) {
                    return this.data[type] && this.data[type].viewed.has(id);
                },
                updateCount(type, count) {
                    if (this.data[type]) {
                        this.data[type].count = count;
                        this.saveToStorage();
                    }
                },
                getCount(type) {
                    return this.data[type] ? this.data[type].count : 0;
                },
                clearSection(type) {
                    if (this.data[type]) {
                        this.data[type].count = 0;
                        this.saveToStorage();
                    }
                }
            };

            // Initialize the notification storage
            notificationStorage.initialize();

            // Navigation links
            document.querySelectorAll('.nav-link').forEach(link => {
    link.addEventListener('click', function(e) {
        const sectionId = this.getAttribute('data-section');
        if (sectionId) {
            e.preventDefault(); // Only prevent default for section links
            showSection(sectionId);
        }
        // Let the natural link behavior happen for non-section links (like Reports)
    });
});

            // Function to show section
            function showSection(sectionId) {
                // Hide all sections
                document.querySelectorAll('.section').forEach(section => {
                    section.classList.add('d-none');
                });

                const activeSection = document.getElementById(sectionId);
                if (activeSection) {
                    activeSection.classList.remove('d-none');

                    // Handle section-specific actions
                    switch (sectionId) {
                        case 'viewStudentRegistration':
                            fetchStudentRegistrations();
                            clearSectionNotifications('students');
                            break;
                        case 'roomAllocation':
                            fetchRoomAllocations();
                            clearSectionNotifications('rooms');
                            break;
                        case 'viewLeaveDetails':
                            fetchLeaveRequests();
                            clearSectionNotifications('leaves');
                            break;
                        case 'feedbacks':
                            fetchFeedbacks();
                            clearSectionNotifications('feedbacks');
                            break;
                        case 'reports':
                            fetchReports();
                            clearSectionNotifications('reports');
                            break;
                    }
                }
            }
            // Function to clear section notifications
            function clearSectionNotifications(type) {
                notificationStorage.clearSection(type);
                updateBadges();

                // Hide section alert if visible
                switch (type) {
                    case 'students':
                        document.getElementById('newStudentRegistrationsAlert').style.display = 'none';
                        break;
                    case 'leaves':
                        document.getElementById('newLeaveRequestsAlert').style.display = 'none';
                        break;
                    case 'rooms':
                        document.getElementById('newRoomAllocationAlert').style.display = 'none';
                        break;
                    case 'feedbacks':
                        document.getElementById('newFeedbacksAlert').style.display = 'none';
                        break;
                    case 'reports':
                        document.getElementById('newReportsAlert').style.display = 'none';
                        break;
                }
            }

            // Update all notification badges
            function updateBadges() {
                updateBadge('student', notificationStorage.getCount('students'));
                updateBadge('leave', notificationStorage.getCount('leaves'));
                updateBadge('room', notificationStorage.getCount('rooms'));
                updateBadge('feedback', notificationStorage.getCount('feedbacks'));
                updateBadge('report', notificationStorage.getCount('reports'));
            }

            // Update specific badge count
            function updateBadge(type, count) {
                const badge = document.getElementById(`${type}NotificationBadge`);
                const countElement = document.getElementById(`${type}NotificationCount`);

                if (count > 0) {
                    countElement.textContent = count;
                    badge.style.display = 'block';
                } else {
                    badge.style.display = 'none';
                }
            }

            // Check for new notifications periodically
            function startNotificationCheck() {
                // Check for new notifications every 30 seconds
                setInterval(() => {
                    checkForNewNotifications();
                }, 30000);

                // Initial check
                checkForNewNotifications();
            }

            // Check for all types of new notifications
            function checkForNewNotifications() {
                checkForNewStudentRegistrations();
                checkForNewLeaveRequests();
                // Add future notification checks here
                // checkForNewRoomAllocations();
                // checkForNewFeedbacks();
                // checkForNewReports();
            }

            // Check for new student registrations
            function checkForNewStudentRegistrations() {
                // Only check if not currently viewing that section
                if (document.getElementById('viewStudentRegistration').classList.contains('d-none')) {
                    fetch("{{ route('warden.studentRegistrations') }}")
                        .then(response => response.json())
                        .then(data => {
                            let newCount = 0;

                            data.forEach(student => {
                                if (student.status && student.status.toLowerCase() === 'pending' &&
                                    !notificationStorage.hasViewed('students', student.id)) {
                                    newCount++;
                                }
                            });

                            if (newCount > 0) {
                                notificationStorage.updateCount('students', newCount);
                                updateBadge('student', newCount);
                            }
                        })
                        .catch(error => {
                            debug(`Error checking student registrations: ${error.message}`);
                        });
                }
            }

            // Check for new leave requests
            function checkForNewLeaveRequests() {
                // Only check if not currently viewing that section
                if (document.getElementById('viewLeaveDetails').classList.contains('d-none')) {
                    fetch("{{ route('leave.requests') }}")
                        .then(response => response.json())
                        .then(data => {
                            let newCount = 0;

                            data.forEach(request => {
                                const requestId = request.id.toString();

                                // Count pending requests
                                if (request.status && request.status.toLowerCase() === 'pending' &&
                                    !notificationStorage.hasViewed('leaves', requestId)) {
                                    newCount++;
                                }

                                // Count cancelled requests
                                if (request.status && request.status.toLowerCase() === 'cancelled' &&
                                    !notificationStorage.hasViewed('leaves', `${requestId}-cancelled`)
                                    ) {
                                    newCount++;
                                }
                            });

                            if (newCount > 0) {
                                notificationStorage.updateCount('leaves', newCount);
                                updateBadge('leave', newCount);
                            }
                        })
                        .catch(error => {
                            debug(`Error checking leave requests: ${error.message}`);
                        });
                }
            }

            // Fetch student registrations
            function fetchStudentRegistrations() {
                debug('Fetching student registrations...');

                fetch("{{ route('warden.studentRegistrations') }}")
                    .then(response => {
                        if (!response.ok) {
                            throw new Error('Network response was not ok');
                        }
                        return response.json();
                    })
                    .then(data => {
                        debug(`Received ${data.length} student registrations`);
                        const tbody = document.querySelector('#studentRegistrations tbody');
                        tbody.innerHTML = '';

                        let hasNewRequests = false;

                        if (data.length > 0) {
                            data.forEach(student => {
                                const status = student.status || 'unknown';
                                const studentId = student.id.toString();

                                // Mark as viewed
                                if (!notificationStorage.hasViewed('students', studentId)) {
                                    notificationStorage.markAsViewed('students', studentId);
                                    if (status.toLowerCase() === 'pending') {
                                        hasNewRequests = true;
                                    }
                                }

                                let statusBadge;
                                let rowClass = '';

                                switch (status.toLowerCase()) {
                                    case 'pending':
                                        statusBadge = '<span class="badge bg-warning">Pending</span>';
                                        rowClass = 'table-warning';
                                        break;
                                    case 'approved':
                                        statusBadge = '<span class="badge bg-success">Approved</span>';
                                        break;
                                    case 'disapproved':
                                        statusBadge =
                                        '<span class="badge bg-danger">Disapproved</span>';
                                        break;
                                    default:
                                        statusBadge = '<span class="badge bg-secondary">Unknown</span>';
                                        break;
                                }

                                const row = document.createElement('tr');
                                if (rowClass) row.className = rowClass;

                                row.innerHTML = `
                                    <td>${student.cid || ''}</td>
                                    <td>${student.first_name || ''}</td>
                                    <td>${student.last_name || ''}</td>
                                    <td>${student.email || ''}</td>
                                    <td>${student.phone || ''}</td>
                                    <td>${student.address || ''}</td>
                                    <td>${student.gender || ''}</td>
                                    <td>${student.dob || ''}</td>
                                    <td>${student.course || ''}</td>
                                    <td>${statusBadge}</td>
                                    <td>
                                        <button type="button" class="btn btn-success btn-sm student-action" data-action="approve" data-id="${student.id}" ${status.toLowerCase() !== 'pending' ? 'disabled' : ''}>Approve</button>
                                        <button type="button" class="btn btn-danger btn-sm student-action" data-action="disapprove" data-id="${student.id}" ${status.toLowerCase() !== 'pending' ? 'disabled' : ''}>Disapprove</button>
                                    </td>
                                `;
                                tbody.appendChild(row);
                            });

                            // Show alert if there are new requests
                            if (hasNewRequests) {
                                document.getElementById('newStudentRegistrationsAlert').style.display = 'block';
                            }

                            // Add event listeners to student action buttons
                            document.querySelectorAll('#studentRegistrations .student-action').forEach(
                            button => {
                                button.addEventListener('click', handleStudentAction);
                            });
                        } else {
                            tbody.innerHTML =
                                '<tr><td colspan="11" class="text-center">No student registrations found</td></tr>';
                        }
                    })
                    .catch(error => {
                        debug(`Error fetching student registrations: ${error.message}`);
                    });
            }

            // Handle student action (approve/disapprove)
            function handleStudentAction(e) {
                const button = e.target;
                const action = button.getAttribute('data-action');
                const studentId = button.getAttribute('data-id');

                debug(`Student action: ${action} for ID: ${studentId}`);

                let url;
                if (action === 'approve') {
                    url = `{{ route('warden.studentRegistration.approve', '') }}/${studentId}`;
                } else if (action === 'disapprove') {
                    url = `{{ route('warden.studentRegistration.disapprove', '') }}/${studentId}`;
                } else {
                    return;
                }

                // Disable the button while processing
                button.disabled = true;
                button.textContent = 'Processing...';

                fetch(url, {
                        method: 'POST',
                        headers: {
                            'Content-Type': 'application/json',
                            'X-CSRF-TOKEN': csrfToken
                        }
                    })
                    .then(response => {
                        if (!response.ok) {
                            throw new Error('Network response was not ok');
                        }
                        return response.json();
                    })
                    .then(data => {
                        alert(data.message || 'Action processed successfully');
                        fetchStudentRegistrations(); // Refresh the list
                    })
                    .catch(error => {
                        debug(`Error processing student ${action}: ${error.message}`);
                        alert(`Error: ${error.message}`);
                        button.disabled = false;
                        button.textContent = action.charAt(0).toUpperCase() + action.slice(1);
                    });
            }

            // Fetch leave requests
            // Modified fetchLeaveRequests function with better error handling
function fetchLeaveRequests() {
    debug('Fetching leave requests...');

    fetch("{{ route('leave.requests') }}")
        .then(response => {
            // First check if the response is OK
            if (!response.ok) {
                throw new Error(`Server returned ${response.status}: ${response.statusText}`);
            }
            
            // Check the content type of the response
            const contentType = response.headers.get('content-type');
            if (!contentType || !contentType.includes('application/json')) {
                throw new Error(`Expected JSON but got ${contentType}`);
            }
            
            return response.json();
        })
        .then(data => {
            debug(`Received ${data.length} leave requests`);
            const tbody = document.querySelector('#leaveRequests tbody');
            tbody.innerHTML = '';

            let hasNewRequests = false;

            if (data.length > 0) {
                data.forEach(request => {
                    const status = request.status || 'unknown';
                    const requestId = request.id.toString();

                    // Mark as viewed
                    if (!notificationStorage.hasViewed('leaves', requestId)) {
                        notificationStorage.markAsViewed('leaves', requestId);

                        if (status.toLowerCase() === 'pending') {
                            hasNewRequests = true;
                        }
                    }

                    // Mark cancelled status as viewed
                    if (status.toLowerCase() === 'cancelled') {
                        const cancelledId = `${requestId}-cancelled`;
                        if (!notificationStorage.hasViewed('leaves', cancelledId)) {
                            notificationStorage.markAsViewed('leaves', cancelledId);
                            hasNewRequests = true;
                        }
                    }

                    let statusBadge;
                    let rowClass = '';

                    switch (status.toLowerCase()) {
                        case 'pending':
                            statusBadge = '<span class="badge bg-warning">Pending</span>';
                            rowClass = 'table-warning';
                            break;
                        case 'approved':
                            statusBadge = '<span class="badge bg-success">Approved</span>';
                            break;
                        case 'cancelled':
                            statusBadge = '<span class="badge bg-warning">Cancelled</span>';
                            rowClass = 'table-info';
                            break;
                        case 'disapproved':
                            statusBadge = '<span class="badge bg-danger">Disapproved</span>';
                            break;
                        default:
                            statusBadge = '<span class="badge bg-secondary">Unknown</span>';
                            break;
                    }

                    const row = document.createElement('tr');
                    if (rowClass) row.className = rowClass;

                    row.innerHTML = `
                        <td>${request.cid || ''}</td>
                        <td>${request.leave_start_date || ''}</td>
                        <td>${request.leave_end_date || ''}</td>
                        <td>${request.leave_reason || ''}</td>
                        <td>${statusBadge}</td>
                        <td>
                            <button type="button" class="btn btn-success btn-sm leave-action" data-action="approve" data-id="${request.id}" ${status.toLowerCase() !== 'pending' ? 'disabled' : ''}>Approve</button>
                            <button type="button" class="btn btn-danger btn-sm leave-action" data-action="disapprove" data-id="${request.id}" ${status.toLowerCase() !== 'pending' ? 'disabled' : ''}>Disapprove</button>
                        </td>
                    `;
                    tbody.appendChild(row);
                });

                // Show alert if there are new requests
                if (hasNewRequests) {
                    document.getElementById('newLeaveRequestsAlert').style.display = 'block';
                }

                // Add event listeners to leave action buttons
                document.querySelectorAll('#leaveRequests .leave-action').forEach(button => {
                    button.addEventListener('click', handleLeaveAction);
                });
            } else {
                tbody.innerHTML = '<tr><td colspan="6" class="text-center">No leave requests found</td></tr>';
            }
        })
        .catch(error => {
            debug(`Error fetching leave requests: ${error.message}`);
            
            // Display a more user-friendly error in the table
            const tbody = document.querySelector('#leaveRequests tbody');
            tbody.innerHTML = `<tr><td colspan="6" class="text-center text-danger">
                <strong>Error loading leave requests.</strong><br>
                <small>Please check your connection or try again later.</small>
                <button class="btn btn-sm btn-outline-primary mt-2" onclick="fetchLeaveRequests()">
                    <i class="bi bi-arrow-clockwise"></i> Retry
                </button>
            </td></tr>`;
        });
}

// Also modify the checkForNewLeaveRequests function for better error handling
function checkForNewLeaveRequests() {
    // Only check if not currently viewing that section
    if (document.getElementById('viewLeaveDetails').classList.contains('d-none')) {
        fetch("{{ route('leave.requests') }}")
    .then(response => {
        // Check if response is OK
        if (!response.ok) {
            console.error('Response status:', response.status);
            // Clone the response to inspect it
            return response.clone().text().then(text => {
                console.error('Response content:', text);
                throw new Error(`Server returned ${response.status}: ${response.statusText}`);
            });
        }
        return response.json();
    })
            .then(data => {
                let newCount = 0;

                data.forEach(request => {
                    const requestId = request.id.toString();

                    // Count pending requests
                    if (request.status && request.status.toLowerCase() === 'pending' &&
                        !notificationStorage.hasViewed('leaves', requestId)) {
                        newCount++;
                    }

                    // Count cancelled requests
                    if (request.status && request.status.toLowerCase() === 'cancelled' &&
                        !notificationStorage.hasViewed('leaves', `${requestId}-cancelled`)) {
                        newCount++;
                    }
                });

                if (newCount > 0) {
                    notificationStorage.updateCount('leaves', newCount);
                    updateBadge('leave', newCount);
                }
            })
            .catch(error => {
                debug(`Error checking leave requests: ${error.message}`);
                // Silently fail but don't increase the notification count
            });
    }
}

            // Handle leave action (approve/disapprove)
            function handleLeaveAction(e) {
    const button = e.target;
    const action = button.getAttribute('data-action');
    const leaveId = button.getAttribute('data-id');

    debug(`Leave action: ${action} for ID: ${leaveId}`);

    // Construct URL
    let url;
    if (action === 'approve') {
        url = `/warden/leave/approve/${leaveId}`;
    } else if (action === 'disapprove') {
        url = `/warden/leave/disapprove/${leaveId}`;
    } else {
        return;
    }

    // Disable the button while processing
    button.disabled = true;
    button.textContent = 'Processing...';

    // Create form data with CSRF token
    const formData = new FormData();
    formData.append('_token', csrfToken);

    fetch(url, {
        method: 'POST',
        headers: {
            'X-CSRF-TOKEN': csrfToken,
            'Accept': 'application/json'
        },
        body: formData
    })
    .then(response => {
        // First check the content type
        const contentType = response.headers.get('content-type');
        
        if (!response.ok) {
            console.error('Response status:', response.status);
            return response.text().then(text => {
                console.error('Error response body:', text);
                throw new Error(`Server returned ${response.status}: ${text || response.statusText}`);
            });
        }
        
        // Check if we have JSON content
        if (contentType && contentType.includes('application/json')) {
            return response.json().catch(err => {
                console.error('JSON parse error:', err);
                return { message: 'Server returned invalid JSON response' };
            });
        } else {
            // If not JSON, just get the text
            return response.text().then(text => {
                try {
                    // Try to parse it anyway
                    return JSON.parse(text);
                } catch (e) {
                    // Return something usable
                    return { message: text || 'Action completed (no details available)' };
                }
            });
        }
    })
    .then(data => {
        console.log('Success response:', data);
        alert(data.message || 'Action processed successfully');
        fetchLeaveRequests(); // Refresh the list
    })
    .catch(error => {
        debug(`Error processing leave ${action}: ${error.message}`);
        console.error('Full error:', error);
        alert(`Error: ${error.message}`);
        
        // Re-enable button and reset text
        button.disabled = false;
        button.textContent = action.charAt(0).toUpperCase() + action.slice(1);
    });
    
}      function handleFeedbackAction(e) {
                const button = e.target;
                const action = button.getAttribute('data-action');
                const feedbackId = button.getAttribute('data-id');

                debug(`Feedback action: ${action} for ID: ${feedbackId}`);

                if (action !== 'resolve') return;

                // Fix: Use a properly formatted URL
                const url = `/warden/feedback/resolve/${feedbackId}`;
                // OR, alternatively, if your route accepts the ID directly:
                // const url = `/warden/feedback/${feedbackId}/resolve`;

                // Disable the button while processing
                button.disabled = true;
                button.textContent = 'Processing...';

                fetch(url, {
                        method: 'POST',
                        headers: {
                            'Content-Type': 'application/json',
                            'X-CSRF-TOKEN': csrfToken
                        }
                    })
                    .then(response => {
                        if (!response.ok) {
                            throw new Error(`Server responded with status: ${response.status}`);
                        }
                        return response.json();
                    })
                    .then(data => {
                        alert(data.message || 'Feedback marked as resolved');
                        fetchFeedbacks(); // Refresh the list
                    })
                    .catch(error => {
                        debug(`Error processing feedback ${action}: ${error.message}`);
                        alert(`Error: ${error.message}`);
                        button.disabled = false;
                        button.textContent = 'Mark as Resolved';
                    });
            }

            // Test functions for simulating new notifications
            function simulateNewStudentRegistration() {
                const currentCount = notificationStorage.getCount('students');
                notificationStorage.updateCount('students', currentCount + 1);
                updateBadge('student', currentCount + 1);
            }

            function simulateNewLeaveRequest() {
                const currentCount = notificationStorage.getCount('leaves');
                notificationStorage.updateCount('leaves', currentCount + 1);
                updateBadge('leave', currentCount + 1);
            }

            function simulateNewFeedback() {
                const currentCount = notificationStorage.getCount('feedbacks');
                notificationStorage.updateCount('feedbacks', currentCount + 1);
                updateBadge('feedback', currentCount + 1);
            }

            function simulateNewReport() {
                const currentCount = notificationStorage.getCount('reports');
                notificationStorage.updateCount('reports', currentCount + 1);
                updateBadge('report', currentCount + 1);
            }

            function simulateNewRoomAllocation() {
                const currentCount = notificationStorage.getCount('rooms');
                notificationStorage.updateCount('rooms', currentCount + 1);
                updateBadge('room', currentCount + 1);
            }

            // Show student registrations by default
            // showSection('viewStudentRegistration');

            // Start checking for notifications
            startNotificationCheck();

            // Initialize badge display on page load
            updateBadges();

            // Expose simulation functions globally for testing
            window.wardenNotifications = {
                simulateNewStudentRegistration,
                simulateNewLeaveRequest,
                simulateNewFeedback,
                simulateNewReport,
                simulateNewRoomAllocation,
                // Helper to clear all notifications for testing
                clearAll() {
                    ['students', 'leaves', 'rooms', 'feedbacks', 'reports'].forEach(type => {
                        notificationStorage.clearSection(type);
                    });
                    updateBadges();
                },
                // Helper to reset notification storage completely
                reset() {
                    localStorage.removeItem('wardenNotifications');
                    notificationStorage.initialize();
                    updateBadges();
                    location.reload();
                }
            }

            function fetchRoomAllocations() {
                debug('Fetching room allocations...');

                fetch("{{ route('warden.roomAllocations') }}")
                    .then(response => {
                        if (!response.ok) {
                            throw new Error('Network response was not ok');
                        }
                        return response.json();
                    })
                    .then(data => {
                        debug(`Received ${data.length} room allocations`);
                        // Mark all room allocations as viewed
                        data.forEach(allocation => {
                            notificationStorage.markAsViewed('rooms', allocation.id.toString());
                        });

                        // Implement room allocation display logic here
                        // ...

                        // Hide the notification alert for this section
                        document.getElementById('newRoomAllocationAlert').style.display = 'none';
                    })
                    .catch(error => {
                        debug(`Error fetching room allocations: ${error.message}`);
                    });

            }

            function fetchFeedbacks() {
                debug('Fetching feedbacks...');

                fetch("{{ route('warden.feedbacks') }}")
                    .then(response => {
                        if (!response.ok) {
                            throw new Error('Network response was not ok');
                        }
                        return response.json();
                    })
                    .then(data => {
                        debug(`Received ${data.length} feedbacks`);
                        const tbody = document.querySelector('#feedbacksTable tbody');
                        tbody.innerHTML = '';

                        let hasNewFeedbacks = false;

                        if (data.length > 0) {
                            data.forEach(feedback => {
                                const feedbackId = feedback.id.toString();
                                const isResolved = feedback.is_resolved == 1;

                                // Mark as viewed
                                if (!notificationStorage.hasViewed('feedbacks', feedbackId)) {
                                    notificationStorage.markAsViewed('feedbacks', feedbackId);
                                    if (!isResolved) {
                                        hasNewFeedbacks = true;
                                    }
                                }

                                let statusBadge;
                                let rowClass = '';

                                if (isResolved) {
                                    statusBadge = '<span class="badge bg-success">Resolved</span>';
                                } else {
                                    statusBadge = '<span class="badge bg-warning">Pending</span>';
                                    rowClass = 'table-warning';
                                }

                                // Truncate message if it's too long
                                const truncatedMessage = feedback.message.length > 50 ?
                                    `${feedback.message.substring(0, 50)}...` : feedback.message;

                                const row = document.createElement('tr');
                                if (rowClass) row.className = rowClass;

                                row.innerHTML = `
                        <td>${feedback.id}</td>
                        <td>${feedback.name || ''}</td>
                        <td>${feedback.email || ''}</td>
                        <td>${feedback.subject || ''}</td>
                        <td>${feedback.category || ''}</td>
                        <td>
                            <span class="d-inline-block text-truncate" style="max-width: 150px;">
                                ${truncatedMessage}
                            </span>
                            <button type="button" class="btn btn-sm btn-link view-message" 
                                data-bs-toggle="modal" data-bs-target="#viewMessageModal" 
                                data-message="${feedback.message.replace(/"/g, '&quot;')}">
                                View
                            </button>
                        </td>
                        <td>
                            ${feedback.rating ? '⭐'.repeat(feedback.rating) : 'N/A'}
                            <span class="ms-1">(${feedback.rating || 0}/5)</span>
                        </td>
                        <td>${new Date(feedback.created_at).toLocaleDateString()}</td>
                        <td>${statusBadge}</td>
                        <td>
                            <button type="button" class="btn btn-primary btn-sm feedback-action" 
                                data-action="resolve" data-id="${feedback.id}" 
                                ${isResolved ? 'disabled' : ''}>
                                Mark as Resolved
                            </button>
                        </td>
                    `;
                                tbody.appendChild(row);
                            });

                            // Show alert if there are new feedbacks
                            if (hasNewFeedbacks) {
                                document.getElementById('newFeedbacksAlert').style.display = 'block';
                            }

                            // Add event listeners to feedback action buttons
                            document.querySelectorAll('#feedbacksTable .feedback-action').forEach(button => {
                                button.addEventListener('click', handleFeedbackAction);
                            });

                            // Add event listeners to view message buttons
                            document.querySelectorAll('#feedbacksTable .view-message').forEach(button => {
                                button.addEventListener('click', function() {
                                    const message = this.getAttribute('data-message');
                                    document.getElementById('fullMessageText').textContent =
                                        message;
                                });
                            });
                        } else {
                            tbody.innerHTML =
                                '<tr><td colspan="10" class="text-center">No feedbacks found</td></tr>';
                        }
                    })
                    .catch(error => {
                        debug(`Error fetching feedbacks: ${error.message}`);
                    });
            }
            function fetchReports() {
    console.log('Fetching reports...');
    
    fetch("{{ route('warden.reports') }}")
        .then(response => {
            if (!response.ok) {
                console.error('Response not ok:', response);  // Log the response for debugging
                throw new Error('Network response was not ok');
            }
            return response.json();
        })
        .then(data => {
            console.log(`Received ${data.length} reports`);

            // Mark all reports as viewed
            data.forEach(report => {
                notificationStorage.markAsViewed('reports', report.id.toString());
            });

            // Hide the notification alert
            document.getElementById('newReportsAlert').style.display = 'none';
        })
        .catch(error => {
            console.error('Error fetching reports:', error);
        });
}


            // Make sure these check functions are properly implemented
            function checkForNewRoomAllocations() {
                // Only check if not currently viewing that section
                if (document.getElementById('roomAllocation').classList.contains('d-none')) {
                    fetch("{{ route('warden.roomAllocations') }}")
                        .then(response => response.json())
                        .then(data => {
                            let newCount = 0;

                            data.forEach(allocation => {
                                if (allocation.status && allocation.status.toLowerCase() ===
                                    'pending' &&
                                    !notificationStorage.hasViewed('rooms', allocation.id.toString())) {
                                    newCount++;
                                }
                            });

                            if (newCount > 0) {
                                notificationStorage.updateCount('rooms', newCount);
                                updateBadge('room', newCount);
                            }
                        })
                        .catch(error => {
                            debug(`Error checking room allocations: ${error.message}`);
                        });
                }
            }

            // Check for new feedbacks
            function checkForNewFeedbacks() {
                // Only check if not currently viewing that section
                if (document.getElementById('feedbacks').classList.contains('d-none')) {
                    fetch("{{ route('warden.feedbacks') }}")
                        .then(response => response.json())
                        .then(data => {
                            let newCount = 0;

                            data.forEach(feedback => {
                                if (!feedback.is_resolved &&
                                    !notificationStorage.hasViewed('feedbacks', feedback.id.toString())
                                    ) {
                                    newCount++;
                                }
                            });

                            if (newCount > 0) {
                                notificationStorage.updateCount('feedbacks', newCount);
                                updateBadge('feedback', newCount);
                            }
                        })
                        .catch(error => {
                            debug(`Error checking feedbacks: ${error.message}`);
                        });
                }
            }

            function checkForNewReports() {
                // Only check if not currently viewing that section
                if (document.getElementById('reports').classList.contains('d-none')) {
                    fetch("{{ route('warden.reports') }}")
                        .then(response => response.json())
                        .then(data => {
                            let newCount = 0;

                            data.forEach(report => {
                                if (report.status && report.status.toLowerCase() === 'unread' &&
                                    !notificationStorage.hasViewed('reports', report.id.toString())) {
                                    newCount++;
                                }
                            });

                            if (newCount > 0) {
                                notificationStorage.updateCount('reports', newCount);
                                updateBadge('report', newCount);
                            }
                        })
                        .catch(error => {
                            debug(`Error checking reports: ${error.message}`);
                        });
                }
                //     function fetchFeedbacks() {
                //     // Other code...

                //     // Instead of using a named function for the event listener,
                //     // use an anonymous function directly that handles the action:
                //     document.querySelectorAll('#feedbacksTable .feedback-action').forEach(button => {
                //         button.addEventListener('click', function(e) {
                //             const button = e.target;
                //             const action = button.getAttribute('data-action');
                //             const feedbackId = button.getAttribute('data-id');

                //             debug(`Feedback action: ${action} for ID: ${feedbackId}`);

                //             if (action !== 'resolve') return;

                //             const url = `{{ route('warden.feedback.resolve', '') }}/${feedbackId}`;

                //             // Same implementation as in handleFeedbackAction
                //             // ...
                //         });
                //     });
                // }

                // function handleFeedbackAction(e) {
                //     const button = e.target;
                //     const action = button.getAttribute('data-action');
                //     const feedbackId = button.getAttribute('data-id');

                //     debug(`Feedback action: ${action} for ID: ${feedbackId}`);

                //     if (action !== 'resolve') return;

                //     const url = `{{ route('warden.feedback.resolve', '') }}/${feedbackId}`;

                //     // Disable the button while processing
                //     button.disabled = true;
                //     button.textContent = 'Processing...';

                //     fetch(url, {
                //         method: 'POST',
                //         headers: {
                //             'Content-Type': 'application/json',
                //             'X-CSRF-TOKEN': csrfToken
                //         }
                //     })
                //     .then(response => {
                //         if (!response.ok) {
                //             throw new Error('Network response was not ok');
                //         }
                //         return response.json();
                //     })
                //     .then(data => {
                //         alert(data.message || 'Feedback marked as resolved');
                //         fetchFeedbacks(); // Refresh the list
                //     })
                //     .catch(error => {
                //         debug(`Error processing feedback ${action}: ${error.message}`);
                //         alert(`Error: ${error.message}`);
                //         button.disabled = false;
                //         button.textContent = 'Mark as Resolved';
                //     });
                // }
                // Check for new feedbacks
                // function checkForNewFeedbacks() {
                //     // Only check if not currently viewing that section
                //     if (document.getElementById('feedbacks').classList.contains('d-none')) {
                //         fetch("{{ route('warden.feedbacks') }}")
                //             .then(response => response.json())
                //             .then(data => {
                //                 let newCount = 0;

                //                 data.forEach(feedback => {
                //                     if (!feedback.is_resolved && 
                //                         !notificationStorage.hasViewed('feedbacks', feedback.id.toString())) {
                //                         newCount++;
                //                     }
                //                 });

                //                 if (newCount > 0) {
                //                     notificationStorage.updateCount('feedbacks', newCount);
                //                     updateBadge('feedback', newCount);
                //                 }
                //             })
                //             .catch(error => {
                //                 debug(`Error checking feedbacks: ${error.message}`);
                //             });
                //     }
                // }

                // Add this to the checkForNewNotifications function
                function checkForNewNotifications() {
                    checkForNewStudentRegistrations();
                    checkForNewLeaveRequests();
                    checkForNewFeedbacks(); // Make sure this is included
                    checkForNewRoomAllocations();
                    checkForNewReports();
                }
            }
        });
    </script>
    <div class="modal fade" id="viewMessageModal" tabindex="-1" aria-labelledby="viewMessageModalLabel"
        aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="viewMessageModalLabel">Feedback Message</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <p id="fullMessageText"></p>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                </div>
            </div>
        </div>
    </div>
@endsection
