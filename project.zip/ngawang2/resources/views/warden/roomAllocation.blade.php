@extends('components.layout')

@section('title')
    Room Allocation
@endsection

@section('span')
    You are logged in as Warden
@endsection

@section('log')
    <a href="#" data-bs-toggle="modal" data-bs-target="#loginModal" class="text-white">(Logout)</a>
@endsection

@section('content')
    <header class="navbar navbar-expand-lg">
        <div class="container-fluid d-flex justify-content-between align-items-center position-relative">
            <a class="navbar-brand" href="#">
                <img src="{{ asset('images/logo.png') }}" alt="Hostel Management Logo" class="logo">
            </a>
            <div class="text-white">
                <span>You are logged in as Warden</span>
            </div>
        </div>
    </header>

    <link rel="stylesheet" href="{{ asset('css/warden_style.css') }}">
    <div class="container mt-5">
        <div class="d-flex justify-content-between align-items-center mb-4">
            <h3 class="text-primary mb-0">Room Allocation</h3>
            <button id="resetAllocationsBtn" class="btn btn-outline-secondary">
                <i class="fas fa-sync-alt me-2"></i>Reset Room Status
            </button>
        </div>
        
        <!-- Rest of your code -->
        @if($students->isNotEmpty())
    <div class="alert alert-success mb-4">
        <i class="fas fa-check-circle me-2"></i>Showing {{ $students->count() }} students ready for room allocation.
    </div>

    <table class="table table-bordered table-responsive">
        <thead>
            <tr>
                <th>Student ID</th>
                <th>Name</th>
                <th>Gender</th>
                <th>Course</th>
                <th>Block</th>
                <th>Room Number</th>
                <th>Room Occupants</th>
                <th>Action</th>
            </tr>
        </thead>
        <tbody>
            @foreach($students as $student)
                <tr>
                    <td>{{ $student->cid }}</td>
                    <td>{{ $student->first_name }} {{ $student->last_name }}</td>
                    <td>{{ $student->gender }}</td>
                    <td>{{ $student->course }}</td>
                    <td>
                        <select name="block[{{ $student->cid }}]" class="form-control block-dropdown" data-student-id="{{ $student->cid }}">
                            <option value="" disabled selected>Select Block</option>
                            <option value="Block A" {{ $student->block_no == 'Block A' ? 'selected' : '' }}>Block A</option>
                            <option value="Block B" {{ $student->block_no == 'Block B' ? 'selected' : '' }}>Block B</option>
                            <option value="Block C" {{ $student->block_no == 'Block C' ? 'selected' : '' }}>Block C</option>
                            <option value="Block D" {{ $student->block_no == 'Block D' ? 'selected' : '' }}>Block D</option>
                        </select>
                    </td>
                    <td>
                        <select name="room[{{ $student->cid }}]" class="form-control room-dropdown" data-student-id="{{ $student->cid }}">
                            <option value="" disabled selected>Select Room</option>
                        </select>
                        <div class="available-rooms-container mt-2" style="max-height: 200px; overflow-y: auto; display: none;">
                            <h6>Available Rooms</h6>
                            <ul class="list-group available-rooms-list"></ul>
                        </div>
                    </td>
                    <td>
                        <div class="room-occupants-container" data-student-id="{{ $student->cid }}">
                            <!-- Dynamically populated room occupants will be shown here -->
                        </div>
                    </td>
                    <td>
                        <button type="button" class="btn btn-primary individual-submit-btn" 
                                data-student-id="{{ $student->cid }}">
                            <i class="fas fa-save me-2"></i>Allocate
                        </button>
                    </td>
                </tr>
            @endforeach
        </tbody>
    </table>
@else
    <div class="alert alert-info mt-4">
        <i class="fas fa-info-circle me-2"></i>No approved students found for room allocation.
    </div>
@endif
    </div>

    <!-- Rest of your JavaScript code remains unchanged -->
    <script>
    document.addEventListener('DOMContentLoaded', function() {
    // Existing code with room occupancy tracking
    const roomOccupancy = {}; // Holds room occupancy status
    const studentAllocations = {}; // Tracks student room allocations
    let isProcessing = false;

    // Load saved allocations from localStorage and recalculate room occupancy
    function loadSavedAllocations() {
        const savedAllocations = localStorage.getItem('studentRoomAllocations');
        if (savedAllocations) {
            const parsedAllocations = JSON.parse(savedAllocations);
            
            // First, reset all occupancy counts that will be recalculated
            Object.keys(parsedAllocations).forEach(studentId => {
                const allocation = parsedAllocations[studentId];
                const blockRoomKey = `${allocation.block}-${allocation.room}`;
                if (!roomOccupancy[blockRoomKey]) {
                    roomOccupancy[blockRoomKey] = 0;
                }
            });
            
            // Then, populate studentAllocations and count occupancy
            Object.keys(parsedAllocations).forEach(studentId => {
                studentAllocations[studentId] = parsedAllocations[studentId];
                
                // Increment the occupancy count for each allocated room
                const allocation = studentAllocations[studentId];
                const blockRoomKey = `${allocation.block}-${allocation.room}`;
                roomOccupancy[blockRoomKey] = (roomOccupancy[blockRoomKey] || 0) + 1;
            });
            
            // Apply the saved allocations to the UI
            applyAllocationsToUI();
        }
    }

    // Apply saved allocations to the UI
    function applyAllocationsToUI() {
        Object.keys(studentAllocations).forEach(studentId => {
            const allocation = studentAllocations[studentId];
            const blockDropdown = document.querySelector(`.block-dropdown[data-student-id="${studentId}"]`);
            
            if (blockDropdown) {
                const row = blockDropdown.closest('tr');
                const roomDropdown = row.querySelector('.room-dropdown');
                
                // Set block selection
                blockDropdown.value = allocation.block;
                
                // Trigger block change to populate room dropdown
                blockDropdown.dispatchEvent(new Event('change'));
                
                // Wait for room dropdown to be populated
                setTimeout(() => {
                    // Set room selection
                    roomDropdown.value = allocation.room;
                    
                    // Update room occupants display
                    roomDropdown.dispatchEvent(new Event('change'));
                }, 100);
            }
        });
    }

    // Save allocations to localStorage
    function saveAllocations() {
        localStorage.setItem('studentRoomAllocations', JSON.stringify(studentAllocations));
    }

    // Function to fetch and load the current room occupancy
    function fetchRoomOccupancy() {
        fetch('/warden/get-all-room-occupancy')
            .then(response => response.json())
            .then(data => {
                // Clear existing occupancy data before populating with server data
                roomOccupancy = {};
                initializeEmptyOccupancyData();
                
                if (data.occupancy) {
                    Object.keys(data.occupancy).forEach(blockRoom => {
                        roomOccupancy[blockRoom] = data.occupancy[blockRoom];
                    });
                }
                
                // Load saved allocations after getting occupancy data
                loadSavedAllocations();
                // Update all room displays based on the combined occupancy data
                updateAllRoomDisplays();
            })
            .catch(error => {
                console.error('Error fetching room occupancy:', error);
                initializeEmptyOccupancyData();
                loadSavedAllocations();
                updateAllRoomDisplays();
            });
    }
    
    // Initialize occupancy data with empty values
    function initializeEmptyOccupancyData() {
        const blocks = ['Block A', 'Block B', 'Block C', 'Block D'];
        const roomNumbers = [101, 102, 103, 104, 105];
        
        blocks.forEach(block => {
            roomNumbers.forEach(roomNo => {
                roomOccupancy[`${block}-${roomNo}`] = 0; // Set initial occupancy to 0
            });
        });
    }

    // ENHANCED FUNCTION: Check for deleted students and remove them from UI
    function validateLocalAllocations() {
        const studentIds = Object.keys(studentAllocations);
        
        if (studentIds.length === 0) return; // No allocations to validate
        
        // Create an array of all student IDs currently in the table
        const tableStudentIds = Array.from(document.querySelectorAll('.individual-submit-btn'))
            .map(btn => btn.getAttribute('data-student-id'));
        
        // Check which students exist in localStorage but not in current table
        const missingFromTable = studentIds.filter(id => !tableStudentIds.includes(id));
        
        // Remove those students from localStorage
        missingFromTable.forEach(id => {
            delete studentAllocations[id];
        });
        
        // If any were removed, save the updated allocations
        if (missingFromTable.length > 0) {
            saveAllocations();
        }
        
        // Now validate against the server database
        fetch('/warden/validate-allocations', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]').content
            },
            body: JSON.stringify({
                studentIds: studentIds,
                tableStudentIds: tableStudentIds // Send all IDs for complete validation
            })
        })
        .then(response => response.json())
        .then(data => {
            let hasRemovedRecords = false;
            
            // Process deleted students - remove from localStorage and table
            if (data.invalidAllocations && data.invalidAllocations.length > 0) {
                data.invalidAllocations.forEach(studentId => {
                    // Remove from localStorage
                    if (studentAllocations[studentId]) {
                        delete studentAllocations[studentId];
                        hasRemovedRecords = true;
                    }
                    
                    // Remove from table if exists
                    const row = document.querySelector(`tr[data-student-id="${studentId}"]`);
                    if (row) {
                        row.remove();
                        hasRemovedRecords = true;
                    }
                });
                
                // Save updated allocations
                if (hasRemovedRecords) {
                    saveAllocations();
                    updateAllRoomDisplays();
                    showNotification('Some records were removed because they no longer exist in the database.');
                }
            }
            
            // Check database for new students - if found, refresh the page
            if (data.newStudents && data.newStudents.length > 0) {
                showNotification('New students available for allocation. Refreshing page...');
                setTimeout(() => {
                    location.reload();
                }, 2000);
                return;
            }
            
            // Check for students removed from database but still in table
            if (data.deletedFromDatabase && data.deletedFromDatabase.length > 0) {
                let removedCount = 0;
                
                data.deletedFromDatabase.forEach(studentId => {
                    const row = document.querySelector(`tr[data-student-id="${studentId}"]`);
                    if (row) {
                        row.remove();
                        removedCount++;
                    }
                    
                    // Also remove from localStorage if present
                    if (studentAllocations[studentId]) {
                        delete studentAllocations[studentId];
                    }
                });
                
                if (removedCount > 0) {
                    saveAllocations();
                    updateAllRoomDisplays();
                    showNotification(`${removedCount} student(s) were removed as they no longer exist in the database.`);
                }
            }
        })
        .catch(error => console.error('Error validating allocations:', error));
    }

    // Create a notification function
    function showNotification(message) {
        // Create notification element if it doesn't exist
        let notification = document.getElementById('sync-notification');
        if (!notification) {
            notification = document.createElement('div');
            notification.id = 'sync-notification';
            notification.className = 'alert alert-warning alert-dismissible fade show fixed-top mx-auto mt-3';
            notification.style.width = '80%';
            notification.style.maxWidth = '500px';
            notification.style.zIndex = '9999';
            
            // Add close button
            notification.innerHTML = `
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                <div class="notification-message"></div>
            `;
            
            document.body.appendChild(notification);
        }
        
        // Update message and show
        notification.querySelector('.notification-message').textContent = message;
        
        // Auto-hide after 5 seconds
        setTimeout(() => {
            notification.classList.remove('show');
        }, 5000);
    }

    // Reset allocations function
    function resetLocalStorageData() {
        localStorage.removeItem('studentRoomAllocations');
        Object.keys(roomOccupancy).forEach(key => {
            roomOccupancy[key] = 0;
        });
        initializeEmptyOccupancyData(); // Re-initialize with empty data
        updateAllRoomDisplays(); // Update all dropdowns
    }

    // Add reset button event listener
    document.getElementById('resetAllocationsBtn')?.addEventListener('click', function() {
        if (confirm('Are you sure you want to reset all room allocations? This will clear all local data.')) {
            resetLocalStorageData();
            location.reload(); // Reload the page to fetch fresh data
        }
    });

    // Update all room displays
    function updateAllRoomDisplays() {
        document.querySelectorAll('.block-dropdown').forEach(function(blockDropdown) {
            if (blockDropdown.value) {
                const block = blockDropdown.value;
                const roomDropdown = blockDropdown.closest('tr').querySelector('.room-dropdown');
                
                Array.from(roomDropdown.options).forEach(option => {
                    if (option.value) {
                        const room = option.value;
                        const blockRoomKey = `${block}-${room}`;
                        const occupancy = roomOccupancy[blockRoomKey] || 0;
                        
                        // Update option text with correct occupancy
                        option.textContent = `Room ${room} (${occupancy}/2)`;
                        
                        // Update disabled state based on occupancy
                        if (occupancy >= 2) {
                            option.disabled = true;
                            option.style.color = '#999';
                            option.textContent += ' - FULL';
                        } else {
                            option.disabled = false;
                            option.style.color = '';
                        }
                    }
                });
            }
        });
    }

    // Handle block change (dropdown change)
    document.querySelectorAll('.block-dropdown').forEach(function(blockSelect) {
        blockSelect.addEventListener('change', function() {
            let block = this.value;
            let studentId = this.getAttribute('data-student-id');
            let currentRow = this.closest('tr');
            let roomDropdown = currentRow.querySelector('.room-dropdown');
            let roomOccupantsContainer = currentRow.querySelector('.room-occupants-container');
            
            // Add data-student-id attribute to the row for easy access
            if (studentId && currentRow) {
                currentRow.setAttribute('data-student-id', studentId);
            }
            
            roomDropdown.innerHTML = '<option value="" disabled selected>Select Room</option>';
            roomOccupantsContainer.innerHTML = '<p class="text-muted">Select a room to see occupants</p>';
            
            if (block) {
                const roomNumbers = [101, 102, 103, 104, 105];
                let availableRoomsCount = 0;

                roomNumbers.forEach(roomNo => {
                    const blockRoomKey = `${block}-${roomNo}`;
                    const currentOccupancy = roomOccupancy[blockRoomKey] || 0;

                    let option = document.createElement('option');
                    option.value = roomNo.toString();
                    option.textContent = `Room ${roomNo} (${currentOccupancy}/2)`; // Max occupancy is 2

                    // Check if this student is already allocated to this room
                    const isAllocatedToThisRoom = studentAllocations[studentId] && 
                                              studentAllocations[studentId].block === block && 
                                              studentAllocations[studentId].room === roomNo.toString();
                    
                    // Room is full if occupancy >= 2, unless this student is already allocated to this room
                    if (currentOccupancy >= 2 && !isAllocatedToThisRoom) {
                        option.disabled = true;
                        option.style.color = '#999';
                        option.textContent += ' - FULL';
                    } else {
                        availableRoomsCount++;
                    }

                    roomDropdown.appendChild(option);
                });

                if (availableRoomsCount === 0) {
                    roomOccupantsContainer.innerHTML = '<div class="alert alert-warning"><i class="fas fa-exclamation-triangle"></i> No available rooms in this block. All rooms are at maximum capacity.</div>';
                    currentRow.querySelector('.individual-submit-btn').disabled = true;
                } else {
                    currentRow.querySelector('.individual-submit-btn').disabled = false;
                }
                
                // If this student had a saved room in this block, select it
                if (studentAllocations[studentId] && studentAllocations[studentId].block === block) {
                    const savedRoom = studentAllocations[studentId].room;
                    const roomOptions = roomDropdown.options;
                    
                    for (let i = 0; i < roomOptions.length; i++) {
                        if (roomOptions[i].value === savedRoom) {
                            roomDropdown.selectedIndex = i;
                            break;
                        }
                    }
                }
            }
        });
    });

    // Handle room change (dropdown change)
    document.querySelectorAll('.room-dropdown').forEach(function(roomSelect) {
        roomSelect.addEventListener('change', function() {
            let roomNo = this.value;
            let studentId = this.getAttribute('data-student-id');
            let block = this.closest('tr').querySelector('.block-dropdown').value;
            let roomOccupantsContainer = this.closest('tr').querySelector('.room-occupants-container');
            
            if (block && roomNo) {
                const blockRoomKey = `${block}-${roomNo}`;
                roomOccupantsContainer.innerHTML = '<p class="text-muted">Loading occupants...</p>';

                // Get locally allocated students for this room
                const localAllocatedStudents = getLocallyAllocatedStudents(block, roomNo);
                
                fetch(`/warden/get-room-occupants?block=${encodeURIComponent(block)}&room=${encodeURIComponent(roomNo)}`)
                    .then(response => response.json())
                    .then(data => {
                        // Merge server occupancy data with our local knowledge
                        const serverOccupants = data.occupants || [];
                        const localOccupancy = calculateLocalRoomOccupancy(block, roomNo, studentId);
                        
                        // Use the greater of server or local calculation to be safe
                        const currentOccupancy = Math.max(serverOccupants.length, localOccupancy);
                        roomOccupancy[blockRoomKey] = currentOccupancy; // Update room occupancy data
                        
                        // Display room occupants, merging server data with local allocations
                        displayRoomOccupants(roomOccupantsContainer, serverOccupants, currentOccupancy, localAllocatedStudents);
                    })
                    .catch(error => {
                        console.error('Error fetching room occupants:', error);
                        // Use local occupancy data if fetch fails
                        const localOccupancy = calculateLocalRoomOccupancy(block, roomNo, studentId);
                        roomOccupancy[blockRoomKey] = localOccupancy;
                        
                        // Display room occupants using only local data
                        displayRoomOccupants(roomOccupantsContainer, [], localOccupancy, localAllocatedStudents);
                    });
            }
        });
    });

    // Get locally allocated students for a room
    function getLocallyAllocatedStudents(block, roomNo) {
        const students = [];
        Object.keys(studentAllocations).forEach(studentId => {
            const allocation = studentAllocations[studentId];
            if (allocation.block === block && allocation.room === roomNo) {
                students.push({
                    id: studentId,
                    name: `Student ${studentId}`,
                    gender: allocation.gender
                });
            }
        });
        return students;
    }

    // Calculate local room occupancy based on studentAllocations
    function calculateLocalRoomOccupancy(block, roomNo, currentStudentId) {
        let count = 0;
        Object.keys(studentAllocations).forEach(studentId => {
            const allocation = studentAllocations[studentId];
            if (allocation.block === block && allocation.room === roomNo) {
                // Don't count the current student if we're checking for a new allocation
                if (studentId !== currentStudentId || 
                    (studentAllocations[currentStudentId] && 
                     studentAllocations[currentStudentId].block === block && 
                     studentAllocations[currentStudentId].room === roomNo)) {
                    count++;
                }
            }
        });
        return count;
    }

    // Display occupants in the room
    function displayRoomOccupants(container, serverOccupants, currentOccupancy, localAllocatedStudents) {
        // Create status info div
        const statusHtml = `<div class="room-status-info mb-2">Current occupancy: ${currentOccupancy}/2</div>`;
        
        // Create a combined list of occupants
        let occupantsHtml = '';
        
        // If we have occupants from either source
        if (serverOccupants.length > 0 || localAllocatedStudents.length > 0) {
            // Start list
            occupantsHtml = '<ul class="list-group">';
            
            // Add server occupants
            serverOccupants.forEach(occupant => {
                occupantsHtml += `<li class="list-group-item">${occupant.name} - ${occupant.dob}</li>`;
            });
            
            // Add locally allocated students (that aren't already in server list)
            localAllocatedStudents.forEach(student => {
                // Only add if not already in server occupants
                const alreadyInList = serverOccupants.some(
                    occupant => occupant.name === student.name || occupant.name.includes(student.id)
                );
                
                if (!alreadyInList) {
                    occupantsHtml += `<li class="list-group-item">${student.name} - ${student.gender}</li>`;
                }
            });
            
            // End list
            occupantsHtml += '</ul>';
        }
        
        // If no occupants at all, don't show "No occupants yet in this room" message
        // Instead, show the status info with empty space for the list
        if (serverOccupants.length === 0 && localAllocatedStudents.length === 0) {
            container.innerHTML = statusHtml;
        } else {
            container.innerHTML = statusHtml + occupantsHtml;
        }
    }

    // When allocate button is clicked
    document.querySelectorAll('.individual-submit-btn').forEach(function(button) {
        button.addEventListener('click', function() {
            if (isProcessing) return; // Prevent concurrent processing
            isProcessing = true;
            
            let row = this.closest('tr');
            let studentId = this.getAttribute('data-student-id');
            
            // Ensure the row has the data-student-id attribute
            if (row && studentId) {
                row.setAttribute('data-student-id', studentId);
            }
            
            let gender = row.cells[2].textContent.trim(); // Get gender from the table cell
            let block = row.querySelector('.block-dropdown').value;
            let room = row.querySelector('.room-dropdown').value;
            
            // Form validation - make sure block and room are selected
            if (!block || !room) {
                alert('Please select both block and room before allocating.');
                isProcessing = false;
                return;
            }
            
            // Get the CSRF token from the meta tag
            const csrfToken = document.querySelector('meta[name="csrf-token"]').content;
            
            // Create form data
            const formData = new FormData();
            formData.append('studentId', studentId);
            formData.append('block', block);
            formData.append('room', room);
            formData.append('gender', gender);
            formData.append('allocation_date', new Date().toISOString().split('T')[0]); // Current date in YYYY-MM-DD format
            
            fetch("/warden/allocate-rooms", {
                method: 'POST',
                headers: {
                    'X-CSRF-TOKEN': csrfToken
                },
                body: formData
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    // Update local storage to reflect the allocation
                    studentAllocations[studentId] = {
                        block: block,
                        room: room,
                        gender: gender
                    };
                    saveAllocations();
                    
                    // Update room occupancy
                    const blockRoomKey = `${block}-${room}`;
                    roomOccupancy[blockRoomKey] = (roomOccupancy[blockRoomKey] || 0) + 1;
                    
                    // Update UI
                    updateRoomDisplays(block, room, roomOccupancy[blockRoomKey]);
                    
                    // Show success message
                    showSuccess(`Room ${room} in ${block} allocated successfully for Student ${studentId}!`);
                } else {
                    showError(`Error allocating room: ${data.message || 'Unknown error'}`);
                }
                isProcessing = false;
            })
            .catch(error => {
                console.error('Error submitting allocation:', error);
                showError('Error submitting allocation. Please try again.');
                isProcessing = false;
            });
        });
    });

    // Helper functions for showing errors and success messages
    function showError(message) {
        const errorElement = document.getElementById('errorMessage');
        if (errorElement) {
            errorElement.textContent = message;
            errorElement.style.display = 'block';
            // Hide after 5 seconds
            setTimeout(() => {
                errorElement.style.display = 'none';
            }, 5000);
        } else {
            alert(message); // Fallback to alert if element doesn't exist
        }
    }

    function showSuccess(message) {
        const successElement = document.getElementById('successMessage');
        if (successElement) {
            successElement.textContent = message;
            successElement.style.display = 'block';
            // Hide after 5 seconds
            setTimeout(() => {
                successElement.style.display = 'none';
            }, 5000);
        } else {
            alert(message); // Fallback to alert if element doesn't exist
        }
    }

    // Update the room display with the latest occupancy data
    function updateRoomDisplays(block, room, occupancy) {
        document.querySelectorAll('.block-dropdown').forEach(function(blockDropdown) {
            if (blockDropdown.value === block) {
                const roomDropdown = blockDropdown.closest('tr').querySelector('.room-dropdown');
                Array.from(roomDropdown.options).forEach(option => {
                    if (option.value === room) {
                        option.textContent = `Room ${room} (${occupancy}/2)`;
                        if (occupancy >= 2) {
                            option.disabled = true;
                            option.style.color = '#999';
                            option.textContent += ' - FULL';
                        } else {
                            option.disabled = false;
                            option.style.color = '';
                        }
                    }
                });
            }
        });
    }

    // Add data-student-id attributes to all rows when page loads
    function addStudentIdsToRows() {
        document.querySelectorAll('.individual-submit-btn').forEach(btn => {
            const studentId = btn.getAttribute('data-student-id');
            if (studentId) {
                const row = btn.closest('tr');
                row.setAttribute('data-student-id', studentId);
            }
        });
    }

    // Initialize the page
    fetchRoomOccupancy(); // Load the occupancy data initially
    addStudentIdsToRows(); // Add data-student-id attributes to rows
    
    // Set up validation checking intervals
    setTimeout(validateLocalAllocations, 2000); // Initial check after 2 seconds
    setInterval(validateLocalAllocations, 10000); // Check every 10 seconds
    
    // Also check when the page gets focus
    window.addEventListener('focus', validateLocalAllocations);
});
    </script>
@endsection