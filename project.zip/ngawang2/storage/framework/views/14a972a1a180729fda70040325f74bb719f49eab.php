<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <link href="https://cdn.jsdelivr.net/npm/flowbite@3.1.2/dist/flowbite.min.css" rel="stylesheet" />
    <title><?php echo $__env->yieldContent('title'); ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="css/studentreg_style.css" rel="stylesheet">
</head>
<body>

    <!-- Header Section with Green Background -->
    <header class="header bg-success text-white p-3">
        <div class="container-fluid d-flex justify-content-end align-items-center">
            <span class="me-2"><?php echo $__env->yieldContent('span'); ?></span>
            <?php echo $__env->yieldContent('log'); ?>
        </div>
    </header>
    <?php echo $__env->yieldContent('content'); ?>

   <!-- Footer with Border -->
   <footer class="footer text-center py-3 bg-light text-dark" style="border-top: 2px solid #ccc;">
        <p>&copy; 2025 Royal Institute of Management</p>
        <p>Phone: 975 351014</p>
        <p><a href="#" class="text-dark">E-mail: riminfo@rim.edu.bt</a></p>
    </footer>

<script src="https://cdn.jsdelivr.net/npm/flowbite@3.1.2/dist/flowbite.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
<?php /**PATH C:\ngawang2\resources\views/components/layout.blade.php ENDPATH**/ ?>