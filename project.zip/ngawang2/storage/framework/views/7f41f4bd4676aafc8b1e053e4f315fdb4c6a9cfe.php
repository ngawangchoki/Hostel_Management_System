

<?php $__env->startSection('title'); ?>
Feedback Management
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="container">
    <h2 class="mb-4">Student Feedbacks</h2>
    
    <!-- Filter form -->
    <div class="card mb-4">
        <div class="card-body">
            <form action="<?php echo e(route('feedbacks')); ?>" method="GET" class="row g-3">
                <div class="col-md-3">
                    <label for="student_id" class="form-label">Student ID</label>
                    <input type="text" class="form-control" id="student_id" name="student_id" value="<?php echo e(request('student_id')); ?>">
                </div>
                <div class="col-md-3">
                    <label for="category" class="form-label">Category</label>
                    <select class="form-select" id="category" name="category">
                        <option value="">All Categories</option>
                        <option value="facilities" <?php echo e(request('category') == 'facilities' ? 'selected' : ''); ?>>Facilities</option>
                        <option value="food" <?php echo e(request('category') == 'food' ? 'selected' : ''); ?>>Food</option>
                        <option value="cleanliness" <?php echo e(request('category') == 'cleanliness' ? 'selected' : ''); ?>>Cleanliness</option>
                        <option value="other" <?php echo e(request('category') == 'other' ? 'selected' : ''); ?>>Other</option>
                    </select>
                </div>
                <div class="col-md-3">
                    <label for="status" class="form-label">Status</label>
                    <select class="form-select" id="status" name="status">
                        <option value="">All Status</option>
                        <option value="pending" <?php echo e(request('status') == 'pending' ? 'selected' : ''); ?>>Pending</option>
                        <option value="resolved" <?php echo e(request('status') == 'resolved' ? 'selected' : ''); ?>>Resolved</option>
                    </select>
                </div>
                <div class="col-md-3 d-flex align-items-end">
                    <button type="submit" class="btn btn-primary me-2">Filter</button>
                    <a href="<?php echo e(route('feedbacks')); ?>" class="btn btn-secondary">Reset</a>
                </div>
            </form>
        </div>
    </div>
    
    <!-- Feedbacks table -->
    <div class="card">
        <div class="card-body">
            <?php if(isset($feedbacks) && count($feedbacks) > 0): ?>
            <div class="table-responsive">
                <table class="table table-bordered table-hover">
                    <thead class="bg-light">
                        <tr>
                            <th>ID</th>
                            <th>cid</th>
                            <th>Category</th>
                            <th>Subject</th>
                            <th>Date</th>
                            <th>Status</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $feedbacks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $feedback): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($feedback->id); ?></td>
                            <td><?php echo e($feedback->cid); ?></td>
                            <td><?php echo e(ucfirst($feedback->category)); ?></td>
                            <td><?php echo e($feedback->subject); ?></td>
                            <td><?php echo e($feedback->created_at->format('d M Y')); ?></td>
                            <td>
                                <span class="badge bg-<?php echo e($feedback->is_resolved ? 'success' : 'warning'); ?>">
                                    <?php echo e($feedback->is_resolved ? 'Resolved' : 'Pending'); ?>

                                </span>
                            </td>
                            <td>
                                <button type="button" class="btn btn-sm btn-info view-feedback" 
                                        data-bs-toggle="modal" data-bs-target="#viewFeedbackModal"
                                        data-id="<?php echo e($feedback->id); ?>"
                                        data-subject="<?php echo e($feedback->subject); ?>"
                                        data-message="<?php echo e($feedback->message); ?>"
                                        data-category="<?php echo e($feedback->category); ?>"
                                        data-status="<?php echo e($feedback->is_resolved); ?>">
                                    View
                                </button>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
            
            <div class="d-flex justify-content-center mt-4">
                <?php echo e($feedbacks->links()); ?>

            </div>
            <?php else: ?>
            <div class="alert alert-info">
                No feedbacks found.
            </div>
            <?php endif; ?>
        </div>
    </div>
</div>

<!-- View Feedback Modal -->
<div class="modal fade" id="viewFeedbackModal" tabindex="-1" aria-labelledby="viewFeedbackModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="viewFeedbackModalLabel">Feedback Details</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <div class="mb-3">
                    <h6>Category</h6>
                    <p id="modalCategory" class="mb-3"></p>
                    
                    <h6>Subject</h6>
                    <p id="modalSubject" class="mb-3"></p>
                    
                    <h6>Message</h6>
                    <p id="modalMessage"></p>
                </div>
                <form id="resolveForm" action="" method="POST">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('PUT'); ?>
                    <div class="form-check mb-3">
                        <input class="form-check-input" type="checkbox" id="resolvedCheckbox" name="is_resolved">
                        <label class="form-check-label" for="resolvedCheckbox">
                            Mark as Resolved
                        </label>
                    </div>
                    <div class="form-group">
                        <label for="responseText">Response (optional)</label>
                        <textarea class="form-control" id="responseText" name="response" rows="3"></textarea>
                    </div>
                </form>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                <button type="button" class="btn btn-primary" id="saveResponseBtn">Save Changes</button>
            </div>
        </div>
    </div>
</div>

<script>
document.addEventListener('DOMContentLoaded', function() {
    // Handle view feedback modal
    const viewFeedbackBtns = document.querySelectorAll('.view-feedback');
    viewFeedbackBtns.forEach(btn => {
        btn.addEventListener('click', function() {
            const id = this.getAttribute('data-id');
            const subject = this.getAttribute('data-subject');
            const message = this.getAttribute('data-message');
            const category = this.getAttribute('data-category');
            const isResolved = this.getAttribute('data-status') === '1';
            
            document.getElementById('modalCategory').textContent = category.charAt(0).toUpperCase() + category.slice(1);
            document.getElementById('modalSubject').textContent = subject;
            document.getElementById('modalMessage').textContent = message;
            document.getElementById('resolvedCheckbox').checked = isResolved;
            document.getElementById('resolveForm').action = `/feedbacks/${id}/resolve`;
            
            // Save response button handler
            document.getElementById('saveResponseBtn').onclick = function() {
                document.getElementById('resolveForm').submit();
            };
        });
    });
});
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('components.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\ngawang2\resources\views/HR/feedbacks.blade.php ENDPATH**/ ?>