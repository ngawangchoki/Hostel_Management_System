<?php

use App\Http\Controllers\HomeController;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\Auth\LoginController;
use App\Http\Controllers\HrController;
use App\Http\Controllers\WardenController;
use App\Http\Controllers\HostelController;
use App\Http\Controllers\FeedbackController;
use App\Http\Controllers\StudentController;
use App\Http\Controllers\LeaveController;
use App\Http\Controllers\LeaveRequestController;
use App\Models\Leave;
use App\Models\Student;
use App\Http\Controllers\WardenRoomAllocationController;
use App\Http\Controllers\RoomAllocationController;
use App\Http\Controllers\AttendanceController;
use App\Http\Controllers\HRAttendanceController;
use App\Http\Controllers\Feedback;
use App\Http\Controllers\ReportController;
use App\Http\Controllers\ExportController;
use App\Http\Controllers\HRReportController;
use App\Http\Controllers\StudentReportController;

use Illuminate\Http\Request;
use Termwind\Components\Hr;




Route::middleware(['auth', 'warden'])->group(function () {
    // Room allocation routes
    // Route::get('/warden/room-allocation', [WardenRoomAllocationController::class, 'index'])
        // ->name('warden.room-allocation');
    
    Route::get('/get-available-rooms', [WardenRoomAllocationController::class, 'getAvailableRooms'])
        ->name('get.available.rooms');
    
    Route::get('/get-room-occupants', [WardenRoomAllocationController::class, 'getRoomOccupants'])
        ->name('get.room.occupants');
    
    Route::post('/warden/allocate-rooms', [WardenRoomAllocationController::class, 'allocateRooms'])
        ->name('warden.allocate-rooms');
});
Route::middleware(['auth', 'warden'])->group(function () {
    Route::get('/room-allocation', [RoomAllocationController::class, 'index'])
        ->name('room.allocation');
    
    Route::get('/get-available-rooms', [RoomAllocationController::class, 'getAvailableRooms'])
        ->name('get.available.rooms');
    
    Route::get('/get-room-occupants', [RoomAllocationController::class, 'getRoomOccupants'])
        ->name('get.room.occupants');
    
    Route::post('/allocate-rooms', [RoomAllocationController::class, 'allocateRooms'])
        ->name('allocate.rooms');
});
Route::middleware(['auth', 'warden'])->group(function () {
    Route::get('/room-allocation', [RoomAllocationController::class, 'index'])
        ->name('room.allocation');
    
    Route::get('/get-available-rooms', [RoomAllocationController::class, 'getAvailableRooms'])
        ->name('get.available.rooms');
    
    Route::get('/get-room-occupants', [RoomAllocationController::class, 'getRoomOccupants'])
        ->name('get.room.occupants');
    
    Route::post('/allocate-rooms', [RoomAllocationController::class, 'allocateRooms'])
        ->name('allocate.rooms');
});
// Route::middleware(['auth', 'warden'])->group(function () {
//     Route::get('/warden/room-allocation', [RoomAllocationController::class, 'index'])
//         ->name('warden.room-allocation');
    
    Route::get('/get-available-rooms', [RoomAllocationController::class, 'getAvailableRooms'])
        ->name('get.available.rooms');
    
    Route::get('/get-room-occupants', [RoomAllocationController::class, 'getRoomOccupants'])
        ->name('get.room.occupants');
    
    Route::post('/warden/allocate-rooms', [RoomAllocationController::class, 'allocateRooms'])
        ->name('warden.allocate-rooms');




// Routes for leave status and leave requests
Route::get('/student/leave-status', [StudentController::class, 'leaveStatus'])->name('student.leave_status');
Route::get('/student/leave-status/{student_id}', [StudentController::class, 'getLeaveStatus'])->name('student.leave.status');
Route::get('/leave-form-status', [LeaveController::class, 'showLeaveFormStatus'])->name('leave.form.status');
Route::post('/leave/{id}/update-status', [LeaveRequestController::class, 'updateStatus'])->name('leave.updateStatus');

///trying 
Route::get('/leave-form-status', [LeaveController::class, 'fetchLeaveRequests'])->name('fetch.leave.status');
// showLeaveStatus

// Routes for leave requests and submissions
Route::post('/leave/store', [LeaveRequestController::class, 'store'])->name('leave.store');
Route::post('/submit-leave', [LeaveController::class, 'submitLeave'])->name('leave.submit');
Route::post('/leave-request', [LeaveController::class, 'store'])->name('leave_requests');
Route::post('/leave-apply', [LeaveController::class, 'apply'])->name('leave.apply');

// Routes for validating CID
Route::post('/validate-cid', [StudentController::class, 'validateCID'])->name('cid.validate');
Route::post('/cid/validate', [StudentController::class, 'validateCID'])->name('cid.validate');

// Routes for feedback submission
Route::post('/feedback', [FeedbackController::class, 'submit'])->name('feedback.submit');

// Routes for authentication and login/logout
Route::get('/login', [LoginController::class, 'showLoginForm'])->name('login');
Route::post('/login', [LoginController::class, 'login']);
Route::post('/logout', [LoginController::class, 'logout'])->name('logout');

// Routes for Student registration
Route::get('register', [StudentController::class, 'registerForm'])->name('student.registerForm');
Route::post('register', [StudentController::class, 'register'])->name('student.register');

// Routes for student dashboard
Route::middleware(['auth'])->group(function () {
    Route::get('/student/dashboard', [StudentController::class, 'dashboard'])->name('student.dashboard');
    Route::get('/student/leave', [StudentController::class, 'showLeaveForm'])->name('student.leave');
    Route::get('/student/{student_id}/leave-status', [StudentController::class, 'getLeaveStatus'])->name('student.leave.status');
});

// Warden routes
Route::middleware(['auth', 'role:warden'])->group(function () {
    Route::get('/warden/dashboard', [WardenController::class, 'dashboard'])->name('warden.dashboard');
    Route::get('/warden/leave-details', [WardenController::class, 'showLeaveDetails'])->name('warden.leaveDetails');
    Route::resource('students', WardenController::class);
});

// HR routes
Route::middleware(['auth', 'role:HR'])->group(function () {
    Route::get('/HR/dashboard', [HrController::class, 'dashboard'])->name('HR.dashboard');
    Route::resource('students', HrController::class);
});

// Home route
Route::get('/', function () {
    return view('home');
})->name('home');

// Resource routes for StudentController
Route::resource('students', StudentController::class);

// Route for the leave form
Route::get('/student/leave', function () {
    return view('leave');
})->name('leave.form');

// Dashboard routes (after login)
Route::middleware(['auth'])->group(function () {
    Route::get('/dashboard', function () {
        return view('HR.feedbacks');
    })->name('dashboard');
    Route::get('/dashboard/student', [StudentController::class, 'dashboard'])->name('student.dashboard');
    Route::get('/dashboard/hr', [HrController::class, 'dashboard'])->name('hr.dashboard');
    Route::get('/dashboard/warden', [WardenController::class, 'dashboard'])->name('warden.dashboard');
    Route::get('/dashboard/manager', [ManagerController::class, 'dashboard'])->name('manager.dashboard');
});

// Leave status update routes
Route::post('/leave/markViewed', [LeaveController::class, 'markLeaveRequestsAsViewed'])->name('leave.markViewed');
Route::post('/leave/approve', [LeaveController::class, 'approve'])->name('leave.approve');
Route::post('/leave/disapprove', [LeaveController::class, 'disapprove'])->name('leave.disapprove');
Route::get('/leave/fetch', [LeaveController::class, 'fetchLeaveRequests'])->name('leave.fetch');
Route::post('/leave/status', [LeaveController::class, 'checkStatus'])->name('leave.status');
Route::post('/leave/status/{cid}', [LeaveRequestController::class, 'showLeaveStatus']);
Route::get('/leave/status', [LeaveController::class, 'getLeaveStatus'])->name('leave.status');



Route::prefix('leave')->name('leave.')->group(function() {
    // Route to fetch leave requests (for Warden's dashboard)
    Route::get('/requests', [LeaveController::class, 'getLeaveRequests'])->name('requests');

    // Route to approve a leave request
    Route::post('/approve', [LeaveController::class, 'approveLeaveRequest'])->name('approve');

    // Route to disapprove a leave request
    Route::post('/disapprove', [LeaveController::class, 'disapproveLeaveRequest'])->name('disapprove');

    // Route to mark leave requests as viewed (optional)
    Route::post('/markViewed', [LeaveController::class, 'markLeaveRequestsAsViewed'])->name('markViewed');
});


Route::get('/student/status', [StudentController::class, 'status'])->name('student.status');

Route::get('/student/dashboard', [StudentController::class, 'dashboard'])->name('student.dashboard');
Route::get('/HR/dashboard', [HRController::class, 'dashboard'])->name('HR.dashboard');
Route::get('/warden/dashboard', [WardenController::class, 'dashboard'])->name('warden.dashboard');

Route::post('/leave/markViewed', [LeaveController::class, 'markViewed'])->name('leave.markViewed');
Route::post('/leave/approve', [LeaveController::class, 'approve'])->name('leave.approve');
Route::post('/leave/disapprove', [LeaveController::class, 'disapprove'])->name('leave.disapprove');
Route::get('/leave/requests', [LeaveController::class, 'getLeaveRequests'])->name('leave.requests');
Route::get('/student/leave/status/{student_id}', [StudentController::class, 'updateLeaveStatus'])->name('student.leave.status');

Route::get('/warden/leave-requests', [WardenController::class, 'getLeaveRequests'])->name('warden.leaveRequests');

Route::post('/leave/approve', [LeaveRequestController::class, 'approve'])->name('leave.approve');
Route::post('/leave/disapprove', [LeaveRequestController::class, 'disapprove'])->name('leave.disapprove');
Route::get('/warden/leave-requests', [WardenController::class, 'getLeaveRequests'])->name('warden.leaveRequests');


Route::get('/warden/leave-requests', [WardenController::class, 'getLeaveRequests'])->name('warden.leaveRequests');
Route::get('/leave-requests', [LeaveController::class, 'getLeaveRequests'])->name('leave.requests');
Route::get('leave/requests', [LeaveRequestController::class, 'getLeaveRequests'])->name('leave.requests');

Route::get('/warden/leave-requests', [WardenController::class, 'getLeaveRequests'])->name('leave.requests');

Route::get('/leave-requests', [LeaveRequestController::class, 'getLeaveRequests'])->name('leave.requests');
Route::post('/leave-mark-viewed', [LeaveRequestController::class, 'markLeaveRequestsAsViewed'])->name('leave.markViewed');
Route::post('/leave/approve', [LeaveController::class, 'approve'])->name('leave.approve');

Route::post('/leave/disapprove', [LeaveController::class, 'disapprove'])->name('leave.disapprove');

Route::get('/warden/students', [WardenController::class, 'viewStudentRegistrations'])->name('warden.viewStudents');


Route::get('/warden/dashboard', [WardenController::class, 'showDashboard'])->name('warden.dashboard');
Route::get('/warden/student-registrations', [WardenController::class, 'showStudentRegistrations'])->name('warden.studentRegistrations');
Route::post('/warden/student-registration/approve/{id}', [WardenController::class, 'approveStudentRegistration'])->name('warden.studentRegistration.approve');
Route::post('/warden/student-registration/disapprove/{id}', [WardenController::class, 'disapproveStudentRegistration'])->name('warden.studentRegistration.disapprove');
// In routes/web.php
Route::get('/warden/student-registrations', [WardenController::class, 'getStudentRegistrations'])->name('warden.studentRegistrations');


Route::get('/warden/leave-requests', [LeaveController::class, 'getLeaveRequests'])->name('leave.requests');

Route::post('/leave/approve', [LeaveController::class, 'approve'])->name('leave.approve');
Route::post('/leave/disapprove', [LeaveController::class, 'disapprove'])->name('leave.disapprove');

// In routes/web.php

Route::post('/warden/student/approve/{id}', [WardenController::class, 'approveStudentRegistration'])->name('warden.studentRegistration.approve');
Route::post('/warden/student/disapprove/{id}', [WardenController::class, 'disapproveStudentRegistration'])->name('warden.studentRegistration.disapprove');

Route::post('/warden/leave/approve/{id}', [WardenController::class, 'approveLeaveRequest'])->name('warden.leaveRequest.approve');
Route::post('/warden/leave/disapprove/{id}', [WardenController::class, 'disapproveLeaveRequest'])->name('warden.leaveRequest.disapprove');
Route::post('/warden/student-registration/reject/{studentId}', [WardenController::class, 'rejectStudentRegistration'])->name('warden.studentRegistration.reject');
Route::post('/warden/student-registration/reject/{id}', [WardenController::class, 'rejectStudentRegistration'])->name('warden.studentRegistration.reject');


// Approve leave application
Route::post('warden/leave/approve/{leaveId}', [LeaveController::class, 'approve'])->name('warden.leave.approve');

// Disapprove leave application
Route::post('warden/leave/disapprove/{leaveId}', [LeaveController::class, 'disapprove'])->name('warden.leave.disapprove');
Route::get('/student/registration', [StudentController::class, 'showRegistrationForm'])->name('student.registration');


Route::get('/hostel-registration', [StudentController::class, 'showRegistrationForm'])->name('student.hostel-registration');
Route::get('/student/hostel-registration-status', [StudentController::class, 'hostelRegistration'])->name('student.hostel-registration');
Route::get('/hostel-registration-status', [YourController::class, 'hostelRegistrationStatus'])->name('student.hostel-registration-status');
Route::get('/hostel-registration-status', [StudentController::class, 'hostelRegistrationStatus'])->name('student.hostel-registration-status');
Route::get('/hostel-registration-status', [StudentController::class, 'hostelRegistrationStatus'])->name('student.hostel-registration-status');

Route::post('/warden/roomAllocation', [WardenController::class, 'index'])->name('warden.roomAllocation.store');


//room allocation
Route::get('/warden/dashboard', [WardenController::class, 'index'])->name('warden.dashboard');
Route::get('warden/roomAllocation', [WardenController::class, 'showRoomAllocationForm'])->name('warden.room-allocation.form');
// Show the room allocation form (GET method)
Route::get('warden/roomAllocation', [WardenController::class, 'showRoomAllocationForm'])->name('warden.room-allocation.form');

// Route::post('warden/room-allocation', [WardenController::class, 'allocateRoom'])->name('warden.room-allocation');
// Route::get('/warden/room-allocation', [WardenController::class, 'showRoomAllocationForm'])->name('warden.room-allocation');
// // Define the route for room allocation in the Warden section
// Route::get('/warden/room-allocation', [WardenController::class, 'roomAllocation'])->name('warden.roomAllocation');

Route::get('/get-available-rooms', [RoomController::class, 'getAvailableRooms']);
Route::post('/allocate-room', [RoomController::class, 'allocateRoom']);
Route::get('/get-available-rooms', [WardenController::class, 'getAvailableRooms']);
// In your controller or route
Route::get('/debug-rooms', function() {
    $rooms = Room::all();
    dd($rooms); // Dump and die to see all room records
});
Route::get('/debug-rooms', [WardenController::class, 'debugRooms']);
Route::get('/debug-rooms', function() {
    $rooms = \App\Models\Room::all();
    return response()->json([
        'rooms' => $rooms,
        'count' => $rooms->count(),
        'block_values' => $rooms->pluck('block_no')->unique()
    ]);
});
Route::get('/debug-rooms', [YourController::class, 'debugRoomQuery']);

Route::get('/get-room-occupants', [WardenController::class, 'getRoomOccupants']);
Route::get('/get-available-rooms', [WardenController::class, 'getAvailableRooms']);
// Route::post('/warden/allocate-rooms', [WardenController::class, 'allocateRooms'])->name('warden.allocate-rooms');
Route::post('/allocate-room', [WardenController::class, 'allocateRoom'])->name('warden.allocate-room');
Route::get('/get-available-rooms', [WardenController::class, 'getAvailableRooms']);
Route::prefix('warden')->name('warden.')->group(function () {
    Route::get('/get-available-rooms', [WardenController::class, 'getAvailableRooms']);
    Route::get('/get-room-occupants', [WardenController::class, 'getRoomOccupants']);
    Route::get('/get-all-room-occupancy', [WardenController::class, 'getAllRoomOccupancy']);
    Route::get('/check-student-allocation', [WardenController::class, 'checkStudentAllocation']);
    Route::post('/allocate-rooms', [WardenController::class, 'allocateRooms'])->name('allocate-rooms');
});
Route::prefix('warden')->name('warden.')->group(function () {
    // Debug route to test API accessibility
    Route::get('/api-test', function() {
        return response()->json([
            'status' => 'ok',
            'message' => 'API is working',
            'timestamp' => now()->toDateTimeString()
        ]);
    });
    
    // Get available rooms
    Route::get('/get-available-rooms', [WardenController::class, 'getAvailableRooms']);
    
    // Get room occupants
    Route::get('/get-room-occupants', [WardenController::class, 'getRoomOccupants']);
    
    // Get all room occupancy
    Route::get('/get-all-room-occupancy', [WardenController::class, 'getAllRoomOccupancy']);
    
    // Check student allocation
    Route::get('/check-student-allocation', [WardenController::class, 'checkStudentAllocation']);
    
    // Allocate rooms
    Route::post('/allocate-rooms', [WardenController::class, 'allocateRooms'])->name('allocate-rooms');
});

// Add these routes to your routes/web.php file

Route::middleware(['auth', 'warden'])->prefix('warden')->group(function () {
    // Room allocation routes
    Route::get('/room-allocation', [WardenController::class, 'showRoomAllocation'])->name('warden.room-allocation');
    Route::post('/allocate-rooms', [WardenController::class, 'allocateRooms'])->name('warden.allocate-rooms');
    Route::get('/get-all-room-occupancy', [WardenController::class, 'getAllRoomOccupancy']);
    Route::get('/get-room-occupants', [WardenController::class, 'getRoomOccupants']);
});
// Route::post('/warden/allocate-room', [RoomAllocationController::class, 'allocateRoom'])->name('warden.roomAllocation');
// Check your routes.php or web.php
Route::post('/warden/allocate-rooms', [WardenController::class, 'allocateRooms'])->name('warden.allocate-rooms');
Route::middleware(['auth', 'warden'])->prefix('warden')->name('warden.')->group(function () {
    // Room allocation routes - make sure the name matches exactly what you're calling
    Route::post('/allocate-room', [WardenController::class, 'allocateRooms'])->name('allocate-room');
    Route::post('/allocate-rooms', [WardenController::class, 'allocateRooms'])->name('allocate-rooms'); // Keep this as a fallback

    Route::get('/get-room-occupants', [WardenController::class, 'getRoomOccupants']);
    Route::get('/get-all-room-occupancy', [WardenController::class, 'getAllRoomOccupancy']);
    
    // Add other warden routes here...
});
// Route::get('/warden/room-allocation', [WardenController::class, 'roomAllocation'])->name('warden.roomAllocation');
Route::post('/warden/allocate-rooms', 'WardenController@allocateRooms')->name('warden.allocate-rooms');
Route::post('/warden/allocate-rooms', 'WardenController@allocateRooms')->name('warden.allocate-rooms');
// Warden Routes
Route::prefix('warden')->name('warden.')->group(function () {
    // Room allocation routes
    Route::get('/room-allocation', [RoomAllocationController::class, 'index'])->name('room-allocation');
    Route::post('/allocate-rooms', [RoomAllocationController::class, 'allocateRoom'])->name('allocate-room');
    Route::get('/get-room-occupants', [RoomAllocationController::class, 'getRoomOccupants']);
    Route::get('/get-all-room-occupancy', [RoomAllocationController::class, 'getAllRoomOccupancy']);
});
Route::post('/warden/allocate-rooms', [RoomAllocationController::class, 'allocateRoom'])->name('warden.allocate-room');
// Route::get('/warden/room-allocation', [WardenController::class, 'roomAllocation'])->name('warden.roomAllocation');

Route::post('/attendance/store', [AttendanceController::class, 'store'])->name('attendance.store');
Route::post('/warden/attendance/store', [WardenController::class, 'storeAttendance'])->name('warden.attendance.store');
Route::get('/take-attendance', [AttendanceController::class, 'showAttendanceForm'])->name('takeattendance');


Route::get('/take-attendance', [AttendanceController::class, 'showAttendanceForm'])->name('takeattendance');
Route::post('/take-attendance', [AttendanceController::class, 'storeAttendance'])->name('warden.attendance.store');
Route::get('/attendance/form', [AttendanceController::class, 'showAttendanceForm']);

Route::get('/warden/students', [WardenController::class, 'getStudents'])->name('warden.students');
Route::get('/get-rooms/{block_no}', [RoomAllocationController::class, 'getRooms'])->name('get.rooms');
Route::post('/hr/attendance/store', [AttendanceController::class, 'store'])->name('hr.attendance.store');
Route::get('/get-students', [AttendanceController::class, 'getStudents']);
Route::get('/api/rooms/{blockNo}', [RoomAllocationController::class, 'getRoomsByBlock']);
Route::get('/api/room-allocations', [RoomAllocationController::class, 'getRoomAllocations']);
Route::post('/hr/attendance/store', [RoomAllocationController::class, 'storeAttendance'])->name('hr.attendance.store');

Route::get('/status', [StudentController::class, 'status'])->name('status');
Route::get('/profile', [StudentController::class, 'profile'])->name('profile');
Route::get('/help', [StudentController::class, 'help'])->name('help');

Route::post('/warden/allocate-rooms', [WardenController::class, 'allocateRooms'])->name('warden.allocate-rooms');
Route::prefix('warden')->group(function () {
    // Room allocation
    Route::post('/allocate-room', [WardenController::class, 'allocateRoom'])->name('warden.allocate-room');
    Route::post('/allocate-rooms', [WardenController::class, 'allocateRoom']); // Alias for fallback
    
    // Room data endpoints
    Route::get('/get-all-rooms', [WardenController::class, 'getAllRooms']);
    Route::get('/get-rooms-by-block', [WardenController::class, 'getRoomsByBlock']);
    Route::get('/get-room-details', [WardenController::class, 'getRoomDetails']);
    
    // Dashboard view
    Route::get('/dashboard', [WardenController::class, 'dashboard'])->name('warden.dashboard');
});
// Routes for room allocation
// Route::post('/warden/allocate-room', 'WardenController@allocateRoom')->name('warden.allocate-room');
Route::post('/warden/allocate-rooms', 'WardenController@allocateRoom'); 
// Route::get('/warden/room-allocation', [WardenController::class, 'roomAllocation'])->name('warden.roomAllocation');

Route::get('/warden/get-all-room-occupancy', [RoomAllocationController::class, 'getRoomOccupancy']);
Route::post('/warden/allocate-rooms', [RoomAllocationController::class, 'allocateRoom']);
Route::prefix('warden')->name('warden.')->group(function () {
    // Room allocation routes
    Route::get('/room-allocation', [RoomAllocationController::class, 'index'])->name('room-allocation');
    Route::post('/allocate-rooms', [RoomAllocationController::class, 'allocateRoom'])->name('allocate-room');
    Route::get('/get-room-occupants', [RoomAllocationController::class, 'getRoomOccupants']);
    Route::get('/get-all-room-occupancy', [RoomAllocationController::class, 'getAllRoomOccupancy']);
});
// Route::post('/allocate-room', [WardenController::class, 'allocateRoom'])->name('warden.roomAllocation');
Route::prefix('warden')->name('warden.')->group(function () {
    // Room allocation routes
    Route::post('/allocate-rooms', [RoomAllocationController::class, 'allocateRooms'])->name('allocate-room');
});
// routes/web.php
Route::post('/warden/allocate-rooms', [WardenController::class, 'allocateRooms']);

Route::middleware(['auth', 'role:warden'])->group(function () {
    // Existing routes...
    
    // Make sure these routes are defined:
    Route::post('/warden/allocate-rooms', [WardenController::class, 'allocateRooms'])->name('warden.allocate-rooms');
    Route::get('/warden/get-room-occupants', [WardenController::class, 'getRoomOccupants'])->name('warden.get-room-occupants');
    Route::get('/warden/get-all-room-occupancy', [WardenController::class, 'getAllRoomOccupancy'])->name('warden.get-all-room-occupancy');
});
// Routes for room allocations and attendance management
Route::get('/api/rooms/{blockNo}', [RoomAllocationController::class, 'getRoomsByBlock']);
Route::get('/api/room-allocations', [RoomAllocationController::class, 'getRoomAllocations']);
Route::post('/hr/attendance/store', [RoomAllocationController::class, 'storeAttendance'])->name('hr.attendance.store');
Route::post('/warden/allocate-room', 'WardenController@allocateRoom')->name('warden.allocate-room');
// or
Route::post('/warden/allocate-rooms', 'WardenController@allocateRooms')->name('warden.allocate-rooms');
Route::get('/hostel-register', [StudentController::class, 'hostelRegistration'])->name('hostel.register');

// Route::get('/warden/room-allocation', [WardenController::class, 'roomAllocation'])->name('warden.roomAllocation');
Route::post('/warden/allocate-rooms', [WardenController::class, 'allocateRooms'])->name('warden.allocate-rooms');
// HR routes
Route::middleware(['auth', 'role:hr'])->prefix('hr')->name('hr.')->group(function () {
    // Attendance routes
    Route::post('/attendance/store', [AttendanceController::class, 'store'])->name('attendance.store');
    Route::get('/attendance', [AttendanceController::class, 'index'])->name('attendance.index');
});
Route::post('/hr/attendance/store', [HRAttendanceController::class, 'store'])->name('hr.attendance.store');
// Route for room allocation in web.php
// Route::get('/warden/room-allocation', [WardenController::class, 'showRoomAllocation'])->name('warden.room-allocation');

// Room allocation route for the post request
Route::post('/warden/allocate-rooms', [WardenController::class, 'allocateRooms'])->name('warden.allocate-rooms');
Route::get('/warden/get-room-occupants', [WardenController::class, 'getRoomOccupants'])
     ->name('warden.get-room-occupants');
     
Route::get('/warden/get-all-room-occupancy', [WardenController::class, 'getAllRoomOccupancy'])
     ->name('warden.get-all-room-occupancy');
Route::get('/warden/room-allocation', [WardenController::class, 'roomAllocation'])->name('warden.roomAllocation');

Route::post('/warden/allocate-rooms', [App\Http\Controllers\WardenController::class, 'allocateRoom'])
    ->name('warden.allocate-rooms');
Route::get('/warden/get-room-occupants', [App\Http\Controllers\WardenController::class, 'getRoomOccupants'])
    ->name('warden.get-room-occupants');
Route::get('/warden/get-all-room-occupancy', [App\Http\Controllers\WardenController::class, 'getAllRoomOccupancy'])
    ->name('warden.get-all-room-occupancy');
    route::post('/warden/allocate-rooms', [WardenController::class, 'allocateRooms'])->name('warden.allocate-rooms');
Route::post('/warden/leave/approve/{id}', 'WardenController@approveLeave')->name('warden.leave.approve');
Route::post('/warden/leave/disapprove/{id}', 'WardenController@disapproveLeave')->name('warden.leave.disapprove');
Route::post('/leave/cancel/{id}', [studentController::class, 'cancel'])->name('leave.cancel');

Route::get('/warden/leave/acknowledge', [WardenController::class, 'acknowledge'])->name('warden.leave.acknowledge');
Route::get('/warden/cancelled-leaves', [WardenController::class, 'cancelledLeaves'])->name('warden.cancelledLeaves');
Route::get('/warden/notifications', [WardenController::class, 'notifications'])->name('warden.notifications');
Route::get('/warden/notifications/{notification}/mark-read', [WardenController::class, 'markNotificationRead'])->name('warden.markNotificationRead');
Route::get('/warden/notifications/mark-all-read', [WardenController::class, 'markAllNotificationsRead'])->name('warden.markAllNotificationsRead');
Route::get('/warden/cancelled-leaves', 'WardenController@getCancelledLeaves')->name('warden.cancelledLeaves');
// In routes/web.php
Route::post('/student/register', [StudentController::class, 'register'])->name('student.register');
// In routes/web.php
Route::get('/warden/room-allocations', [WardenController::class, 'getRoomAllocations'])->name('warden.roomAllocations');
Route::get('/warden/feedbacks', [WardenController::class, 'getFeedbacks'])->name('warden.feedbacks');
// Route::get('/warden/reports', [WardenController::class, 'getReports'])->name('warden.reports');

Route::get('/attendance-report', [AttendanceController::class, 'attendance'])->name('attendancereport');
Route::get('/attendance-report', [AttendanceController::class, 'report'])->name('attendance.report');
Route::get('/attendance/export-excel', [AttendanceController::class, 'exportExcel'])->name('attendance.export.excel');
Route::get('/attendance/export-pdf', [AttendanceController::class, 'exportPdf'])->name('attendance.export.pdf');
Route::get('/attendance/report', [AttendanceController::class, 'report'])->name('attendancereport');

Route::get('/attendance/report', [AttendanceController::class, 'report'])->name('attendance.report');
Route::get('/attendance/export/excel', [AttendanceController::class, 'exportExcel'])->name('attendance.export.excel');
Route::get('/attendance/export/pdf', [AttendanceController::class, 'exportPDF'])->name('attendance.export.pdf');
Route::get('/attendance-report', [AttendanceController::class, 'report'])->name('attendancereport');
// Attendance routes
Route::get('/attendance/report', [AttendanceController::class, 'report'])->name('attendance.report');
Route::get('/attendance/export/excel', [AttendanceController::class, 'exportExcel'])->name('attendance.export.excel');
Route::get('/attendance/export/pdf', [AttendanceController::class, 'exportPDF'])->name('attendance.export.pdf');

Route::get('/feedbacks', function () {
    return view('student.feedbacks');
})->name('feedbacks');
Route::post('/feedbacks', [FeedbackController::class, 'store'])->name('feedbacks.store');
Route::patch('/warden/feedbacks/{feedback}/resolve', [FeedbackController::class, 'resolve'])->name('warden.feedback.resolve');
Route::get('/warden/feedbacks', 'WardenController@getFeedbacks')->name('warden.feedbacks');
Route::post('/warden/feedback/resolve/{id}', 'WardenController@resolveFeedback')->name('warden.feedback.resolve');
Route::get('/warden/feedbacks', [WardenController::class, 'getFeedbacks'])->name('warden.feedbacks');
Route::get('/warden/feedbacks', [WardenController::class, 'getFeedbacks'])->name('warden.feedbacks');
// // For feedback resolution
// Route::post('/warden/feedback/resolve/{id}', 'WardenController@resolveFeedback')->name('warden.feedback.resolve');
// Route::post('/warden/feedback/{id}/resolve', 'WardenController@resolveFeedback')->name('warden.feedback.resolve');
// // OR
// Route::post('/warden/feedback/resolve/{id}', 'WardenController@resolveFeedback')->name('warden.feedback.resolve');
// // In routes/web.php
// Route::get('/warden/feedback/test', function() {
//     return response()->json(['status' => 'success', 'message' => 'Test route working']);
// });
// Route::post('/warden/feedback/resolve/{id}', [App\Http\Controllers\WardenController::class, 'resolveFeedback'])->name('warden.feedback.resolve');
// Route::post('/warden/feedback/resolve/{id}', [App\Http\Controllers\WardenController::class, 'resolveFeedback'])->name('warden.feedback.resolve');
// Make sure this is within your warden middleware group
// One of these formats depending on your route structure:
  
Route::post('/warden/feedback/resolve/{id}', [WardenController::class, 'markAsResolved'])->name('warden.feedback.resolve');
Route::post('/warden/feedback/resolve/{id}', [FeedbackController::class, 'markAsResolved']);
Route::get('/reports', [ReportController::class, 'index'])->name('warden.report');
// Route::get('/warden/reports', [WardenController::class, 'getReports'])->name('warden.reports');
Route::get('/reports', [ReportController::class, 'fetchReports'])->name('warden.reports');
// Route::get('/warden/report', [WardenController::class, 'report'])->name('warden.report');
Route::get('/reports', [ReportController::class, 'index'])->name('warden.report');

Route::get('/warden/dashboard', [WardenController::class, 'index'])->name('warden.dashboard');
Route::get('/warden/report', [WardenController::class, 'report'])->name('warden.report');

Route::get('/warden/report', [WardenController::class, 'report'])->name('warden.report');

Route::get('/warden/reports', 'WardenController@getReports')->name('warden.reports');
Route::get('/room-allocations', [RoomAllocationController::class, 'index'])->name('room-allocations.index');
Route::get('/room-allocations/{id}', [RoomAllocationController::class, 'show'])->name('room-allocations.show');
Route::get('/leaves', [LeaveController::class, 'index'])->name('leaves.index');
Route::get('/leaves/{id}', [LeaveController::class, 'show'])->name('leaves.show');
Route::get('/leaves/{id}/approve', [LeaveController::class, 'approve'])->name('leaves.approve');
Route::get('/leaves/{id}/reject', [LeaveController::class, 'reject'])->name('leaves.reject');
Route::get('/feedback', [FeedbackController::class, 'index'])->name('feedback.index');
Route::get('/feedback/{id}', [FeedbackController::class, 'show'])->name('feedback.show');
Route::post('/feedback/{id}/mark-read', [FeedbackController::class, 'markRead'])->name('feedback.mark-read');
Route::get('/room-allocations/create', [RoomAllocationController::class, 'create'])->name('room-allocations.create');

/// Export routes
Route::get('/export/students', [App\Http\Controllers\ReportController::class, 'exportStudents'])->name('export.students');
Route::get('/export/room-allocations', [App\Http\Controllers\ReportController::class, 'exportRoomAllocations'])->name('export.room-allocations');
Route::get('/export/leaves', [App\Http\Controllers\ReportController::class, 'exportLeaves'])->name('export.leaves');
Route::get('/export/feedback', [App\Http\Controllers\ReportController::class, 'exportFeedback'])->name('export.feedback');
Route::get('room-allocations/{id}/edit', [RoomAllocationController::class, 'edit'])->name('room-allocations.edit');
route::get('/hr/leave-requests', [App\Http\Controllers\HRController::class, 'viewLeaveRequests'])->name('hr.leave-requests');
Route::get('/leave/requests', [LeaveController::class, 'getRequests'])->name('leave.requests');
Route::post('/warden/validate-allocations', [WardenController::class, 'validateAllocations'])
    ->name('warden.validate-allocations');
    Route::post('/warden/validate-allocations', 'WardenController@validateAllocations')->name('warden.validate-allocations');
    Route::get('/leave-requests', [LeaveRequestController::class, 'index'])->name('leave-requests');
    
    
    Route::middleware(['auth', 'checkrole:hr'])->group(function () {
        Route::get('/hr/feedbacks', [App\Http\Controllers\HRController::class, 'getFeedbacks'])->name('hr.feedbacks');
        // For AJAX requests to get feedback data
        Route::get('/hr/get-feedbacks', [App\Http\Controllers\HRController::class, 'getFeedbacks'])->name('hr.getFeedbacks');
    });
    // Route::get('/feedbacks', [HRController::class, 'feedbacks'])->name('feedbacks');
Route::get('/hr-dashboard', [HRController::class, 'dashboard'])->name('feedbacks-back');
// Route::get('/hr/feedbacks', [HRController::class, 'feedbacks'])->name('hr.feedbacks');
route::get('/reports/hr', [HRReportController::class, 'generateReport'])->name('reports.hr');
Route::get('/reports/hr/filter', [HRReportController::class, 'generateReport'])->name('reports.hr.filter');
Route::get('/reports/hr', [HRReportController::class, 'generateReport'])->name('hr.report');
Route::get('/reports/hr/filter', [HRReportController::class, 'generateReport'])->name('hr.report.filter');
Route::get('/report', [ReportController::class, 'index'])->name('report');
Route::get('/hr/report', [App\Http\Controllers\HRReportController::class, 'index'])->name('report');
Route::get('/report', [ReportController::class, 'index'])->name('report');
Route::get('/reports', [ReportController::class, 'index'])->name('reports');
// Route::get('/studentreport', [ReportController::class, 'index'])->name('studentreport');
Route::get('/student/reports', [StudentController::class, 'reports'])->name('student.reports');
Route::get('/studentreport', [ReportController::class, 'index'])->name('studentreport');
Route::get('/studentreport', [ReportController::class, 'studentReport'])->name('studentreport');
Route::get('/leave-requests', [LeaveController::class, 'getLeaveRequests'])->name('leave.requests');
Route::post('/feedback/{feedback}/mark-resolved', [FeedbackController::class, 'markResolved'])->name('feedback.mark-resolved');
// In routes/web.php or routes/api.php
Route::get('/leave/requests', [App\Http\Controllers\LeaveController::class, 'index'])->name('leave.requests');
Route::get('/leave-requests', [LeaveRequestController::class, 'index'])->name('leave-requests');
// Feedback routes
Route::middleware(['auth'])->group(function () {
    // Route::get('/feedbacks', [App\Http\Controllers\HRController::class, 'feedbacks'])->name('feedbacks');
    Route::post('/feedbacks', [App\Http\Controllers\HRController::class, 'storeFeedback'])->name('feedback.store');
    Route::put('/feedbacks/{id}/resolve', [App\Http\Controllers\HRController::class, 'resolveFeedback'])->name('feedback.resolve');
});
Route::post('/feedbacks', [FeedbackController::class, 'store'])->name('feedbacks.store');
Route::get('/feedbacks', [HrController::class, 'feedbacks'])->name('feedbacks')->middleware('auth');
// In routes/web.php
Route::get('/student/report', [StudentController::class, 'report'])->name('student.report');
Route::get('/export/report', [ExportController::class, 'exportReport'])->name('export.report');
// Student Reports Routes
Route::get('/student/reports', [StudentReportController::class, 'index'])->name('studentreport');
Route::get('/student/reports/export', [StudentReportController::class, 'exportReport'])->name('export.report');

Route::get('/student/report', [StudentController::class, 'studentReport'])->name('studentreport');
Route::get('/student/report', [StudentReportController::class, 'index'])->name('student.report');
// In your routes/web.php
Route::get('/student/reports', [StudentReportController::class, 'index'])->name('studentreport');
Route::get('/export/report', [StudentReportController::class, 'exportReport'])->name('export.report');


//leave
// This should be in your routes file (web.php or api.php)
Route::get('leave/requests', 'LeaveController@getRequests')->name('leave.requests');
// In your routes file
Route::get('/leave/requests', 'LeaveController@getRequests')
    ->name('leave.requests')
    ->middleware('auth:api'); // Or a custom middleware that doesn't redirect
    // Make sure this exists and is correctly defined
Route::get('/warden/leave-requests', [LeaveController::class, 'getRequests'])->name('leave.requests');
// Route::get('/leave-requests', [LeaveController::class, 'getRequests'])->name('leave.requests');

Route::post('/warden/leave/approve/{id}', 'App\Http\Controllers\WardenController@approveLeave');
Route::post('/warden/leave/disapprove/{id}', 'App\Http\Controllers\WardenController@disapproveLeave');

// In routes/web.php
Route::post('/admin/student/{id}/approve', [StudentController::class, 'approveRegistration'])->name('admin.student.approve');
Route::post('/admin/leave/{id}/approve', [LeaveController::class, 'approveLeave'])->name('admin.leave.approve');
Route::post('register', [RegisterController::class, 'register']);
Route::get('/feedbacks', [FeedbackController::class, 'index'])->name('feedbacks');

