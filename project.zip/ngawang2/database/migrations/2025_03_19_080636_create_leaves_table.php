<?php



use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateLeavesTable extends Migration
{
    // public function up()
    // {
    //     Schema::create('leaves', function (Blueprint $table) {
    //         $table->id();
    //         $table->string('cid'); // CID of the student
    //         $table->date('leave_start_date'); // Start date of leave
    //         $table->date('leave_end_date'); // End date of leave
    //         $table->text('leave_reason'); // Reason for leave
    //         $table->enum('status', ['pending', 'approved', 'rejected'])->default('pending'); // Status of the leave
    //         $table->timestamps(); // Created at and updated at columns
    //     });
    // }

    // public function down()
    // {
    //     Schema::dropIfExists('leaves');
    // }
    public function up()
{
    Schema::create('leaves', function (Blueprint $table) {
        $table->id();
        $table->string('cid'); // Assuming it's a string or numeric type
        $table->date('leave_start_date');
        $table->date('leave_end_date');
        $table->text('leave_reason');
        $table->timestamps();
    });
}

public function down()
{
    Schema::dropIfExists('leaves');
}
}
