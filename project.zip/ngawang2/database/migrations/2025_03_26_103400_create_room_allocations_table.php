<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateRoomAllocationsTable extends Migration
{
    public function up()
    {
        Schema::create('room_allocations', function (Blueprint $table) {
            $table->id('allocation_id');
            $table->string('cid');
            $table->string('block_no');
            $table->string('room_no');
            $table->date('allocation_date');
            $table->timestamps();

            // Foreign key constraints
            $table->foreign('cid')->references('cid')->on('students')->onDelete('cascade');
            $table->foreign(['block_no', 'room_no'])->references(['block_no', 'room_no'])->on('rooms')->onDelete('cascade');
        });
    }

    public function down()
    {
        Schema::dropIfExists('room_allocations');
    }
}