<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
{
    Schema::table('attendance', function (Blueprint $table) {
        if (!Schema::hasColumn('attendance', 'allocation_id')) {
            $table->unsignedBigInteger('allocation_id')->after('id');
            // Add foreign key constraint
            $table->foreign('allocation_id')->references('allocation_id')->on('room_allocations')
                  ->onDelete('cascade');
        }
        
        if (!Schema::hasColumn('attendance', 'cid')) {
            $table->string('cid')->after('allocation_id');
        }
        
        if (!Schema::hasColumn('attendance', 'block_no')) {
            $table->string('block_no')->after('cid');
        }
        
        if (!Schema::hasColumn('attendance', 'room_no')) {
            $table->string('room_no')->after('block_no');
        }
        
        if (!Schema::hasColumn('attendance', 'remarks')) {
            $table->text('remarks')->nullable()->after('status');
        }
        
        // Add unique constraint if it doesn't exist
        // (You may need to modify this approach depending on your DB system)
        $sm = Schema::getConnection()->getDoctrineSchemaManager();
        $indexes = $sm->listTableIndexes('attendance');
        if (!array_key_exists('attendance_allocation_id_attendance_date_unique', $indexes)) {
            $table->unique(['allocation_id', 'attendance_date']);
        }
    });
}

public function down()
{
    Schema::table('attendance', function (Blueprint $table) {
        $table->dropColumn(['allocation_id', 'cid', 'block_no', 'room_no', 'remarks']);
        $table->dropForeign(['allocation_id']);
        $table->dropUnique(['allocation_id', 'attendance_date']);
    });
}

    
};
