<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateAttendanceTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('attendance', function (Blueprint $table) {
            $table->id();
            $table->unsignedBigInteger('allocation_id');
            $table->string('cid');
            $table->string('block_no');
            $table->string('room_no');
            $table->date('attendance_date');
            $table->enum('status', ['present', 'absent', 'leave']);
            $table->text('remarks')->nullable();
            $table->timestamps();
            
            // Foreign key constraint
            $table->foreign('allocation_id')->references('allocation_id')->on('room_allocations')
                  ->onDelete('cascade');
                  
            // Add unique constraint to prevent duplicate entries
            $table->unique(['allocation_id', 'attendance_date']);
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('attendance');
    }
}
