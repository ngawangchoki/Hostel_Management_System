<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::table('students', function (Blueprint $table) {
            // Change the status column to string with a default of 'pending'
            $table->string('status')->default('pending')->change();  // Ensure it can be 'pending', 'approved', 'disapproved'
        });
    }
    
    public function down()
    {
        Schema::table('students', function (Blueprint $table) {
            // If rolling back, drop the status column
            $table->dropColumn('status');
        });
    }
    
};
    