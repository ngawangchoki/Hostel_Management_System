<?php

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;

class UsersTableSeeder extends Seeder
{
    public function run()
    {
        DB::table('users')->insert([
            'username' => 'sonam',
            'password' => Hash::make('sonam'), // Hash the password
            'role' => 'student',
            'created_at' => now(),
            'updated_at' => now(),
        ]);

        // Add more users as needed
    }
}
